import SwiftUI
import WidgetKit
import AppIntents
import UniformTypeIdentifiers
import PhotosUI
import QuickLook
import Speech
import AVFoundation
import UIKit
import Security
import CommonCrypto

// I3b3v: same App Intent registered in the containing app and widget extension.
// The extension queues an atomic completion request; the app applies it to storage.
struct FEI3b3wMarkCompletedIntent: AppIntent {
    static var title: LocalizedStringResource = "Отметить заметку выполненной"
    static var openAppWhenRun: Bool { false }
    @Parameter(title: "Идентификатор заметки") var noteID: String
    init() { noteID = "" }
    init(noteID: String) { self.noteID = noteID }
    func perform() async throws -> some IntentResult {
        guard let id = UUID(uuidString: noteID)?.uuidString.lowercased() else {
            throw NSError(domain: "NorrNoteWidgetCompletion", code: 1031,
                          userInfo: [NSLocalizedDescriptionKey: "Неверный ID заметки"])
        }
        guard let group = FileManager.default.containerURL(
            forSecurityApplicationGroupIdentifier: "group.su.norrvind.norrnote.fe.ios") else {
            throw NSError(domain: "NorrNoteWidgetCompletion", code: 1032,
                          userInfo: [NSLocalizedDescriptionKey: "App Group недоступна"])
        }
        let dir = group.appendingPathComponent("WidgetCompletionRequests-v1", isDirectory: true)
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let record: [String: Any] = ["id": id, "atMillis": Int64(Date().timeIntervalSince1970 * 1000)]
        let bytes = try JSONSerialization.data(withJSONObject: record)
        try bytes.write(to: dir.appendingPathComponent(id + ".json"), options: [.atomic])
        WidgetCenter.shared.reloadTimelines(ofKind: FEWidgetBridge.widgetKind)
        return .result()
    }
}

// Android FE-inspired structure: three primary screens, category chips, pastel cards,
// independent Important property, direct completion and quick-add actions.
// Pure SwiftUI for iOS 17+. Does not add mock cloud sync or notifications.
private enum FEMintTheme {
    static let button = Color(.sRGB, red: 0.82, green: 0.93, blue: 0.83, opacity: 1)
    static let accent = Color(.sRGB, red: 0.20, green: 0.47, blue: 0.34, opacity: 1)
    static let border = Color(.sRGB, red: 0.58, green: 0.77, blue: 0.63, opacity: 1)
    static let text = Color(.sRGB, red: 0.10, green: 0.30, blue: 0.21, opacity: 1)
}

private enum FEAndroidPalette {
    // I3b3c: 4-color iOS visual palette; unchanged Sync21 colorIndex storage.
    static let rgb: [UInt32] = [0xC9B8E8, 0xA9E2CB, 0xF5C8AE, 0x4A3F5C]
    static func displayIndex(_ raw: Int) -> Int {
        switch raw {
        case 0...3: return raw
        case 4: return 0
        case 5, 6: return 2
        case 7: return 1
        default: return 0
        }
    }
    static func isDark(_ index: Int) -> Bool { displayIndex(index) == 3 }
    static func ink(_ index: Int) -> Color { isDark(index) ? .white : .black }
    static func color(_ index: Int) -> Color {
        let n = rgb[displayIndex(index)]
        return Color(.sRGB, red: Double((n >> 16) & 255) / 255,
                     green: Double((n >> 8) & 255) / 255,
                     blue: Double(n & 255) / 255, opacity: 1)
    }
}

// I3b.1: Pure, read-only calendar occurrence math shared by the iOS day screen and calendar.
// Never creates extra notes, changes modifiedAt, or writes Sync21 snapshots.

enum FECalendarEngine {
    private static func day(_ text: String, calendar: Calendar) -> Date? {
        let parts = text.split(separator: "-", omittingEmptySubsequences: false)
        guard parts.count == 3, let year = Int(parts[0]), let month = Int(parts[1]),
              let day = Int(parts[2]), (1...12).contains(month), (1...31).contains(day),
              let value = calendar.date(from: DateComponents(year: year, month: month, day: day)),
              calendar.component(.year, from: value) == year,
              calendar.component(.month, from: value) == month,
              calendar.component(.day, from: value) == day else { return nil }
        return calendar.startOfDay(for: value)
    }

    static func includes(target: Date, scheduledDate: String, createdAtMillis: Int64,
                         kind: String, repeatRule: String, repeatWeekdays: String,
                         reminderAtMillis: Int64? = nil,
                         calendar: Calendar = .current) -> Bool {
        if kind == "PERMANENT" { return false }
        let candidate = calendar.startOfDay(for: target)
        let fallback = reminderAtMillis ?? createdAtMillis
        guard let base = day(scheduledDate, calendar: calendar) ??
                (fallback > 0 ? calendar.startOfDay(for: Date(timeIntervalSince1970: Double(fallback) / 1000)) : nil),
              candidate >= base else { return false }
        let rule = repeatRule.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        // Legacy birthdays have an annual recurrence even when repeatRule is missing.
        let normalized = rule.isEmpty && kind == "BIRTHDAY" ? "YEARLY" : rule
        if normalized.isEmpty || normalized == "NONE" { return calendar.isDate(candidate, inSameDayAs: base) }
        let baseDay = calendar.dateComponents([.year, .month, .day, .weekday], from: base)
        let wanted = calendar.dateComponents([.year, .month, .day, .weekday], from: candidate)
        switch normalized {
        case "DAILY": return true
        case "WEEKLY":
            guard let diff = calendar.dateComponents([.day], from: base, to: candidate).day else { return false }
            return diff >= 0 && diff % 7 == 0
        case "WEEKDAYS":
            let days = Set(repeatWeekdays.split(separator: ",").compactMap { Int($0.trimmingCharacters(in: .whitespaces)) })
            // Android and Windows: Monday=1 ... Sunday=7. Foundation: Sunday=1.
            let isoDay = ((wanted.weekday ?? 1) + 5) % 7 + 1
            return days.contains(isoDay)
        case "MONTHLY":
            // A 31st-day event skips months without the 31st; never rolls into next month.
            return wanted.day == baseDay.day
        case "YEARLY":
            if baseDay.month == 2 && baseDay.day == 29 && !calendar.isLeapYear(wanted.year ?? 0) {
                return wanted.month == 2 && wanted.day == 28
            }
            return wanted.month == baseDay.month && wanted.day == baseDay.day
        default: return calendar.isDate(candidate, inSameDayAs: base)
        }
    }

    static func nextOccurrence(from start: Date, scheduledDate: String, createdAtMillis: Int64,
                               kind: String, repeatRule: String, repeatWeekdays: String,
                               reminderAtMillis: Int64? = nil,
                               calendar: Calendar = .current) -> Date? {
        let first = calendar.startOfDay(for: start)
        // Bounded, read-only 2-year horizon also covers Feb 29 fallback policy.
        for offset in 0...732 {
            guard let date = calendar.date(byAdding: .day, value: offset, to: first) else { continue }
            if includes(target: date, scheduledDate: scheduledDate, createdAtMillis: createdAtMillis,
                        kind: kind, repeatRule: repeatRule, repeatWeekdays: repeatWeekdays,
                        reminderAtMillis: reminderAtMillis, calendar: calendar) { return date }
        }
        return nil
    }

    // Encode subtypes in a Sync21 v2 field that Android/Windows already serialize.
    // Never introduce an unknown wire type "DATE".
    static func isDateEvent(kind: String, repeatRule: String, categoryKey: String) -> Bool {
        categoryKey.hasPrefix("fe-date:") || kind == "BIRTHDAY" ||
            (kind == "REPEATING" && repeatRule.uppercased() == "YEARLY")
    }
    static func dateSubtype(kind: String, repeatRule: String, categoryKey: String) -> String {
        let parts = categoryKey.split(separator: ":")
        if parts.count >= 2 && parts[0] == "fe-date" {
            let type = String(parts[1]); if ["birthday", "wedding", "anniversary", "other"].contains(type) { return type }
        }
        return kind == "BIRTHDAY" ? "birthday" : "anniversary"
    }
    static func yearKnown(_ categoryKey: String) -> Bool {
        !categoryKey.hasSuffix(":noyear")
    }
}

private extension Calendar {
    func isLeapYear(_ year: Int) -> Bool { (year % 4 == 0 && year % 100 != 0) || year % 400 == 0 }
}

private enum FEPage: Int, CaseIterable {
    case day, calendar, permanent, dates, all, trash
    var title: String {
        switch self {
        case .day: return "На день"
        case .calendar: return "Календарь"
        case .permanent: return "Постоянные"
        case .dates: return "Даты"
        case .all: return "Все записи"
        case .trash: return "Корзина"
        }
    }
    var symbol: String {
        switch self {
        case .day: return "note.text"
        case .calendar: return "calendar"
        case .permanent: return "pin.fill"
        case .dates: return "gift"
        case .all: return "square.grid.2x2"
        case .trash: return "trash"
        }
    }
}

private enum FENoteType: String, CaseIterable, Identifiable {
    case text = "TEXT", list = "LIST", permanent = "PERMANENT"
    case reminder = "REMINDER", birthday = "BIRTHDAY", repeating = "REPEATING"
    var id: String { rawValue }
    var title: String {
        switch self {
        case .text: return "Заметка"
        case .list: return "Список"
        case .permanent: return "Постоянная"
        case .reminder: return "Напоминание"
        case .birthday: return "День рождения"
        case .repeating: return "Повторяющаяся"
        }
    }
    var symbol: String {
        switch self {
        case .text: return "note.text"
        case .list: return "checklist"
        case .permanent: return "pin"
        case .reminder: return "bell"
        case .birthday: return "gift"
        case .repeating: return "repeat"
        }
    }
}

private struct FECategory: Identifiable {
    let id: String
    let title: String
    static func symbol(_ key: String) -> String {
        switch key {
        case "home": return "house.fill"
        case "work": return "briefcase.fill"
        case "study": return "graduationcap.fill"
        case "shopping": return "cart.fill"
        case "hobby": return "paintpalette.fill"
        case "personal": return "person.fill"
        case "data": return "externaldrive.fill"
        default: return "folder.fill"
        }
    }
    static let base: [FECategory] = [
        .init(id: "work", title: "Работа"), .init(id: "home", title: "Дом"),
        .init(id: "personal", title: "Личное"), .init(id: "study", title: "Учёба"),
        .init(id: "shopping", title: "Покупки"), .init(id: "hobby", title: "Хобби"),
        .init(id: "data", title: "Данные")
    ]
}

// Bridge from local note read model to the read-only recurrence engine.
private extension FEiOSNote {
    func occurs(on date: Date) -> Bool {
        FECalendarEngine.includes(target: date, scheduledDate: scheduledDate,
            createdAtMillis: createdAtMillis, kind: kind, repeatRule: repeatRule,
            repeatWeekdays: repeatWeekdays, reminderAtMillis: reminderAtMillis)
    }
    func displayed(on date: Date) -> FEiOSNote {
        var result = self
        // Gregorian local date matches FEiOSStore.dateString without calling
        // the main-actor isolated store from this nonisolated model helper.
        let components = Calendar(identifier: .gregorian)
            .dateComponents(in: TimeZone.current, from: date)
        let key = String(format: "%04d-%02d-%02d",
                         components.year ?? 0, components.month ?? 0, components.day ?? 0)
        result.isCompleted = completionsByDate[key] ?? (Calendar.current.isDateInToday(date) && isCompleted)
        return result
    }
    var nextAnniversaryDate: Date? {
        FECalendarEngine.nextOccurrence(from: Date(), scheduledDate: scheduledDate,
            createdAtMillis: createdAtMillis, kind: kind, repeatRule: repeatRule,
            repeatWeekdays: repeatWeekdays, reminderAtMillis: reminderAtMillis)
    }
    var nextAnniversaryLabel: String? {
        guard let date = nextAnniversaryDate else { return nil }
        return date.formatted(.dateTime.day().month(.twoDigits))
    }
}

struct FEiOSRootView: View {
    @EnvironmentObject private var store: FEiOSStore
    @Environment(\.scenePhase) private var scenePhase
    @State private var section: FEPage = .day
    @State private var editing: FEEditorID?
    @State private var unlockedProtected: Set<String> = []
    @State private var protectionRevision = 0
    @State private var showBackups = false
    @AppStorage("NorrNote.FE.Language") private var language = "ru"
    @Namespace private var glassNamespace
    @State private var showGoogleDrive = false
    @State private var importing = false
    @State private var searching = false
    @State private var query = ""
    @State private var currentDay = Date()
    @State private var displayedMonth = Date()
    @State private var category = ""
    @State private var info: String?
    // User's chosen display style is shared by all sections and survives restarts.
    @AppStorage("NorrNote.FE.MainCardLayout") private var cardLayout = "rows"

    private var isGlobalSearch: Bool {
        searching && !query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    private var filtered: [FEiOSNote] {
        let candidates: [FEiOSNote]
        if isGlobalSearch {
            let needle = query.trimmingCharacters(in: .whitespacesAndNewlines)
            candidates = store.notes.filter { note in
                !note.deleted && !note.isProtected && !FEPermanentPIN.isProtected(note.id) &&
                (note.title.localizedCaseInsensitiveContains(needle) ||
                 note.body.localizedCaseInsensitiveContains(needle))
            }
        } else {
            switch section {
            case .day, .calendar:
                candidates = store.notes.filter { !$0.deleted && $0.occurs(on: currentDay) }
                    .map { $0.displayed(on: currentDay) }
            case .dates:
                candidates = store.notes.filter { !$0.deleted &&
                    FECalendarEngine.isDateEvent(kind: $0.kind, repeatRule: $0.repeatRule, categoryKey: $0.categoryKey) }
            case .permanent:
                candidates = store.notes.filter { !$0.deleted && $0.kind == "PERMANENT" &&
                    (category.isEmpty || category == $0.categoryKey) }
            case .all: candidates = store.notes.filter { !$0.deleted }
            case .trash: candidates = store.notes.filter { $0.deleted }
            }
        }
        return candidates.sorted { lhs, rhs in
            if !isGlobalSearch && section == .dates {
                let l = lhs.nextAnniversaryDate, r = rhs.nextAnniversaryDate
                if l != r { return (l ?? .distantFuture) < (r ?? .distantFuture) }
            }
            if !isGlobalSearch && (section == .day || section == .calendar) {
                let l = isEvent(lhs)
                let r = isEvent(rhs)
                if l != r { return l }
            }
            if section != .trash && lhs.isCompleted != rhs.isCompleted {
                return !lhs.isCompleted
            }
            return false
        }
    }
    private func isEvent(_ note: FEiOSNote) -> Bool {
        FECalendarEngine.isDateEvent(kind: note.kind, repeatRule: note.repeatRule,
                                     categoryKey: note.categoryKey)
    }
    private var counts: Int { section == .calendar && !isGlobalSearch ? 0 : filtered.count }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                header
                if searching {
                    HStack {
                        Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                        TextField("Поиск по заметкам", text: $query)
                            .textInputAutocapitalization(.never)
                        if !query.isEmpty {
                            Button { query = "" } label: { Image(systemName: "xmark.circle.fill") }
                        }
                    }
                    .padding(12)
                    .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 12))
                    .padding(.horizontal, 16).padding(.bottom, 8)
                }
                screenHeading
                if section == .permanent && !isGlobalSearch { categoryStrip }
                if isGlobalSearch {
                    ScrollView {
                        LazyVStack(spacing: 10) {
                            if filtered.isEmpty { emptyState }
                            ForEach(filtered) { note in
                                if isEvent(note) {
                                    dateCard(note)
                                } else { card(for: note, tiled: false) }
                            }
                        }
                        .padding(.horizontal, 14).padding(.top, 10).padding(.bottom, 94)
                    }
                    .background(Color(.systemGroupedBackground))
                } else if section == .calendar {
                    calendarPane
                } else if section == .dates {
                    datesPane
                } else {
                    ScrollView {
                        Group {
                            if filtered.isEmpty {
                                emptyState
                            } else if cardLayout == "tiles" {
                                LazyVGrid(columns: [GridItem(.flexible(), spacing: 10),
                                                    GridItem(.flexible(), spacing: 10)],
                                          alignment: .center, spacing: 10) {
                                    ForEach(filtered) { note in
                                        if isEvent(note) { dateCard(note) }
                                        else { card(for: note, tiled: true) }
                                    }
                                }
                            } else {
                                LazyVStack(spacing: 10) {
                                    ForEach(filtered) { note in
                                        if section == .day && isEvent(note) {
                                            dateCard(note)
                                        } else { card(for: note, tiled: false) }
                                    }
                                }
                            }
                        }
                        .padding(.horizontal, 14)
                        .padding(.top, 10)
                        .padding(.bottom, 94)
                    }
                    .background(Color(.systemGroupedBackground))
                }
                bottomNavigation
            }
            .background(Color(.systemBackground))
            .overlay(alignment: .bottomTrailing) {
                if section == .dates && !isGlobalSearch {
                    Button {
                        editing = FEEditorID(id: store.create(kind: "BIRTHDAY", day: currentDay))
                    } label: {
                        Label("Добавить дату", systemImage: "plus")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundStyle(FEMintTheme.text)
                            .padding(.horizontal, 20).frame(height: 49)
                            .background(FEMintTheme.button, in: Capsule())
                            .overlay(Capsule().strokeBorder(FEMintTheme.border))
                    }
                    .padding(.trailing, 23).padding(.bottom, 77)
                } else if section != .trash && section != .calendar && !isGlobalSearch {
                    createMenu
                        .padding(.trailing, 23)
                        .padding(.bottom, 77)
                }
            }
            .navigationBarHidden(true)
            .tint(FEMintTheme.accent)
            .environment(\.locale, Locale(identifier:language))
            .onChange(of: section) { _, next in if next == .calendar { displayedMonth = currentDay } }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.json], allowsMultipleSelection: false) { answer in
                do {
                    guard let url = try answer.get().first else { return }
                    let change = try store.importSnapshot(url)
                    info = "Импорт завершён. Изменение количества записей: \(change)."
                } catch { info = "Импорт остановлен: \(error.localizedDescription)" }
            }
            .sheet(isPresented: $showBackups) { FEBackupSettingsView().environmentObject(store) }
            .sheet(isPresented: $showGoogleDrive) {
                FEGoogleDriveSettingsView().environmentObject(store)
            }
            .sheet(item: $editing) { entry in
                if FEPermanentPIN.isProtected(entry.id) && !unlockedProtected.contains(entry.id) {
                    FEPINUnlockView(noteID: entry.id) {
                        unlockedProtected.insert(entry.id)
                    }
                } else if let note = store.notes.first(where: { $0.id == entry.id }), isEvent(note) {
                    FEDateEditor(id: entry.id).environmentObject(store)
                } else {
                    FEAndroidEditor(id: entry.id, onProtectionChanged: {
                        unlockedProtected.insert(entry.id)  // keep editor open until dismissal
                        protectionRevision += 1
                    })
                    .environmentObject(store)
                    .onDisappear {
                        unlockedProtected.remove(entry.id)
                    }
                }
            }
            .alert("NorrNote", isPresented: Binding(get: { info != nil }, set: { if !$0 { info = nil } })) {
                Button("OK") { info = nil }
            } message: { Text(FELanguage.display(info ?? "", language:language)) }
            .onChange(of: store.status) { _, value in if !value.isEmpty { info = value } }
            .onOpenURL { url in openNoteFromWidget(url) }
            .task {
                // Best effort while foregrounded; no simulated background execution.
                applyI3b3vWidgetCompletions()
                store.reconcileElapsedReminders()
                while !Task.isCancelled {
                    do { try await Task.sleep(for: .seconds(20)) }
                    catch { break }
                    if scenePhase == .active { store.reconcileElapsedReminders() }
                }
            }
            .onChange(of: scenePhase) { _, phase in
                if phase == .active {
                    // Reconcile any widget actions made while app was suspended.
                    store.applyPendingWidgetCompletions()
                    applyI3b3vWidgetCompletions()
                    store.reconcileElapsedReminders()
                }
                if phase == .background {
                    unlockedProtected.removeAll()
                    if let opened = editing?.id, FEPermanentPIN.isProtected(opened) {
                        editing = nil
                    }
                }
            }
        }
    }

    // I3b3v: commit interactive widget completions after app activation.
    // Never toggle twice if the note has already been completed for that day.
    // Leave the atomic request in place if the store has not loaded it yet.
    private func applyI3b3vWidgetCompletions() {
        guard let root = FileManager.default.containerURL(
            forSecurityApplicationGroupIdentifier: "group.su.norrvind.norrnote.fe.ios") else { return }
        let directory = root.appendingPathComponent("WidgetCompletionRequests-v1", isDirectory: true)
        guard let files = try? FileManager.default.contentsOfDirectory(
            at: directory, includingPropertiesForKeys: nil) else { return }
        for file in files where file.pathExtension == "json" {
            guard let uuid = UUID(uuidString: file.deletingPathExtension().lastPathComponent),
                  let bytes = try? Data(contentsOf: file),
                  let record = (try? JSONSerialization.jsonObject(with: bytes)) as? [String: Any],
                  let recordID = record["id"] as? String,
                  UUID(uuidString: recordID) == uuid,
                  let atMillis = record["atMillis"] as? NSNumber else { continue }
            let tappedAt = Date(timeIntervalSince1970: atMillis.doubleValue / 1000)
            guard tappedAt <= Date().addingTimeInterval(120),
                  tappedAt >= Date().addingTimeInterval(-90 * 86400) else { continue }
            guard let note = store.notes.first(where: { $0.id.lowercased() == recordID }) else {
                continue // Note may still be loading; do not lose the user's action.
            }
            if note.deleted || isEvent(note) {
                try? FileManager.default.removeItem(at: file)
                continue
            }
            if !note.displayed(on: tappedAt).isCompleted {
                store.toggleCompleted(note.id, on: tappedAt)
            }
            if store.notes.first(where: { $0.id == note.id })?
                .displayed(on: tappedAt).isCompleted == true {
                try? FileManager.default.removeItem(at: file)
            }
        }
    }

    // Widget I2v: only an exact widget new-note link can create a note.
    // UUID note links keep the original I2s validation and PIN protections.
    private func openNoteFromWidget(_ url: URL) {
        guard url.scheme?.lowercased() == "norrnote21fe" else { return }
        if url.host?.lowercased() == "new" && (url.path.isEmpty || url.path == "/") &&
           url.query == nil && url.fragment == nil && url.user == nil && url.password == nil {
            section = .day
            currentDay = Date()
            editing = FEEditorID(id: store.create(kind: "TEXT", day: currentDay))
            return
        }
        guard url.host?.lowercased() == "note",
              url.pathComponents.count == 2,
              let uuid = UUID(uuidString: url.lastPathComponent)?.uuidString.lowercased(),
              let note = store.notes.first(where: {
                  $0.id.lowercased() == uuid && !$0.deleted
              }) else { return }
        editing = FEEditorID(id: note.id)
    }

    private func card(for note: FEiOSNote, tiled: Bool) -> some View {
        // protectionRevision is intentionally read to refresh local Keychain state
        // after PIN changes without editing Sync21 data.
        let _ = protectionRevision
        return FENoteCard(note: note, tiled: tiled,
                   locked: FEPermanentPIN.isProtected(note.id),
                   open: { editing = FEEditorID(id: note.id) },
                   complete: { store.toggleCompleted(note.id, on: (section == .day || section == .calendar) ? currentDay : Date()) },
                   delete: { store.trash(note.id) },
                   restore: { store.restore(note.id) })
    }

    private var header: some View {
        HStack(spacing: 12) {
            HStack(spacing: 9) {
                Group {
                    if UIImage(named: "NorrNoteShip") != nil {
                        Image("NorrNoteShip").resizable().scaledToFit()
                    } else {
                        // Exact Android icon not present yet: no invented replacement image.
                        Image(systemName: "sailboat").resizable().scaledToFit()
                    }
                }
                .frame(width: 27, height: 27)
                Text("NorrNote")
                    .font(.system(size: 22, weight: .bold, design: .rounded))
                    .foregroundStyle(Color.primary)
            }
            Spacer()
            if section == .day || section == .permanent || section == .all || section == .trash {
                Button {
                    cardLayout = cardLayout == "tiles" ? "rows" : "tiles"
                } label: {
                    Image(systemName: cardLayout == "tiles" ? "list.bullet" : "square.grid.2x2")
                        .font(.system(size: 19, weight: .medium))
                        .frame(width: 38, height: 38)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(cardLayout == "tiles" ? "Показать списком" : "Показать плиткой")
                .accessibilityIdentifier("FEMain.LayoutToggle")
            }
            Button { searching.toggle(); if !searching { query = "" } } label: {
                Image(systemName: searching ? "xmark" : "magnifyingglass")
                    .font(.system(size: 19, weight: .medium))
                    .frame(width: 38, height: 38)
            }
            .accessibilityLabel(searching ? "Закрыть поиск" : "Поиск")
            Menu {
                Button { section = .trash } label: { Label("Корзина", systemImage: "trash") }
                Divider()
                Button { showBackups = true } label: { Label("Резервные копии", systemImage: "externaldrive") }
                #if DEBUG
                // I3b3l: debug-only widget diagnostics, no note text leaves device.
                Button { info = store.widgetDiagnostics() } label: {
                    Label("Проверить виджет", systemImage: "stethoscope")
                }
                #endif
                Menu {
                    Button("Русский") { language = "ru" }
                    Button("English") { language = "en" }
                    Button("Deutsch") { language = "de" }
                } label: { Label("Выбор языка", systemImage: "globe") }
            } label: {
                Image(systemName: "ellipsis.circle")
                    .font(.system(size: 22))
                    .frame(width: 38, height: 38)
            }
            .accessibilityLabel("Дополнительно")
        }
        .foregroundStyle(Color.primary)
        .padding(.leading, 17)
        .padding(.trailing, 12)
        .padding(.vertical, 8)
    }

    private var screenHeading: some View {
        ZStack {
            HStack {
                VStack(alignment:.leading,spacing:3) {
                    Text(LocalizedStringKey(isGlobalSearch ? "Поиск по всей базе" : section.title))
                        .font(.system(size:27,weight:.bold,design:.rounded))
                    if section != .calendar {
                        Text(FELanguage.display("Записей:", language:language) + " \(counts)")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
                Spacer(minLength:0)
                if section == .day {
                    Button("Сегодня") { currentDay = Date() }
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(FEMintTheme.text)
                        .padding(.horizontal,10)
                        .frame(height:32)
                        .background(FEMintTheme.button,in:Capsule())
                        .overlay(Capsule().strokeBorder(FEMintTheme.border,lineWidth:1))
                        .buttonStyle(.plain)
                        .accessibilityIdentifier("FEMain.Today")
                }
            }
            if section == .day {
                HStack(spacing:9) {
                    Button { currentDay = Calendar.current.date(byAdding:.day,value:-1,to:currentDay) ?? currentDay }
                        label: { Image(systemName:"chevron.left") }
                    Text(currentDay.formatted(.dateTime.day().month(.abbreviated).locale(Locale(identifier:language))))
                        .font(.subheadline.weight(.semibold))
                        .monospacedDigit()
                        .lineLimit(1)
                        .minimumScaleFactor(0.85)
                    Button { currentDay = Calendar.current.date(byAdding:.day,value:1,to:currentDay) ?? currentDay }
                        label: { Image(systemName:"chevron.right") }
                }
                .frame(maxWidth:.infinity)
                .allowsHitTesting(true)
            }
        }
        .foregroundStyle(Color.primary)
        .padding(.horizontal,17)
        .padding(.vertical,9)
    }

    // Only UI representations; the single source note remains in local-notes.json / Sync21.
    private var calendarPane: some View {
        ScrollView {
            VStack(spacing: 15) {
                FECalendarMonthGrid(month: $displayedMonth, selected: $currentDay,
                                    notes: store.notes, language: language,
                                    onSelect: { section = .day })
                HStack(spacing: 9) {
                    Circle().fill(FEMintTheme.accent).frame(width: 7, height: 7)
                    Text("Заметки")
                    Circle().fill(.orange).frame(width: 7, height: 7)
                    Text("Напоминания")
                    Circle().fill(.purple).frame(width: 7, height: 7)
                    Text("Даты")
                    Spacer(minLength: 0)
                }
                .font(.caption2).foregroundStyle(.secondary)
                .padding(.horizontal, 5)
                HStack {
                    Text("Нажмите на число, чтобы открыть этот день")
                        .font(.caption).foregroundStyle(.secondary)
                    Spacer()
                    Button("Сегодня") { currentDay = Date(); displayedMonth = Date() }
                        .font(.subheadline.weight(.medium))
                }
                .padding(.horizontal, 5)
            }
            .padding(.horizontal, 14)
            .padding(.top, 10)
            .padding(.bottom, 94)
        }
        .background(Color(.systemGroupedBackground))
    }

    private func dateCard(_ note: FEiOSNote) -> some View {
        let subtype = FECalendarEngine.dateSubtype(kind: note.kind,
                                  repeatRule: note.repeatRule, categoryKey: note.categoryKey)
        let icons = ["birthday":"birthday.cake", "wedding":"heart.fill",
                     "anniversary":"calendar.badge.clock", "other":"bookmark.fill"]
        let yearKnown = FECalendarEngine.yearKnown(note.categoryKey)
        let occurs = section == .day ? currentDay : (note.nextAnniversaryDate ?? Date())
        let birthYear = Int(note.scheduledDate.prefix(4)) ?? 0
        let age = subtype == "birthday" && yearKnown && birthYear > 0 ?
                  max(0, Calendar.current.component(.year, from: occurs) - birthYear) : 0
        let showAge = subtype == "birthday" && yearKnown && birthYear > 0
        let label = note.title.isEmpty ? "Без названия" : note.title
        let dateLabel = FEEventDateFormatter.label(note.scheduledDate, yearKnown: yearKnown)
        return Button { editing = FEEditorID(id: note.id) } label: {
            HStack(spacing: 11) {
                Image(systemName: icons[subtype] ?? "calendar")
                    .font(.system(size: 19))
                    .foregroundStyle(FEMintTheme.accent)
                    .frame(width: 25)
                VStack(alignment: .leading, spacing: 2) {
                    HStack(spacing: 4) {
                        Text(label).font(.system(size: 15, weight: .semibold))
                        if showAge {
                            Text("— \(age) \(FELanguage.display("лет", language: language))")
                                .font(.system(size: 13, weight: .medium))
                        }
                    }.lineLimit(2)
                    Text(dateLabel).font(.caption).foregroundStyle(.secondary)
                }
                .foregroundStyle(.primary)
                Spacer(minLength: 0)
                Image(systemName: "chevron.right")
                    .font(.caption).foregroundStyle(.tertiary)
            }
            .padding(.horizontal, 13)
            .padding(.vertical, 7)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(.secondarySystemGroupedBackground),
                        in: RoundedRectangle(cornerRadius: 15))
            .contentShape(RoundedRectangle(cornerRadius: 15))
        }.buttonStyle(.plain)
    }

    private var datesPane: some View {
        ScrollView {
            LazyVStack(spacing: 8) {
                if filtered.isEmpty {
                    Text("Пока нет памятных дат")
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, minHeight: 120)
                } else {
                    ForEach(filtered) { note in dateCard(note) }
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 12)
            .padding(.bottom, 86)
        }
        .background(Color(.systemGroupedBackground))
    }

    private var categoryStrip: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                categoryPill("Все", key: "")
                ForEach(FECategory.base) { item in categoryPill(item.title, key: item.id) }
            }
            .padding(.horizontal, 16)
        }
        .padding(.vertical, 6)
    }
    private func categoryPill(_ title: String, key: String) -> some View {
        Button { category = key } label: {
            Text(LocalizedStringKey(title))
                .font(.subheadline.weight(category == key ? .semibold : .regular))
                .padding(.horizontal, 13).padding(.vertical, 8)
                .foregroundStyle(category == key ? Color.white : Color.primary)
                .background(category == key ? FEMintTheme.accent : Color(.secondarySystemGroupedBackground),
                            in: Capsule())
        }
        .buttonStyle(.plain)
    }

    // SwiftUI Liquid Glass on iOS 26, translucent matched pill on iOS 17–25.
    // The matched geometry animates a single fluid selected background.
    private var bottomNavigation: some View {
        HStack(spacing: 1) {
            ForEach([FEPage.day, .calendar, .permanent, .dates], id: \.rawValue) { tab in
                Button {
                    section = tab
                    category = ""
                } label: {
                    VStack(spacing: 3) {
                        Image(systemName:tab.symbol).font(.system(size:20,weight:.medium))
                        Text(LocalizedStringKey(tab.title))
                            .font(.system(size:11,weight:section == tab ? .semibold : .medium))
                    }
                    .frame(maxWidth:.infinity)
                    .frame(height:58)
                    .foregroundStyle(section == tab ? FEMintTheme.accent : Color.secondary)
                    .background {
                        if section == tab {
                            if #available(iOS 26.0, *) {
                                Capsule()
                                    .fill(Color.clear)
                                    .glassEffect(.regular, in:Capsule())
                                    .matchedGeometryEffect(id:"activeGlass",in:glassNamespace)
                            } else {
                                Capsule()
                                    .fill(.ultraThinMaterial)
                                    .overlay(Capsule().strokeBorder(.white.opacity(0.5)))
                                    .matchedGeometryEffect(id:"activeGlass",in:glassNamespace)
                            }
                        }
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityAddTraits(section == tab ? .isSelected : [])
            }
        }
        .padding(.horizontal,8)
        .padding(.vertical,5)
        .background(.regularMaterial)
        .animation(.spring(response:0.38,dampingFraction:0.72),value:section)
        .overlay(alignment:.top) {
            Rectangle().fill(Color.gray.opacity(0.15)).frame(height:0.5)
        }
    }

    private var createMenu: some View {
        Menu {
            ForEach(FENoteType.allCases) { item in
                Button {
                    let uid = store.create(kind: item.rawValue, day: currentDay)
                    editing = FEEditorID(id: uid)
                } label: { Label(item == .birthday ? "Дата" : item.title, systemImage: item.symbol) }
            }
        } label: {
            Label("Добавить", systemImage: "plus")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(FEMintTheme.text)
                .padding(.horizontal, 20)
                .frame(height: 49)
                .background(FEMintTheme.button, in: Capsule())
                .overlay(Capsule().strokeBorder(FEMintTheme.border, lineWidth: 1))
                .shadow(color: .black.opacity(0.10), radius: 5, y: 2)
        }
        .accessibilityLabel("Добавить заметку, список или дату")
    }
    private var emptyState: some View {
        VStack(spacing: 13) {
            Image(systemName: section == .trash ? "trash" : section.symbol)
                .font(.system(size: 39, weight: .light))
                .foregroundStyle(.secondary)
            Text(section == .trash ? "Корзина пуста" : "Здесь пока нет записей")
                .font(.title3.weight(.semibold))
            Text(section == .trash ? "Удалённые заметки появятся здесь." :
                    "Создайте заметку с помощью кнопки +")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            if section != .trash && store.notes.isEmpty {
                Button("Создать первую заметку") {
                    editing = FEEditorID(id: store.create(day: currentDay))
                }.buttonStyle(.borderedProminent)
                Button("Добавить 3 тестовые заметки") {
                    let added = store.addDemoNotes()
                    section = .all
                    info = added > 0 ? "Добавлены тестовые заметки." : "Тестовые заметки уже созданы."
                }.buttonStyle(.bordered)
            }
        }
        .padding(.horizontal, 16)
        .frame(maxWidth: .infinity)
        .padding(.vertical, 55)
    }
}

// Six calendar weeks keep the interface stable when switching months.
private struct FECalendarMonthGrid: View {
    @Binding var month: Date
    @Binding var selected: Date
    let notes: [FEiOSNote]
    let language: String
    let onSelect: () -> Void

    private let cal = Calendar.current
    private let columns = Array(repeating: GridItem(.flexible(), spacing: 2), count: 7)
    private var first: Date {
        let components = cal.dateComponents([.year, .month], from: month)
        return cal.date(from: components) ?? cal.startOfDay(for: month)
    }
    private var offset: Int { (cal.component(.weekday, from: first) + 5) % 7 }
    private var weekdayNames: [String] {
        let index = [2,3,4,5,6,7,1]
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: language)
        return index.map { formatter.veryShortStandaloneWeekdaySymbols[$0 - 1] }
    }

    var body: some View {
        VStack(spacing: 9) {
            HStack {
                Button { move(-1) } label: { Image(systemName: "chevron.left") }
                    .accessibilityLabel("Предыдущий месяц")
                Spacer()
                Text(first.formatted(.dateTime.month(.wide).year().locale(Locale(identifier: language))))
                    .font(.system(size: 18, weight: .semibold, design: .rounded))
                Spacer()
                Button { move(1) } label: { Image(systemName: "chevron.right") }
                    .accessibilityLabel("Следующий месяц")
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            LazyVGrid(columns: columns, spacing: 4) {
                ForEach(0..<7, id: \.self) { index in
                    Text(weekdayNames[index]).font(.caption2.weight(.medium))
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity)
                }
                ForEach(0..<42, id: \.self) { index in
                    let dayIndex = index - offset
                    if let date = cal.date(byAdding: .day, value: dayIndex, to: first),
                       cal.isDate(date, equalTo: first, toGranularity: .month) {
                        Button {
                            selected = date
                            onSelect()
                        } label: {
                            VStack(spacing: 3) {
                                Text("\(cal.component(.day, from: date))")
                                    .font(.subheadline.weight(cal.isDate(date, inSameDayAs: selected) ? .bold : .regular))
                                    .foregroundStyle(cal.isDate(date, inSameDayAs: selected) ? FEMintTheme.accent : Color.primary)
                                HStack(spacing: 2) {
                                    ForEach(0..<3, id: \.self) { dot in
                                        Circle().fill(dotColor(for: date, at: dot))
                                            .frame(width: 4, height: 4)
                                    }
                                }
                            }
                            .frame(maxWidth: .infinity, minHeight: 40)
                            .background(cal.isDate(date, inSameDayAs: selected) ? FEMintTheme.button.opacity(0.68) : Color.clear,
                                        in: RoundedRectangle(cornerRadius: 10))
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel(date.formatted(.dateTime.day().month(.wide).year()
                            .locale(Locale(identifier: language))))
                    } else {
                        Color.clear.frame(height: 40)
                    }
                }
            }
        }
        .padding(13)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 21))
    }
    private func move(_ months: Int) {
        guard let shifted = cal.date(byAdding: .month, value: months, to: first) else { return }
        month = shifted
    }
    private func dotColor(for date: Date, at index: Int) -> Color {
        var hasDate = false, hasReminder = false, hasOrdinary = false
        for note in notes where !note.deleted {
            guard note.occurs(on: date) else { continue }
            if FECalendarEngine.isDateEvent(kind: note.kind, repeatRule: note.repeatRule, categoryKey: note.categoryKey) { hasDate = true }
            else if note.hasReminder || note.kind == "REMINDER" { hasReminder = true }
            else { hasOrdinary = true }
            if hasDate && hasReminder && hasOrdinary { break }
        }
        let colors: [Color] = [hasDate ? .purple : .clear,
                               hasReminder ? .orange : .clear,
                               hasOrdinary ? FEMintTheme.accent : .clear]
        return colors[index]
    }
}

private struct FENoteCard: View {
    let note: FEiOSNote
    let tiled: Bool
    let locked: Bool
    let open: () -> Void
    let complete: () -> Void
    let delete: () -> Void
    let restore: () -> Void

    private var kind: FENoteType { FENoteType(rawValue: note.kind) ?? .text }
    private var cardTextColor: Color { note.isCompleted ? .gray : FEAndroidPalette.ink(note.colorIndex) }
    private var noteTitle: String {
        locked ? "Защищённая заметка" : (note.title.isEmpty ? "Без названия" : note.title)
    }

    var body: some View {
        HStack(alignment: .center, spacing: 6) {
            Button(action: open) {
                VStack(alignment: .leading, spacing: 2) {
                    HStack(spacing: 5) {
                        Image(systemName: kind.symbol)
                        Text(LocalizedStringKey(kind.title)).lineLimit(1)
                        if !locked && kind == .permanent && !note.categoryKey.isEmpty {
                            Image(systemName: FECategory.symbol(note.categoryKey))
                                .accessibilityLabel("Категория")
                        }
                        // One large lock only, in the same metadata row as picture/file.
                        if locked {
                            Image(systemName: "lock.fill")
                                .font(.system(size: 15, weight: .semibold))
                                .accessibilityLabel("PIN")
                        } else {
                            if note.hasImage { Image(systemName: "photo").accessibilityLabel("Есть изображение") }
                            if note.hasFile { Image(systemName: "doc").accessibilityLabel("Есть файл") }
                            if note.hasReminder { Image(systemName: "alarm").accessibilityLabel("Активное напоминание") }
                            if note.isRepeating { Image(systemName: "repeat") }
                            if note.isImportant { Image(systemName: "star.fill").foregroundStyle(.orange) }
                        }
                        Spacer(minLength: 0)
                    }
                    .font(.system(size: tiled ? 10 : 12, weight: .semibold))
                    .foregroundStyle(cardTextColor.opacity(0.86))

                    Text(LocalizedStringKey(noteTitle))
                        .font(.system(size: tiled ? 15 : 16, weight: .semibold))
                        .foregroundStyle(cardTextColor)
                        .strikethrough(note.isCompleted && !locked, color:.gray)
                        .lineLimit(tiled ? 3 : 2)
                    if locked {
                        Text("Нажмите для ввода PIN").font(.caption)
                            .foregroundStyle(cardTextColor.opacity(0.7))
                    } else if kind == .list && note.checklistCount > 0 {
                        Text("Выполнено \(note.checklistDone) из \(note.checklistCount)")
                            .font(.caption).foregroundStyle(cardTextColor.opacity(0.7)).lineLimit(1)
                    } else if !note.body.isEmpty {
                        Text(note.body).font(.caption).lineLimit(tiled ? 3 : 2)
                            .foregroundStyle(cardTextColor.opacity(0.7))
                    }
                }
                .frame(maxWidth:.infinity,alignment:.leading)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel(locked ? "Открыть защищённую заметку" : "Открыть заметку: \(note.title)")

            if !locked {
                VStack(spacing: 3) {
                    if !note.deleted {
                        Button(action: complete) {
                            ZStack {
                                Circle().fill(Color.white.opacity(0.08))
                                    .overlay(Circle().strokeBorder(note.isCompleted ? Color.gray.opacity(0.7) : cardTextColor.opacity(0.75),lineWidth:1.6))
                                if note.isCompleted {
                                    Image(systemName:"checkmark")
                                        .font(.system(size:14,weight:.semibold))
                                        .foregroundStyle(.gray)
                                }
                            }
                            .frame(width:27,height:27)
                            .frame(width:38,height:38)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel(note.isCompleted ? "Снять выполнение" : "Выполнено")
                    }
                    Button(role: note.deleted ? nil : .destructive,
                           action: note.deleted ? restore : delete) {
                        Image(systemName:note.deleted ? "arrow.uturn.backward" : "trash")
                            .font(.system(size:15))
                            .frame(width:38,height:38)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel(note.deleted ? "Вернуть" : "В корзину")
                }
                .frame(width:38)
                .foregroundStyle(cardTextColor)
            }
        }
        .padding(.horizontal,tiled ? 9 : 11)
        .padding(.vertical,3)
        .frame(maxWidth:.infinity, minHeight:tiled ? 80 : nil,alignment:.leading)
        .background(note.isCompleted ? Color(.systemGray5) : FEAndroidPalette.color(note.colorIndex),
                    in:RoundedRectangle(cornerRadius:16))
        .overlay(RoundedRectangle(cornerRadius:16)
            .strokeBorder(note.isCompleted ? Color.gray.opacity(0.18) : Color.black.opacity(0.06)))
        .saturation(note.isCompleted ? 0 : 1)
        .contextMenu {
            if locked { Button("Открыть с PIN",action:open) }
            else if note.deleted { Button("Восстановить",action:restore) }
            else {
                Button(LocalizedStringKey(note.isCompleted ? "Снять выполнение" : "Выполнено"),action:complete)
                Button(role:.destructive,action:delete) { Label("В корзину",systemImage:"trash") }
            }
        }
        .accessibilityIdentifier(tiled ? "FENoteCard.Tile" : "FENoteCard.Row")
    }
}

private struct FEEditorID: Identifiable { let id: String }
private struct FEDraftItem: Identifiable {
    let id: String
    var title: String
    var done: Bool
}

// This surface must remain independent of the selected card colour.
private enum FEEditorSurface {
    static let paleGray = Color(.sRGB, red: 0.951, green: 0.958, blue: 0.962, opacity: 1)
}

// I3b.2: date-only editor. Writes through the existing FE/Sync21 v2 store.
private enum FEEventDateFormatter {
    static func label(_ wire: String, yearKnown: Bool) -> String {
        let parts = wire.split(separator: "-")
        guard parts.count == 3 else { return wire }
        if yearKnown { return "\(parts[2]).\(parts[1]).\(parts[0])" }
        return "\(parts[2]).\(parts[1])"
    }
}

private enum FEDateKind: String, CaseIterable, Identifiable {
    case birthday, wedding, anniversary, other
    var id: String { rawValue }
    var title: String {
        switch self {
        case .birthday: return "День рождения"
        case .wedding: return "Свадьба"
        case .anniversary: return "Памятная дата"
        case .other: return "Другое"
        }
    }
    var symbol: String {
        switch self {
        case .birthday: return "birthday.cake"
        case .wedding: return "heart.fill"
        case .anniversary: return "calendar.badge.clock"
        case .other: return "bookmark.fill"
        }
    }
}

private struct FEDateEditor: View {
    @EnvironmentObject private var store: FEiOSStore
    @Environment(\.dismiss) private var dismiss
    let id: String
    @State private var subtype: FEDateKind = .birthday
    @State private var title = ""
    @State private var eventDate = Date()
    @State private var yearKnown = false
    @State private var eventMonth = Calendar.current.component(.month, from: Date())
    @State private var eventDay = Calendar.current.component(.day, from: Date())
    @AppStorage("NorrNote.FE.Language") private var language = "ru"
    @State private var annual = true
    @State private var sound = true
    @State private var alarmTime = Calendar.current.date(from:
        DateComponents(year: 2000, month: 1, day: 1, hour: 9, minute: 0)) ?? Date()
    @State private var playCount = 1
    @State private var error: String?
    @State private var confirmDelete = false
    var body: some View {
        NavigationStack {
            Form {
                Section("Тип события") {
                    HStack(spacing: 8) {
                        ForEach(FEDateKind.allCases) { item in
                            Button {
                                subtype = item
                            } label: {
                                VStack(spacing: 5) {
                                    Image(systemName: item.symbol).font(.system(size: 22))
                                    Text(LocalizedStringKey(item.title)).font(.system(size: 10))
                                        .lineLimit(1).minimumScaleFactor(0.75)
                                }
                                .frame(maxWidth: .infinity).frame(height: 58)
                                .foregroundStyle(subtype == item ? FEMintTheme.accent : .secondary)
                                .background(subtype == item ? FEMintTheme.button : Color.clear,
                                    in: RoundedRectangle(cornerRadius: 12))
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel(LocalizedStringKey(item.title))
                        }
                    }
                }
                Section("Событие") {
                    TextField("Имя или название события", text: $title)
                        .textInputAutocapitalization(.words)
                    if yearKnown {
                        DatePicker("Дата события", selection: $eventDate,
                                   displayedComponents: .date)
                    } else {
                        Picker("Месяц", selection: $eventMonth) {
                            ForEach(1...12, id: \.self) { month in
                                Text(monthNames[month - 1]).tag(month)
                            }
                        }
                        Picker("День", selection: $eventDay) {
                            ForEach(1...daysInMonth, id: \.self) { day in
                                Text("\(day)").tag(day)
                            }
                        }
                        Text("Год не указан")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Toggle("Год известен", isOn: $yearKnown)
                        .tint(FEMintTheme.accent)
                        .onChange(of: yearKnown) { _, known in
                            if !known {
                                eventMonth = Calendar.current.component(.month, from: eventDate)
                                eventDay = Calendar.current.component(.day, from: eventDate)
                            }
                        }
                    .onChange(of: eventMonth) { _, _ in
                        eventDay = min(eventDay, daysInMonth)
                    }
                    .onChange(of: eventDate) { _, newDate in
                        eventMonth = Calendar.current.component(.month, from: newDate)
                        eventDay = Calendar.current.component(.day, from: newDate)
                    }
                    Toggle("Повторять ежегодно", isOn: $annual)
                        .tint(FEMintTheme.accent)
                }
                Section("Напоминание") {
                    Toggle("Звуковое напоминание", isOn: $sound)
                        .tint(FEMintTheme.accent)
                    if sound {
                        DatePicker("Время сигнала", selection: $alarmTime,
                                   displayedComponents: .hourAndMinute)
                        Picker("Повторить звук", selection: $playCount) {
                            Text("1 раз").tag(1)
                            Text("3 раза").tag(3)
                            Text("5 раз").tag(5)
                        }
                    }
                }
                Section {
                    Button(role: .destructive) { confirmDelete = true } label: {
                        Label("Переместить в корзину", systemImage: "trash")
                    }
                }
            }
            .navigationTitle("Памятная дата")
            .navigationBarTitleDisplayMode(.inline)
            .tint(FEMintTheme.accent)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { save() }.fontWeight(.semibold)
                }
            }
            .onAppear(perform: load)
            .alert("Не удалось сохранить", isPresented:
                Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                Button("OK") { error = nil }
            } message: { Text(error ?? "") }
            .confirmationDialog("Удалить дату?", isPresented: $confirmDelete) {
                Button("В корзину", role: .destructive) {
                    store.trash(id); dismiss()
                }
                Button("Отмена", role: .cancel) {}
            }
        }
    }
    private var monthNames: [String] {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: language)
        return formatter.monthSymbols
    }
    private var daysInMonth: Int {
        let cal = Calendar(identifier: .gregorian)
        let date = cal.date(from: DateComponents(year: 2000, month: eventMonth, day: 1)) ?? Date()
        return cal.range(of: .day, in: .month, for: date)?.count ?? 28
    }
    private func load() {
        guard let row = store.record(id) else { return }
        title = row["title"] as? String ?? ""
        let type = FECalendarEngine.dateSubtype(kind: row["type"] as? String ?? "BIRTHDAY",
                repeatRule: row["repeatRule"] as? String ?? "",
                categoryKey: row["categoryKey"] as? String ?? "")
        subtype = FEDateKind(rawValue: type) ?? .birthday
        let key = row["categoryKey"] as? String ?? ""
        yearKnown = key.isEmpty ? !title.isEmpty : FECalendarEngine.yearKnown(key)
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.dateFormat = "yyyy-MM-dd"
        eventDate = formatter.date(from: row["scheduledDate"] as? String ?? "") ?? Date()
        eventMonth = Calendar.current.component(.month, from: eventDate)
        eventDay = Calendar.current.component(.day, from: eventDate)
        annual = (row["repeatRule"] as? String ?? "").uppercased() != "NONE"
        sound = FEiOSWire.time(row["reminderAtMillis"]) != nil
        if let millis = FEiOSWire.time(row["reminderAtMillis"]) {
            alarmTime = Date(timeIntervalSince1970: Double(millis) / 1000)
        }
        playCount = (row["feReminderPlayCount"] as? NSNumber)?.intValue ?? 1
    }
    private func save() {
        do {
            var effectiveDate = eventDate
            if !yearKnown {
                var cal = Calendar(identifier: .gregorian)
                cal.timeZone = .current
                guard let chosen = cal.date(from:
                    DateComponents(year: 2000, month: eventMonth, day: eventDay)) else {
                    self.error = "Некорректная дата"; return
                }
                effectiveDate = chosen
            }
            try store.saveDateEvent(id, title: title, subtype: subtype.rawValue,
                eventDate: effectiveDate, yearKnown: yearKnown, annual: annual,
                notify: sound, alarmTime: alarmTime, playCount: playCount)
            dismiss()
        } catch { self.error = error.localizedDescription }
    }
}

private struct FEAndroidEditor: View {
    @EnvironmentObject private var store: FEiOSStore
    @Environment(\.dismiss) private var dismiss
    let id: String
    let onProtectionChanged: () -> Void
    @State private var title = ""
    @State private var bodyText = ""
    @State private var richHTML = ""
    @State private var formatSequence = 0
    @State private var formatCommand: FERichCommand = .bold
    @State private var color = 0
    @State private var important = false
    @State private var completed = false
    @State private var kind = FENoteType.text
    @State private var category = ""
    @State private var scheduledDay = Date()
    @State private var checklist: [FEDraftItem] = []
    @State private var confirmChecklist = false
    @StateObject private var voice = FEVoiceInput()
    @State private var voiceStartText = ""
    @State private var pinProtected = false
    @State private var pinMode: FEPINMode?
    @State private var photo: PhotosPickerItem?
    @State private var importingAttachment = false
    @State private var previewAttachment: URL?
    @State private var attachments: [[String: Any]] = []
    @State private var reminderDate = Date().addingTimeInterval(3600)
    @State private var repeats = 1
    @State private var notifyEnabled = false
    @State private var localError: String?
    @State private var showingParameters = false
    // I3b3u: load the record ONCE. onAppear fires again after full-screen
    // pickers (Files, Quick Look, photos) and used to overwrite unsaved edits
    // (title, text, date, time) with the stored copy.
    @State private var didLoad = false
    // I3b3u: every way of closing saves, except an explicit "Отмена" or trash.
    @State private var discardOnClose = false
    @FocusState private var focusedItemID: String?
    var body: some View {
        NavigationStack {
            ScrollView {
                // Four full-width, independent editor surfaces. Their sequence is deliberate:
                // note colour → pale grey text → note colour controls → pale grey footer.
                VStack(spacing: 0) {
                    titleBand
                    textBand
                    inputActionsBand
                }
                .frame(maxWidth: .infinity)
            }
            .scrollDismissesKeyboard(.interactively)
            // Also paints the home-indicator safe area when the content is short.
            .background(FEEditorSurface.paleGray.ignoresSafeArea())
            // Navigation bar belongs to the first colour band.
            .toolbarBackground(FEAndroidPalette.color(color), for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarColorScheme(FEAndroidPalette.isDark(color) ? .dark : .light, for: .navigationBar)
            .tint(FEAndroidPalette.isDark(color) ? Color.white : FEMintTheme.accent)
            .navigationTitle(kind.title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { discardOnClose = true; dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { save(); dismiss() }.fontWeight(.semibold)
                }
            }
            .onAppear {
                guard !didLoad else { return }
                didLoad = true
                load()
            }
            .onChange(of: store.status) { _, message in
                if !message.isEmpty { localError = message }
            }
            .onDisappear {
                voice.stop()
                // Swipe-down, the parameters "×" followed by a swipe, or a cover
                // by a system picker: keep the edits. saveDraft is a no-op when
                // nothing changed, so a second call after "Готово" is harmless.
                if !discardOnClose { save() }
            }
            .onChange(of: voice.transcript) { _, transcript in
                // Speech partial results can revise previously recognised words.
                // Recompose from the state at recording start to avoid duplicates.
                if !transcript.isEmpty {
                    let separator = voiceStartText.isEmpty || voiceStartText.hasSuffix(" ") ? "" : " "
                    bodyText = voiceStartText + separator + transcript
                }
            }
            .sheet(isPresented: $showingParameters) { parametersSheet }
            .onChange(of: photo) { _, next in
                guard let next else { return }
                Task {
                    do {
                        guard let content = try await next.loadTransferable(type: Data.self) else { return }
                        let type = next.supportedContentTypes.first
                        let ext = type?.preferredFilenameExtension ?? "bin"
                        let mime = type?.preferredMIMEType ?? "application/octet-stream"
                        try store.addAttachment(id, data: content,
                                                filename: "Изображение-\(UUID().uuidString.prefix(8)).\(ext)",
                                                mime: mime)
                        attachments = store.attachmentMetadata(id)
                    } catch { localError = error.localizedDescription }
                }
            }
            .fileImporter(isPresented: $importingAttachment,
                          allowedContentTypes: [.item], allowsMultipleSelection: false) { result in
                do {
                    guard let url = try result.get().first else { return }
                    try store.addAttachmentFromFile(id, url: url)
                    attachments = store.attachmentMetadata(id)
                } catch { localError = error.localizedDescription }
            }
            .quickLookPreview($previewAttachment)
            .alert("Не удалось выполнить действие", isPresented: Binding(
                get: { localError != nil }, set: { if !$0 { localError = nil } })) {
                Button("OK") { localError = nil }
            } message: { Text(localError ?? "") }
            .alert("Пометить список как выполненный?", isPresented: $confirmChecklist) {
                Button("Да") { completed = true }
                Button("Нет", role: .cancel) { }
            } message: { Text("Все пункты списка отмечены.") }
        }
    }

    // I2c: note colour extends through the entire title block (not the text editor).
    private var titleBand: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text("Название заметки")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(FEAndroidPalette.ink(color))
            TextField("Название заметки", text: $title, prompt: Text("Название заметки").foregroundColor(FEAndroidPalette.ink(color).opacity(0.64)))
                .font(.system(size: 17))
                .foregroundStyle(FEAndroidPalette.ink(color))
                .padding(.horizontal, 13)
                .frame(height: 48)
                .background(FEAndroidPalette.isDark(color) ? Color.black.opacity(0.23) : Color.white.opacity(0.60), in: RoundedRectangle(cornerRadius: 12))
                .accessibilityIdentifier("FEEditor.Title")
        }
        .padding(.horizontal, 17)
        .padding(.top, 17)
        .padding(.bottom, 18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(FEAndroidPalette.color(color))
        .animation(.easeInOut(duration: 0.16), value: color)
    }

    // Dedicated pale-grey field for the note contents or checklist.
    private var textBand: some View {
        VStack(alignment: .leading, spacing: 7) {
            if kind == .list {
                Text("Пункты списка")
                    .font(.caption.weight(.medium))
                    .foregroundStyle(Color.black.opacity(0.66))
                listEditor
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .frame(minHeight: 184, alignment: .top)
            } else {
                FERichTextEditor(text: $bodyText, richHTML: $richHTML,
                                 command: formatCommand, sequence: formatSequence)
                    .frame(height: 225)
                    .accessibilityLabel("Редактор заметки")
                    .accessibilityIdentifier("FEEditor.Body")
                HStack(spacing: 8) {
                    formatButton("Ж", icon: "bold", action: .bold, hint: "Жирный")
                    formatButton("К", icon: "italic", action: .italic, hint: "Курсив")
                    formatButton("Ч", icon: "underline", action: .underline, hint: "Подчёркнутый")
                    formatButton("З", icon: "strikethrough", action: .strike, hint: "Зачёркнутый")
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.top, 5)
            }
            attachmentBlock
        }
        .padding(.horizontal, 17)
        .padding(.top, 15)
        .padding(.bottom, 16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(FEEditorSurface.paleGray)
    }

    private var attachmentBlock: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Вложения")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(Color.black)
            if attachments.isEmpty {
                Text("Вложений нет")
                    .font(.caption)
                    .foregroundStyle(Color.black.opacity(0.58))
            }
            ForEach(attachments.indices, id: \.self) { index in
                HStack(spacing: 11) {
                    Button {
                        let item = attachments[index]
                        if let digest = item["sha256"] as? String {
                            do {
                                previewAttachment = try store.verifiedAttachmentURL(
                                    digest: digest, filename: item["displayName"] as? String)
                            } catch { localError = error.localizedDescription }
                        }
                    } label: {
                        Label(attachments[index]["displayName"] as? String ?? "Файл", systemImage: "doc")
                            .lineLimit(1)
                    }
                    .buttonStyle(.plain)
                    .foregroundStyle(Color.black)
                    Spacer(minLength: 0)
                    Button(role: .destructive) {
                        if let digest = attachments[index]["sha256"] as? String {
                            attachments.removeAll { ($0["sha256"] as? String) == digest }
                        }
                    } label: { Image(systemName: "trash") }
                        .accessibilityLabel("Удалить вложение")
                }
            }
        }
        .padding(.top, 8)
        .accessibilityIdentifier("FEEditor.Attachments")
    }

    private func formatButton(_ title: String, icon: String,
                              action: FERichCommand, hint: String) -> some View {
        Button {
            formatCommand = action
            formatSequence += 1
        } label: {
            Image(systemName: icon)
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(Color.black)
                .frame(width: 42, height: 35)
                .background(Color.white.opacity(0.68), in: RoundedRectangle(cornerRadius: 9))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(hint)
        .accessibilityIdentifier("FEEditor.Format.\(action.rawValue)")
    }

    // Both the microphone and attachment controls live on the same note-coloured band.
    // One horizontal toolbar. On narrow screens only the microphone label disappears.
    private var inputActionsBand: some View {
        VStack(alignment: .leading, spacing: 7) {
            ViewThatFits(in: .horizontal) {
                actionRow(compactMicrophone: false)
                actionRow(compactMicrophone: true)
            }
            if voice.isRecording {
                Label("Запись идёт", systemImage: "waveform")
                    .font(.caption)
                    .foregroundStyle(FEAndroidPalette.ink(color))
            }
            if voice.isProcessing {
                Label("Распознаём запись…", systemImage: "ellipsis.circle")
                    .font(.caption).foregroundStyle(FEAndroidPalette.ink(color))
            }
            if let raw = voice.rawFinalText {
                DisclosureGroup("Исходный результат Apple Speech") {
                    Text(raw.isEmpty ? "(пустой результат)" : raw)
                        .font(.caption)
                        .textSelection(.enabled)
                }
                .font(.caption)
                .foregroundStyle(FEAndroidPalette.ink(color))
            }
            if let voiceError = voice.errorMessage {
                Text(voiceError).font(.caption).foregroundStyle(Color.red)
            }
        }
        .foregroundStyle(FEAndroidPalette.ink(color))
        .font(.system(size: 13, weight: .semibold))
        .buttonStyle(.plain)
        .padding(.horizontal, 17)
        .padding(.vertical, 14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(FEAndroidPalette.color(color))
        .animation(.easeInOut(duration: 0.16), value: color)
    }

    private func actionRow(compactMicrophone: Bool) -> some View {
        HStack(spacing: 8) {
            Button {
                if voice.isRecording {
                    voice.stop()
                } else {
                    voiceStartText = bodyText
                    voice.start(offlineOnly: pinProtected)
                }
            } label: {
                Group {
                    if compactMicrophone {
                        Image(systemName: voice.isRecording ? "stop.circle.fill" : "mic")
                    } else {
                        Label(voice.isRecording ? "Стоп" : "Голосовой ввод",
                              systemImage: voice.isRecording ? "stop.circle.fill" : "mic")
                    }
                }
                .padding(.horizontal, compactMicrophone ? 12 : 11)
                .frame(height: 39)
                .background(Color.white.opacity(0.52), in: Capsule())
            }
            .disabled(kind == .list || voice.isProcessing)
            .opacity(kind == .list ? 0.42 : 1)
            .accessibilityLabel(voice.isRecording ? "Остановить запись" : "Голосовой ввод")
            Button { showingParameters = true } label: {
                Label("Параметры", systemImage: "slider.horizontal.3")
            }
                .font(.system(size: 13, weight: .semibold))
                .padding(.horizontal, compactMicrophone ? 10 : 11)
                .frame(height: 39)
                .background(Color.white.opacity(0.52), in: Capsule())
                .accessibilityIdentifier("FEEditor.Parameters")
                .accessibilityLabel("Параметры заметки")
            PhotosPicker(selection: $photo, matching: .images) {
                Group {
                    if compactMicrophone { Image(systemName: "photo.on.rectangle") }
                    else { Label("Картинка", systemImage: "photo.on.rectangle") }
                }
                    .padding(.horizontal, compactMicrophone ? 10 : 11)
                    .frame(height: 39)
                    .background(Color.white.opacity(0.52), in: Capsule())
            }
            Button { importingAttachment = true } label: {
                Group {
                    if compactMicrophone { Image(systemName: "paperclip") }
                    else { Label("Файл", systemImage: "paperclip") }
                }
                    .padding(.horizontal, compactMicrophone ? 10 : 11)
                    .frame(height: 39)
                    .background(Color.white.opacity(0.52), in: Capsule())
            }
        }
        .fixedSize(horizontal: true, vertical: false)
    }

    // The entire remaining area, including underneath the home indicator, is pale grey.
    // I3b3e: Dedicated note-parameters sheet (NorrNote21 parity).
    private var parametersSheet: some View {
        NavigationStack {
            ScrollView { parametersContent }
                .background(FEEditorSurface.paleGray.ignoresSafeArea())
                .navigationTitle("Параметры заметки")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        Button { showingParameters = false } label: {
                            Image(systemName: "xmark")
                        }
                        .accessibilityLabel("Закрыть")
                        .accessibilityIdentifier("FEEditor.Parameters.Close")
                    }
                }
        }
        .tint(FEMintTheme.accent)
        .sheet(item: $pinMode) { mode in
            FEPINManageView(noteID: id, mode: mode) {
                pinProtected = FEPermanentPIN.isProtected(id)
                onProtectionChanged()
            }
        }
        .presentationDetents([.large])
        .presentationDragIndicator(.visible)
    }

    private var parametersContent: some View {
        VStack(alignment: .leading, spacing: 16) {
            VStack(alignment: .leading, spacing: 7) {
                Text("Тип записи").font(.subheadline.weight(.semibold))
                Menu {
                    ForEach(FENoteType.allCases) { option in
                        Button { kind = option } label: {
                            Label(option.title, systemImage: option.symbol)
                        }
                    }
                } label: {
                    HStack(spacing: 9) {
                        Image(systemName: kind.symbol)
                        Text(LocalizedStringKey(kind.title))
                        Spacer()
                        Image(systemName: "chevron.down").font(.caption.weight(.semibold))
                    }
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.primary)
                    .padding(.horizontal, 13)
                    .frame(height: 43)
                    .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
                }
                .accessibilityIdentifier("FEEditor.Parameters.Kind")
            }
            Divider()
            Text("Цвет карточки")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(Color.black)
            HStack(spacing: 1) {
                ForEach(0..<4, id: \.self) { index in
                    Button { color = index } label: {
                        Circle()
                            .fill(FEAndroidPalette.color(index))
                            .frame(width: 30, height: 30)
                            .overlay(Circle().strokeBorder(index == FEAndroidPalette.displayIndex(color) ? Color.black : Color.black.opacity(0.12),
                                                         lineWidth: index == FEAndroidPalette.displayIndex(color) ? 2.5 : 0.5))
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Цвет \(index + 1)")
                }
            }
            Divider()
            Toggle("Важное", isOn: $important)
            Toggle("Выполнено", isOn: $completed)
            if kind == .permanent || pinProtected {
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Image(systemName: pinProtected ? "lock.fill" : "lock.open")
                        Text("Защита PIN")
                        Spacer()
                        Toggle("Защита PIN", isOn: Binding(
                            get: { pinProtected },
                            set: { enabled in
                                guard enabled != pinProtected else { return }
                                pinMode = enabled ? .setup : .remove
                            }))
                            .labelsHidden()
                            .tint(FEMintTheme.accent)
                    }
                    if pinProtected {
                        Button("Изменить PIN") { pinMode = .change }
                            .font(.caption.weight(.medium))
                    }
                    Text("Локальная блокировка доступа на этом iPhone; данные Sync21 не шифруются.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            if kind == .permanent {
                Picker("Категория", selection: $category) {
                    Text("Без категории").tag("")
                    ForEach(FECategory.base) { item in Text(LocalizedStringKey(item.title)).tag(item.id) }
                }
            } else {
                DatePicker("Дата", selection: $scheduledDay, displayedComponents: .date)
            }
            if kind == .reminder || kind == .birthday || kind == .repeating {
                Toggle("Включить уведомление", isOn: $notifyEnabled)
                if notifyEnabled {
                    DatePicker("Напомнить", selection: $reminderDate,
                               displayedComponents: [.date, .hourAndMinute])
                    Picker("Повторить звук", selection: $repeats) {
                        Text("1 раз").tag(1)
                        Text("3 раза").tag(3)
                        Text("5 раз").tag(5)
                    }
                    Text("Интервал между сигналами — 1 минута")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Button("Прослушать фирменный звук") { store.previewNotificationSound() }
                        .font(.caption.weight(.medium))
                        .buttonStyle(.bordered)
                }
            }
            Divider()
            Button {
                discardOnClose = true
                store.trash(id)
                dismiss()
            } label: {
                Label("Переместить в корзину", systemImage: "trash")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(FEMintTheme.text)
                    .padding(.horizontal, 20)
                    .frame(height: 49)
                    .background(FEMintTheme.button, in: Capsule())
                    .overlay(Capsule().strokeBorder(FEMintTheme.border, lineWidth: 1))
                    .shadow(color: .black.opacity(0.10), radius: 5, y: 2)
            }
            .buttonStyle(.plain)
            .frame(maxWidth: .infinity, alignment: .center)
            .accessibilityIdentifier("FEEditor.Trash")
        }
        .padding(.horizontal, 17)
        .padding(.top, 18)
        .padding(.bottom, 28)
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .background(FEEditorSurface.paleGray)
    }

    private var listEditor: some View {
        VStack(spacing: 10) {
            ForEach(checklist.indices, id: \.self) { index in
                HStack(spacing: 10) {
                    Button {
                        checklist[index].done.toggle()
                        if !checklist.isEmpty && checklist.allSatisfy({ $0.done }) { confirmChecklist = true }
                    } label: {
                        Image(systemName: checklist[index].done ? "checkmark.circle.fill" : "circle")
                            .font(.system(size: 23))
                    }
                    .buttonStyle(.plain)
                    TextField("Пункт списка", text: $checklist[index].title)
                        .focused($focusedItemID, equals: checklist[index].id)
                    Button {
                        checklist.remove(at: index)
                    } label: { Image(systemName: "minus.circle").foregroundStyle(.secondary) }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Удалить пункт")
                }
            }
            Button {
                let uid = UUID().uuidString.lowercased()
                checklist.append(FEDraftItem(id: uid, title: "", done: false))
                Task { @MainActor in focusedItemID = uid }
            } label: { Label("Добавить пункт", systemImage: "plus") }
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(Color.primary)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(.vertical, 6)
    }

    private func load() {
        guard let row = store.record(id) else { return }
        title = row["title"] as? String ?? ""
        bodyText = row["text"] as? String ?? row["body"] as? String ?? ""
        richHTML = row["feRichTextHTML"] as? String ?? ""
        color = max(0, min(7, (row["colorIndex"] as? NSNumber)?.intValue ?? 0))
        important = row["isImportant"] as? Bool ?? false
        completed = row["checked"] as? Bool ?? false
        kind = FENoteType(rawValue: row["type"] as? String ?? "TEXT") ?? .text
        category = row["categoryKey"] as? String ?? ""
        if let date = row["scheduledDate"] as? String {
            let f = DateFormatter()
            f.locale = Locale(identifier: "en_US_POSIX")
            f.dateFormat = "yyyy-MM-dd"
            scheduledDay = f.date(from: date) ?? Date()
        }
        attachments = store.attachmentMetadata(id)
        pinProtected = FEPermanentPIN.isProtected(id)
        voiceStartText = bodyText
        if let ms = FEiOSWire.time(row["reminderAtMillis"]) {
            notifyEnabled = true
            reminderDate = Date(timeIntervalSince1970: Double(ms) / 1000)
        }
        let storedCount = (row["feReminderPlayCount"] as? NSNumber)?.intValue ??
                          (row["alertRepeatCount"] as? NSNumber)?.intValue ?? 1
        repeats = [1, 3, 5].contains(storedCount) ? storedCount : 1
        checklist = (row["items"] as? [[String: Any]] ?? []).map {
            FEDraftItem(id: ($0["id"] as? String) ?? ($0["uuid"] as? String) ?? UUID().uuidString.lowercased(),
                        title: $0["text"] as? String ?? "", done: $0["done"] as? Bool ?? $0["checked"] as? Bool ?? false)
        }
    }
    private func save() {
        let wireItems: [[String: Any]] = checklist.enumerated().map { index, item in
            ["id": item.id, "uuid": item.id, "text": item.title,
             "done": item.done, "checked": item.done, "position": index]
        }
        store.saveDraft(id, title: title, body: bodyText, color: color, important: important,
                        completed: completed, kind: kind.rawValue, category: category,
                        checklist: wireItems, scheduledDay: scheduledDay,
                        reminderAt: notifyEnabled && (kind == .reminder || kind == .birthday || kind == .repeating) ? reminderDate : nil,
                        repeatCount: repeats, attachmentList: attachments,
                        richTextHTML: kind == .list ? nil : richHTML)
    }
}

// UIKit-backed rich text editing. Plain `text` remains intact for old Sync21 readers;
// optional FE-specific HTML contains character styles for this iOS editor.
private enum FERichCommand: String {
    case bold, italic, underline, strike
}

private struct FERichTextEditor: UIViewRepresentable {
    @Binding var text: String
    @Binding var richHTML: String
    let command: FERichCommand
    let sequence: Int

    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }
    func makeUIView(context: Context) -> UITextView {
        let view = UITextView()
        view.delegate = context.coordinator
        view.backgroundColor = .clear
        view.isEditable = true
        view.isSelectable = true
        view.textColor = .black
        view.font = UIFont.systemFont(ofSize: 16)
        view.isScrollEnabled = true
        view.adjustsFontForContentSizeCategory = true
        view.accessibilityIdentifier = "FEEditor.Body"
        view.attributedText = FERichCodec.decode(html: richHTML, fallback: text)
        context.coordinator.loaded = true
        context.coordinator.lastExternalText = text
        context.coordinator.lastExternalHTML = richHTML
        return view
    }
    func updateUIView(_ view: UITextView, context: Context) {
        context.coordinator.parent = self
        if !context.coordinator.loaded { return }
        // Voice input writes to plain text binding; preserve existing formatting when appending.
        if text != view.text {
            // I3b3u: voice input replaces the tail of the text while Speech revises
            // words. Keep the formatted common prefix and replace only the rest.
            // (Previously a revision re-decoded the stale HTML and restored the
            // pre-dictation text.)
            let current = NSMutableAttributedString(attributedString: view.attributedText ?? NSAttributedString(string: ""))
            let keep = min(Self.commonPrefixUTF16(view.text ?? "", text), current.length)
            if keep < current.length {
                current.deleteCharacters(in: NSRange(location: keep, length: current.length - keep))
            }
            let rest = (text as NSString).substring(from: min(keep, (text as NSString).length))
            if !rest.isEmpty {
                current.append(NSAttributedString(string: rest,
                    attributes: [.font: UIFont.systemFont(ofSize: 16), .foregroundColor: UIColor.black]))
            }
            // A programmatic Speech update is not a user edit. UIKit may
            // synchronously notify its delegate when attributed text changes.
            context.coordinator.applyingExternalText = true
            view.attributedText = current
            context.coordinator.applyingExternalText = false
            context.coordinator.lastExternalText = text
            context.coordinator.lastExternalHTML = richHTML
            // Only publish the rich-text representation if this exact revision
            // is still current. Otherwise a queued closure can write an older
            // partial speech hypothesis back into SwiftUI.
            let expectedRevision = text
            DispatchQueue.main.async { [weak view, weak coordinator = context.coordinator] in
                guard let view, let coordinator,
                      coordinator.parent.text == expectedRevision,
                      view.text == expectedRevision else { return }
                coordinator.publish(view)
            }
        } else if richHTML != context.coordinator.lastExternalHTML {
            // When opening a note, text and HTML bindings can arrive in distinct updates.
            // Do not rebuild after an editor-originated formatting change.
            let selected = view.selectedRange
            view.attributedText = FERichCodec.decode(html: richHTML, fallback: text)
            if selected.location <= view.attributedText.length &&
                selected.length <= view.attributedText.length - selected.location {
                view.selectedRange = selected
            }
            context.coordinator.lastExternalHTML = richHTML
        }
        if context.coordinator.lastSequence != sequence {
            context.coordinator.lastSequence = sequence
            context.coordinator.apply(command: command, to: view)
        }
    }

    /// Length (UTF-16 units, as used by NSAttributedString) of the common
    /// prefix of two strings, never splitting a Character.
    static func commonPrefixUTF16(_ a: String, _ b: String) -> Int {
        var count = 0
        var left = a.makeIterator()
        var right = b.makeIterator()
        while let l = left.next(), let r = right.next(), l == r {
            count += l.utf16.count
        }
        return count
    }

    final class Coordinator: NSObject, UITextViewDelegate {
        var parent: FERichTextEditor
        var loaded = false
        var lastExternalText = ""
        var lastExternalHTML = ""
        var applyingExternalText = false
        var lastSequence = 0
        var savedSelection: NSRange?
        init(parent: FERichTextEditor) { self.parent = parent }

        func textViewDidChange(_ textView: UITextView) {
            // External speech updates must never re-enter the text binding.
            guard !applyingExternalText else { return }
            publish(textView)
        }
        func textViewDidChangeSelection(_ textView: UITextView) {
            if textView.isFirstResponder {
                savedSelection = textView.selectedRange
            }
        }
        func publish(_ view: UITextView) {
            let content = view.attributedText ?? NSAttributedString()
            let plain = content.string
            lastExternalText = plain
            if parent.text != plain { parent.text = plain }
            let html = FERichCodec.encode(content)
            lastExternalHTML = html
            if parent.richHTML != html { parent.richHTML = html }
        }

        // Long-press/select shows the native iOS menu, extended with note formatting.
        // A single tap places the caret; the buttons below the editor format its word.
        func textView(_ textView: UITextView, editMenuForTextIn range: NSRange,
                      suggestedActions: [UIMenuElement]) -> UIMenu? {
            let commands: [(FERichCommand, String, String)] = [
                (.bold, "Жирный", "bold"),
                (.italic, "Курсив", "italic"),
                (.underline, "Подчёркнутый", "underline"),
                (.strike, "Зачёркнутый", "strikethrough")
            ]
            let formatting = UIMenu(title: "Форматирование", image: UIImage(systemName: "textformat"),
                children: commands.map { entry in
                    let (kind, label, symbol) = entry
                    return UIAction(title: NSLocalizedString(label, comment: "Rich text format"),
                             image: UIImage(systemName: symbol)) { [weak self, weak textView] _ in
                        guard let self, let textView else { return }
                        self.apply(command: kind, to: textView, preferredRange: range)
                    }
                })
            return UIMenu(children: suggestedActions + [formatting])
        }

        // I3b3h: text selection + word formatting and native iOS edit menu.
        private func formattingRange(in view: UITextView) -> NSRange? {
            let fullLength = view.attributedText?.length ?? 0
            let current = view.isFirstResponder ? view.selectedRange : (savedSelection ?? view.selectedRange)
            let selection = current.location != NSNotFound && current.location <= fullLength &&
                current.length <= fullLength - current.location ? current : savedSelection
            guard let selection, selection.location != NSNotFound,
                  selection.location <= fullLength,
                  selection.length <= fullLength - selection.location else { return nil }
            if selection.length > 0 { return selection }
            let content = view.text as NSString
            guard content.length > 0 else { return nil }
            var result: NSRange?
            content.enumerateSubstrings(in: NSRange(location: 0, length: content.length),
                                        options: .byWords) { _, word, _, stop in
                if NSLocationInRange(selection.location, word) ||
                    (selection.location == NSMaxRange(word) && selection.location > word.location) {
                    result = word
                    stop.pointee = true
                }
            }
            return result
        }

        func apply(command: FERichCommand, to view: UITextView, preferredRange: NSRange? = nil) {
            let mutable = NSMutableAttributedString(attributedString: view.attributedText ?? NSAttributedString(string: ""))
            let target = preferredRange ?? formattingRange(in: view)
            if let range = target, range.length > 0,
               range.location != NSNotFound, range.location <= mutable.length,
               range.length <= mutable.length - range.location {
                // Consistent toggle: mixed formatting becomes ON for the entire selection.
                var allOn = true
                mutable.enumerateAttributes(in: range, options: []) { attrs, _, _ in
                    if !active(command, attributes: attrs) { allOn = false }
                }
                let enable = !allOn
                let snapshot = NSAttributedString(attributedString: mutable)
                snapshot.enumerateAttributes(in: range, options: []) { attrs, partRange, _ in
                    var edited = attrs
                    set(command, enabled: enable, attributes: &edited)
                    mutable.setAttributes(edited, range: partRange)
                }
                view.attributedText = mutable
                view.selectedRange = range
                savedSelection = range
                view.becomeFirstResponder()
                publish(view)
                return
            }
            // Cursor on whitespace / empty note: format the next typed characters.
            var attrs = view.typingAttributes
            set(command, enabled: !active(command, attributes: attrs), attributes: &attrs)
            view.becomeFirstResponder()
            view.typingAttributes = attrs
        }

        private func active(_ command: FERichCommand,
                            attributes: [NSAttributedString.Key: Any]) -> Bool {
            switch command {
            case .bold, .italic:
                let font = attributes[.font] as? UIFont ?? UIFont.systemFont(ofSize: 16)
                return font.fontDescriptor.symbolicTraits.contains(command == .bold ? .traitBold : .traitItalic)
            case .underline:
                return (attributes[.underlineStyle] as? Int ?? 0) != 0
            case .strike:
                return (attributes[.strikethroughStyle] as? Int ?? 0) != 0
            }
        }
        private func set(_ command: FERichCommand, enabled: Bool,
                         attributes: inout [NSAttributedString.Key: Any]) {
            switch command {
            case .bold, .italic:
                let font = attributes[.font] as? UIFont ?? UIFont.systemFont(ofSize: 16)
                let trait: UIFontDescriptor.SymbolicTraits = command == .bold ? .traitBold : .traitItalic
                var symbolic = font.fontDescriptor.symbolicTraits
                if enabled { symbolic.insert(trait) } else { symbolic.remove(trait) }
                let descriptor = font.fontDescriptor.withSymbolicTraits(symbolic) ?? font.fontDescriptor
                attributes[.font] = UIFont(descriptor: descriptor, size: font.pointSize)
            case .underline:
                attributes[.underlineStyle] = enabled ? NSUnderlineStyle.single.rawValue : 0
            case .strike:
                attributes[.strikethroughStyle] = enabled ? NSUnderlineStyle.single.rawValue : 0
            }
        }
    }
}

private enum FERichCodec {
    static func decode(html: String, fallback: String) -> NSAttributedString {
        let baseFont = UIFont.systemFont(ofSize: 16)
        let defaults: [NSAttributedString.Key: Any] = [.font: baseFont, .foregroundColor: UIColor.black]
        guard !html.isEmpty, let data = html.data(using: .utf8),
              let content = try? NSAttributedString(data: data,
                options: [.documentType: NSAttributedString.DocumentType.html,
                          .characterEncoding: String.Encoding.utf8.rawValue],
                documentAttributes: nil) else {
            return NSAttributedString(string: fallback, attributes: defaults)
        }
        let normalized = NSMutableAttributedString(attributedString: content)
        // Apple's HTML importer may append a single paragraph terminator.
        while normalized.string != fallback && normalized.string.hasSuffix("\n") && normalized.string.count > fallback.count {
            normalized.deleteCharacters(in: NSRange(location: normalized.length - 1, length: 1))
        }
        guard normalized.string == fallback else {
            return NSAttributedString(string: fallback, attributes: defaults)
        }
        content.enumerateAttributes(in: NSRange(location: 0, length: normalized.length), options: []) { attributes, range, _ in
            let font = attributes[.font] as? UIFont
            let traits = font?.fontDescriptor.symbolicTraits ?? []
            let face = UIFont.systemFont(ofSize: 16, weight: traits.contains(.traitBold) ? .bold : .regular)
            let descriptor = traits.contains(.traitItalic) ? (face.fontDescriptor.withSymbolicTraits(face.fontDescriptor.symbolicTraits.union(.traitItalic)) ?? face.fontDescriptor) : face.fontDescriptor
            normalized.addAttributes([.font: UIFont(descriptor: descriptor, size: 16),
                                      .foregroundColor: UIColor.black], range: range)
        }
        return normalized
    }
    static func encode(_ text: NSAttributedString) -> String {
        let content = text.string
        if content.isEmpty { return "" }
        var html = ""
        text.enumerateAttributes(in: NSRange(location: 0, length: text.length), options: []) { attrs, range, _ in
            let part = (content as NSString).substring(with: range)
            var escape = part.replacingOccurrences(of: "&", with: "&amp;")
                .replacingOccurrences(of: "<", with: "&lt;")
                .replacingOccurrences(of: ">", with: "&gt;")
                .replacingOccurrences(of: "\"", with: "&quot;")
                .replacingOccurrences(of: "\n", with: "<br/>")
            let symbolic = (attrs[.font] as? UIFont)?.fontDescriptor.symbolicTraits ?? []
            let bold = symbolic.contains(.traitBold), italic = symbolic.contains(.traitItalic)
            let under = (attrs[.underlineStyle] as? Int ?? 0) != 0
            let strike = (attrs[.strikethroughStyle] as? Int ?? 0) != 0
            if strike { escape = "<s>" + escape + "</s>" }
            if under { escape = "<u>" + escape + "</u>" }
            if italic { escape = "<i>" + escape + "</i>" }
            if bold { escape = "<b>" + escape + "</b>" }
            html += escape
        }
        return "<html><body>" + html + "</body></html>"
    }
}

// Apple Speech framework dictation. Normal notes use system speech recognition
// with an on-device retry; PIN-protected notes require on-device recognition only.
@MainActor
private final class FEVoiceInput: ObservableObject {
    @Published private(set) var isRecording = false
    @Published private(set) var transcript = ""
    @Published private(set) var errorMessage: String?

    private let engine = AVAudioEngine()
    private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "ru-RU"))
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?
    private var tapInstalled = false
    private var isPreparing = false
    private var generation = 0
    private var offlineOnly = false
    // Ordinary notes use Apple Speech default mode; PIN notes require local.
    private var useOnDevice = false
    private var awaitingFinal = false
    private var finalResultDeadline: Task<Void, Never>?
    private var audioSetup: Task<Void, Never>?
    private var audioShutdown: Task<Void, Never>?

    // I3b3ae: the Speech request emits only the final hypothesis. This class
    // never merges different recognizer callbacks, changes word order or deletes
    // repeats. Expose the EXACT Apple result separately so a mismatch with the
    // UITextView can be distinguished from a bad recognition result.
    @Published private(set) var rawFinalText: String?
    @Published private(set) var isProcessing = false

    func start(offlineOnly: Bool = false) {
        guard !isRecording && !isPreparing && !awaitingFinal else { return }
        generation += 1
        let current = generation
        isPreparing = true
        errorMessage = nil
        transcript = ""
        rawFinalText = nil
        isProcessing = false
        self.offlineOnly = offlineOnly
        useOnDevice = offlineOnly
        finalResultDeadline?.cancel()
        finalResultDeadline = nil
        SFSpeechRecognizer.requestAuthorization { [weak self] authorization in
            Task { @MainActor in
                guard let self, self.generation == current else { return }
                guard authorization == .authorized else {
                    self.isPreparing = false
                    self.errorMessage = "Разрешите распознавание речи в настройках iPhone."
                    return
                }
                AVAudioApplication.requestRecordPermission { granted in
                    Task { @MainActor in
                        guard self.generation == current else { return }
                        guard granted else {
                            self.isPreparing = false
                            self.errorMessage = "Нет разрешения на использование микрофона."
                            return
                        }
                        self.startEngine(generation: current)
                    }
                }
            }
        }
    }

    private func startEngine(generation current: Int) {
        guard let recognizer, recognizer.isAvailable else {
            isPreparing = false
            errorMessage = "Распознавание русской речи сейчас недоступно."
            return
        }
        if offlineOnly && !recognizer.supportsOnDeviceRecognition {
            isPreparing = false
            errorMessage = "Для защищённой заметки недоступно локальное распознавание русской речи."
            return
        }
        let shutdown = audioShutdown
        audioSetup?.cancel()
        audioSetup = Task { @MainActor [weak self] in
            if let shutdown { await shutdown.value }
            guard let self, !Task.isCancelled, self.generation == current else { return }
            do {
                try await FEiOSAudioSessionCoordinator.shared.activateRecording()
                guard !Task.isCancelled, self.generation == current else {
                    await FEiOSAudioSessionCoordinator.shared.deactivate()
                    return
                }
                self.startCapture(generation: current)
            } catch {
                self.isPreparing = false
                self.errorMessage = "Не удалось включить микрофон: \(error.localizedDescription)"
            }
        }
    }

    private func startCapture(generation current: Int) {
        guard let recognizer, recognizer.isAvailable else {
            isPreparing = false
            errorMessage = "Распознавание русской речи сейчас недоступно."
            return
        }
        do {
            let bufferRequest = SFSpeechAudioBufferRecognitionRequest()
            // One final recognition for one recording. Never concatenate partials.
            bufferRequest.shouldReportPartialResults = false
            // Avoid forcing offline models for ordinary notes: on some devices
            // this path failed with kAFAssistantErrorDomain 216. Speech services
            // may use Apple servers unless a note is PIN protected.
            bufferRequest.requiresOnDeviceRecognition = useOnDevice
            request = bufferRequest
            let input = engine.inputNode
            let format = input.outputFormat(forBus: 0)
            input.installTap(onBus: 0, bufferSize: 1024, format: format) { buffer, _ in
                bufferRequest.append(buffer)
            }
            tapInstalled = true
            engine.prepare()
            try engine.start()
            isPreparing = false
            isRecording = true
            task = recognizer.recognitionTask(with: bufferRequest) { [weak self] result, error in
                Task { @MainActor in
                    guard let self, current == self.generation else { return }
                    if let result, result.isFinal {
                        // Assign one immutable Apple result verbatim, once.
                        // No sanitization, overlap merge, or word reordering.
                        if self.rawFinalText == nil {
                            let raw = result.bestTranscription.formattedString
                            self.rawFinalText = raw
                            if !raw.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                                self.transcript = raw
                            }
                        }
                    }
                    if let error {
                        let failure = error as NSError
                        // A user-initiated finish can deliver a late result or
                        // terminal error. Keep any recognized text; never retry
                        // after the user stopped the microphone.
                        if self.awaitingFinal {
                            if self.transcript.isEmpty {
                                self.errorMessage = "Не удалось распознать речь (\(failure.domain), код \(failure.code))."
                            }
                            self.stop(cancelRecognition: true)
                            return
                        }
                        // Do not restart the microphone invisibly after an error.
                        // A retry is a NEW user-initiated recording, so no audio
                        // can accidentally be mixed across recognition tasks.
                        self.errorMessage = "Ошибка распознавания: \(failure.domain), код \(failure.code). Проверьте разрешения Siri/Диктовки и соединение с интернетом."
                        self.stop(cancelRecognition: true)
                    } else if result?.isFinal == true {
                        self.stop(cancelRecognition: true)
                    }
                }
            }
        } catch {
            errorMessage = "Не удалось включить микрофон: \(error.localizedDescription)"
            stop(cancelRecognition: true)
        }
    }

    // User stop is a graceful finish, not an immediate cancellation. Keep the
    // callback generation alive until the final transcription (or a deadline),
    // otherwise late words can be lost after pressing the stop button.
    func stop() {
        if awaitingFinal { return }
        guard isRecording else {
            if isPreparing { stop(cancelRecognition: true) }
            return
        }
        awaitingFinal = true
        isProcessing = true
        isRecording = false
        if engine.isRunning { engine.stop() }
        if tapInstalled {
            engine.inputNode.removeTap(onBus: 0)
            tapInstalled = false
        }
        request?.endAudio()
        task?.finish()
        let previousSetup = audioSetup
        previousSetup?.cancel()
        audioSetup = nil
        audioShutdown = Task {
            if let previousSetup { await previousSetup.value }
            await FEiOSAudioSessionCoordinator.shared.deactivate()
        }
        let current = generation
        finalResultDeadline?.cancel()
        finalResultDeadline = Task { @MainActor [weak self] in
            try? await Task.sleep(for: .seconds(12))
            guard let self, self.generation == current, self.awaitingFinal else { return }
            if self.rawFinalText == nil {
                self.errorMessage = "Apple Speech не вернул окончательный текст за 12 секунд. Попробуйте снова."
            }
            self.stop(cancelRecognition: true)
        }
    }

    private func stop(cancelRecognition: Bool) {
        generation += 1
        isPreparing = false
        isRecording = false
        awaitingFinal = false
        isProcessing = false
        finalResultDeadline?.cancel()
        finalResultDeadline = nil
        if engine.isRunning { engine.stop() }
        if tapInstalled {
            engine.inputNode.removeTap(onBus: 0)
            tapInstalled = false
        }
        request?.endAudio()
        if cancelRecognition { task?.cancel() }
        else { task?.finish() }
        task = nil
        request = nil
        let previousSetup = audioSetup
        previousSetup?.cancel()
        audioSetup = nil
        audioShutdown = Task {
            if let previousSetup { await previousSetup.value }
            await FEiOSAudioSessionCoordinator.shared.deactivate()
        }
    }
}

// I2t: Local-only PIN access gate for selected permanent notes.
// The content remains plain text in Sync21/local DB; this does not encrypt note data.
private enum FEPermanentPIN {
    private static let service = "su.norrvind.norrnote.fe.ios.permanent-pin.v1"
    private static let saltLength = 16
    private static let digestLength = 32
    private static let rounds: UInt32 = 120_000

    private static func query(_ id: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: service,
         kSecAttrAccount as String: id.lowercased()]
    }
    private static func item(_ id: String) -> Data? {
        var parameters = query(id)
        parameters[kSecReturnData as String] = kCFBooleanTrue
        parameters[kSecMatchLimit as String] = kSecMatchLimitOne
        var raw: CFTypeRef?
        guard SecItemCopyMatching(parameters as CFDictionary, &raw) == errSecSuccess else { return nil }
        return raw as? Data
    }
    static func isProtected(_ id: String) -> Bool {
        // Fail closed for any error other than a definitive missing Keychain item.
        SecItemCopyMatching(query(id) as CFDictionary, nil) != errSecItemNotFound
    }
    static func valid(_ pin: String) -> Bool {
        pin.count >= 6 && pin.count <= 8 && pin.allSatisfy { $0.isASCII && $0.isNumber }
    }
    private static func derived(_ pin: String, salt: Data) -> Data? {
        guard let bytes = pin.data(using: .utf8) else { return nil }
        var output = [UInt8](repeating: 0, count: digestLength)
        let result: Int32 = bytes.withUnsafeBytes { input in
            salt.withUnsafeBytes { nonce in
                CCKeyDerivationPBKDF(CCPBKDFAlgorithm(kCCPBKDF2),
                    input.bindMemory(to: Int8.self).baseAddress, bytes.count,
                    nonce.bindMemory(to: UInt8.self).baseAddress, salt.count,
                    CCPseudoRandomAlgorithm(kCCPRFHmacAlgSHA256), rounds,
                    &output, output.count)
            }
        }
        return result == kCCSuccess ? Data(output) : nil
    }
    static func verify(_ id: String, pin: String) -> Bool {
        guard valid(pin), let data = item(id), data.count == saltLength + digestLength,
              let check = derived(pin, salt: data.prefix(saltLength)) else { return false }
        // Constant-time digest comparison (apart from PIN length validation).
        var different: UInt8 = 0
        for index in 0..<digestLength { different |= check[index] ^ data[saltLength + index] }
        return different == 0
    }
    static func set(_ id: String, pin: String) -> Bool {
        guard valid(pin) else { return false }
        var salt = [UInt8](repeating: 0, count: saltLength)
        guard SecRandomCopyBytes(kSecRandomDefault, salt.count, &salt) == errSecSuccess,
              let digest = derived(pin, salt: Data(salt)) else { return false }
        let value = Data(salt) + digest
        let q = query(id)
        if isProtected(id) {
            return SecItemUpdate(q as CFDictionary, [kSecValueData as String: value] as CFDictionary) == errSecSuccess
        }
        var adding = q
        adding[kSecValueData as String] = value
        adding[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        return SecItemAdd(adding as CFDictionary, nil) == errSecSuccess
    }
    static func remove(_ id: String) -> Bool {
        SecItemDelete(query(id) as CFDictionary) == errSecSuccess
    }
}

private enum FEPINMode: String, Identifiable {
    case setup, remove, change
    var id: String { rawValue }
}

private struct FEPINUnlockView: View {
    let noteID: String
    let onUnlock: () -> Void
    @State private var pin = ""
    @State private var problem = ""
    @State private var failures = 0
    @State private var lockedUntil: Date = .distantPast

    var body: some View {
        NavigationStack {
            Form {
                Section("Защищённая заметка") {
                    Label("Введите PIN для открытия", systemImage: "lock.fill")
                    SecureField("PIN (6–8 цифр)", text: $pin)
                        .keyboardType(.numberPad)
                        .textContentType(.password)
                    if !problem.isEmpty { Text(problem).foregroundStyle(.red).font(.caption) }
                    Button("Открыть") {
                        guard Date() >= lockedUntil else { problem = "Подождите перед повторной попыткой."; return }
                        if FEPermanentPIN.verify(noteID, pin: pin) {
                            pin = ""
                            failures = 0
                            onUnlock()
                        } else {
                            failures += 1
                            problem = "Неверный PIN"
                            pin = ""
                            if failures >= 5 {
                                lockedUntil = Date().addingTimeInterval(30)
                                failures = 0
                                problem = "Пять неверных попыток. Повторите через 30 секунд."
                            }
                        }
                    }
                    .disabled(!FEPermanentPIN.valid(pin))
                }
            }
            .navigationTitle("PIN-доступ")
            .navigationBarTitleDisplayMode(.inline)
            .tint(FEMintTheme.accent)
        }
    }
}

private struct FEPINManageView: View {
    @Environment(\.dismiss) private var dismiss
    let noteID: String
    let mode: FEPINMode
    let onChanged: () -> Void
    @State private var oldPIN = ""
    @State private var pin = ""
    @State private var confirmation = ""
    @State private var problem = ""

    var body: some View {
        NavigationStack {
            Form {
                Section(LocalizedStringKey(mode == .setup ? "Установить PIN" :
                        (mode == .change ? "Изменить PIN" : "Отключить PIN"))) {
                    if mode != .setup {
                        SecureField("Действующий PIN", text: $oldPIN).keyboardType(.numberPad)
                    }
                    if mode != .remove {
                        SecureField("Новый PIN (6–8 цифр)", text: $pin).keyboardType(.numberPad)
                        SecureField("Повторите новый PIN", text: $confirmation).keyboardType(.numberPad)
                    }
                    if !problem.isEmpty { Text(problem).foregroundStyle(.red).font(.caption) }
                    Button(LocalizedStringKey(mode == .remove ? "Отключить защиту" : "Сохранить PIN")) {
                        if mode != .setup && !FEPermanentPIN.verify(noteID, pin: oldPIN) {
                            problem = "Действующий PIN неверен"; return
                        }
                        if mode == .remove {
                            if !FEPermanentPIN.remove(noteID) { problem = "Не удалось удалить PIN из Keychain"; return }
                        } else {
                            guard FEPermanentPIN.valid(pin), pin == confirmation else {
                                problem = "Введите одинаковые PIN длиной 6–8 цифр"; return
                            }
                            if !FEPermanentPIN.set(noteID, pin: pin) { problem = "Keychain не сохранил PIN"; return }
                        }
                        oldPIN = ""; pin = ""; confirmation = ""
                        onChanged()
                        dismiss()
                    }
                    .disabled(mode == .remove ? !FEPermanentPIN.valid(oldPIN) :
                              (!FEPermanentPIN.valid(pin) || pin != confirmation ||
                               (mode == .change && !FEPermanentPIN.valid(oldPIN))))
                }
                Section {
                    Text("Защита действует только на этом iPhone. Содержимое заметки в локальной базе и Sync21 остаётся незашифрованным. При потере PIN восстановление доступа через интерфейс невозможно.")
                        .font(.caption)
                }
            }
            .navigationTitle("Защита заметки")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Отмена") { dismiss() } } }
            .tint(FEMintTheme.accent)
        }
    }
}
