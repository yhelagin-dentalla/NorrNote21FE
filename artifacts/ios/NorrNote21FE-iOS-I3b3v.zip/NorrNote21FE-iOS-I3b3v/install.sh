#!/usr/bin/env bash
# NORRVIND · NorrNote21FE iOS I3b3v · single-command safe patch installer
# Only modifies the iOS Xcode project, never note DBs, user data or cloud sync.
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${NORRNOTE21FE_ROOT:-$HOME/Projects/NorrNote21FE}"
if [[ ! -d "$ROOT" ]]; then
  echo "ERROR: NorrNote21FE project directory not found: $ROOT" >&2
  exit 2
fi
for cmd in shasum xcodebuild plutil find; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "ERROR: Missing required tool: $cmd" >&2; exit 2; }
done
PROJECT="$(find "$ROOT" -type d -name 'NorrNote21FEiOS.xcodeproj' \
  ! -path '*/.patch-backups/*' ! -path '*/Backups/*' ! -path '*/DerivedData/*' \
  -print | LC_ALL=C sort | head -n 1)"
if [[ -z "$PROJECT" ]]; then
  echo 'ERROR: NorrNote21FEiOS.xcodeproj not found. No changes made.' >&2
  exit 2
fi
PROJECT_DIR="$(dirname "$PROJECT")"
BACKUP_DIR="$PROJECT_DIR/.patch-backups/I3b3v-$(date +%Y%m%d-%H%M%S)"
PAYLOAD="$SCRIPT_DIR/payload"
WIDGET_ASSET="$PROJECT_DIR/NorrNoteWidget/Assets.xcassets/NorrNoteShip.imageset"
APP_ASSETS="$PROJECT_DIR/NorrNote21FEiOS/Assets.xcassets"

SOURCE_PATHS=(
  NorrNote21FEiOS/FEiOSRootView.swift
  NorrNoteWidget/NorrNoteHomeWidget.swift
  NorrNote21FEiOS.xcodeproj/project.pbxproj
)
SOURCE_SHAS=(
  25d28769fc38a95a456e4e7e0cdd9a4d65e4ff0e672a6cc1e44c26b8f94fab02
  b7741970fc0c36a2e3f92c4398cb832adc7a40ddcac454b696a2265696e81e1b
  0d4575f489c158ed9f973e051dc1b36aaaba204381d3cd59e9c9aa8abaa0cb57
)

# Abort on any unrecognised/newer version; never overwrite user's edits.
echo "Project: $PROJECT_DIR"
for i in "${!SOURCE_PATHS[@]}"; do
  rel="${SOURCE_PATHS[$i]}"
  test -f "$PROJECT_DIR/$rel" && test -f "$PAYLOAD/$rel" || {
    echo "ERROR: Missing source or payload file: $rel" >&2; exit 3;
  }
  actual="$(shasum -a 256 "$PROJECT_DIR/$rel" | awk '{print $1}')"
  if [[ "$actual" != "${SOURCE_SHAS[$i]}" ]]; then
    echo "STOP: $rel does not match the installed I3b3u baseline." >&2
    echo "Actual SHA256: $actual" >&2
    echo 'This installer will NOT overwrite later user modifications.' >&2
    exit 3
  fi
done
plutil -lint "$PAYLOAD/NorrNote21FEiOS.xcodeproj/project.pbxproj" >/dev/null

# Resolve the real branded ship BEFORE modifying any project files.
# First reuse the existing widget image, then the application's own imageset,
# then the real, branded application icon. Never draw a generic substitute.
ASSET_MODE='existing'
ASSET_SOURCE=''
if [[ -d "$WIDGET_ASSET" && -f "$WIDGET_ASSET/Contents.json" ]]; then
  ASSET_MODE='existing'
elif [[ -d "$APP_ASSETS/NorrNoteShip.imageset" ]]; then
  ASSET_MODE='imageset'
  ASSET_SOURCE="$APP_ASSETS/NorrNoteShip.imageset"
else
  shipfile="$(find "$APP_ASSETS" -type f \( -iname 'NorrNoteShip.png' -o -iname '*Ship*.png' -o -iname '*NorrNote*Ship*.jpg' \) -print 2>/dev/null | LC_ALL=C sort | head -n 1 || true)"
  if [[ -z "$shipfile" ]]; then
    shipfile="$(find "$APP_ASSETS/AppIcon.appiconset" -type f \( -iname '*.png' -o -iname '*.jpg' -o -iname '*.jpeg' \) -print 2>/dev/null | LC_ALL=C sort | head -n 1 || true)"
  fi
  if [[ -n "$shipfile" ]]; then
    ASSET_MODE='iconfile'
    ASSET_SOURCE="$shipfile"
  else
    echo 'STOP: Original NorrNoteShip image or AppIcon image not found in iOS Assets.xcassets.' >&2
    echo 'No changes made: we will not replace the NORRVIND logo with a generic sailboat.' >&2
    exit 4
  fi
fi

echo "Branded image: $ASSET_MODE ${ASSET_SOURCE:-$WIDGET_ASSET}"
mkdir -p "$BACKUP_DIR/original"
for rel in "${SOURCE_PATHS[@]}"; do
  mkdir -p "$BACKUP_DIR/original/$(dirname "$rel")"
  cp -p "$PROJECT_DIR/$rel" "$BACKUP_DIR/original/$rel"
done
EXISTING_ASSET=0
if [[ -d "$WIDGET_ASSET" ]]; then
  EXISTING_ASSET=1
  mkdir -p "$BACKUP_DIR/original/NorrNoteWidget/Assets.xcassets"
  cp -R "$WIDGET_ASSET" "$BACKUP_DIR/original/NorrNoteWidget/Assets.xcassets/"
fi

PATCH_STARTED=0
BUILD_TEMP=''
rollback() {
  echo 'ROLLBACK: Restoring original I3b3u sources and asset state.' >&2
  for rel in "${SOURCE_PATHS[@]}"; do
    cp -p "$BACKUP_DIR/original/$rel" "$PROJECT_DIR/$rel"
  done
  rm -rf "$WIDGET_ASSET"
  if [[ "$EXISTING_ASSET" == 1 ]]; then
    cp -R "$BACKUP_DIR/original/NorrNoteWidget/Assets.xcassets/NorrNoteShip.imageset" "$WIDGET_ASSET"
  fi
}
on_exit() {
  local rc="$1"
  trap - EXIT
  if [[ -n "$BUILD_TEMP" && -d "$BUILD_TEMP" ]]; then rm -rf "$BUILD_TEMP"; fi
  if [[ "$rc" != 0 && "$PATCH_STARTED" == 1 ]]; then rollback; fi
  exit "$rc"
}
trap 'on_exit "$?"' EXIT
PATCH_STARTED=1
for rel in "${SOURCE_PATHS[@]}"; do
  cp "$PAYLOAD/$rel" "$PROJECT_DIR/$rel"
done
if [[ "$ASSET_MODE" != 'existing' ]]; then
  rm -rf "$WIDGET_ASSET"
fi
if [[ "$ASSET_MODE" == 'imageset' ]]; then
  mkdir -p "$(dirname "$WIDGET_ASSET")"
  cp -R "$ASSET_SOURCE" "$WIDGET_ASSET"
elif [[ "$ASSET_MODE" == 'iconfile' ]]; then
  mkdir -p "$WIDGET_ASSET"
  ext="${ASSET_SOURCE##*.}"
  ext="$(printf '%s' "$ext" | tr '[:upper:]' '[:lower:]')"
  cp "$ASSET_SOURCE" "$WIDGET_ASSET/norrnote-ship.$ext"
  cat > "$WIDGET_ASSET/Contents.json" <<EOF
{
  "images": [{ "filename": "norrnote-ship.$ext", "idiom": "universal" }],
  "info": { "author": "xcode", "version": 1 }
}
EOF
fi

# Check the real iOS project with the user's Xcode toolchain, not just swiftc parse.
echo 'Building NorrNote21FEiOS for iOS Simulator...'
BUILD_TEMP="$(mktemp -d "${TMPDIR:-/tmp}/norrnote-i3b3v-build.XXXXXX")"
set +e
xcodebuild -project "$PROJECT" -scheme NorrNote21FEiOS -configuration Debug \
  -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' \
  -derivedDataPath "$BUILD_TEMP/DerivedData" CODE_SIGNING_ALLOWED=NO build \
  >"$BACKUP_DIR/xcodebuild-simulator.log" 2>&1
RESULT=$?
set -e
if [[ "$RESULT" != 0 ]]; then
  echo 'BUILD FAILED: original source restored automatically.' >&2
  tail -n 60 "$BACKUP_DIR/xcodebuild-simulator.log" >&2
  exit "$RESULT"
fi

echo 'BUILD SUCCEEDED. Patch I3b3v applied.'
echo "Backup: $BACKUP_DIR"
echo 'Next: open Xcode, select physical iPhone, Product -> Run (Cmd-R).'
echo 'The widget AppIntent queues completion without launching the app; the app'
echo 'commits queued completions when activated. No user data has been deleted.'
