import SwiftUI
import WidgetKit
import AppIntents
import UserNotifications

// An intentionally focused home-screen widget: TODAY'S INCOMPLETE notes only.
struct FEWidgetEntry: TimelineEntry {
    let date: Date
    let snapshot: FEWidgetSnapshot?
    let page: Int
    // I3b3l: capture App Group mirror in TimelineProvider on physical iPhone.
    // SwiftUI renderer only reads this immutable value, not the filesystem.
    fileprivate let mirror: [FEI3b3kMirrorNote]?
    fileprivate let transportState: String
}

struct FEWidgetProvider: TimelineProvider {
    func placeholder(in context: Context) -> FEWidgetEntry {
        FEWidgetEntry(date: Date(), snapshot: nil, page: 0, mirror: nil, transportState: "PREVIEW")
    }
    func getSnapshot(in context: Context, completion: @escaping (FEWidgetEntry) -> Void) {
        let now = Date()
        let delivery = FEI3b3kMirror.load()
        completion(FEWidgetEntry(date: now, snapshot: FEWidgetBridge.read(),
                     page: FEWidgetPaging.page(for: context.family),
                     mirror: FEI3b3kMirror.read(on: now, days: delivery.days),
                     transportState: delivery.state))
    }
    func getTimeline(in context: Context, completion: @escaping (Timeline<FEWidgetEntry>) -> Void) {
        let now = Date()
        let midnight = Calendar.current.nextDate(after: now,
                            matching: DateComponents(hour: 0, minute: 0, second: 0),
                            matchingPolicy: .nextTime) ?? now.addingTimeInterval(86400)
        let snapshot = FEWidgetBridge.read()
        let delivery = FEI3b3kMirror.load()
        // WidgetKit can show a static color cue near each scheduled alarm; it
        // cannot perform five exact 1Hz flashes or run freely in background.
        // Entries are hints to iOS and may be rendered later than requested.
        var dates = [now, midnight]
        let todayNotes = snapshot?.notes ?? []
        // One timeline entry for each final scheduled sound (up to iOS budget).
        // A reminder is hidden from the widget after the final scheduled signal,
        // without marking it completed or deleting it from the local database.
        let alarms = todayNotes.filter { note in
            !FEWidgetBridge.isCompletedToday(note, date: now) &&
            FEWidgetReminderWindow.firstFire(note, on: now) != nil
        }.sorted {
            (FEWidgetReminderWindow.finalSoundEnd($0, on: now) ?? .distantFuture) <
            (FEWidgetReminderWindow.finalSoundEnd($1, on: now) ?? .distantFuture)
        }
        for note in alarms {
            if let end = FEWidgetReminderWindow.finalSoundEnd(note, on: now),
               end > now && end < midnight { dates.append(end) }
        }
        // Preserve modest static colour cues around upcoming alarm times.
        for note in alarms.prefix(12) {
            guard let first = FEWidgetReminderWindow.firstFire(note, on: now) else { continue }
            let rawCount = note.alarmPlays ?? 1
            let count = [1, 3, 5].contains(rawCount) ? rawCount : 1
            for repeatIndex in 0..<count {
                let begins = Calendar.current.date(byAdding: .minute,
                                 value: repeatIndex, to: first) ?? first
                if begins > now && begins < midnight {
                    dates.append(begins)
                    let end = begins.addingTimeInterval(10)
                    if end < midnight { dates.append(end) }
                }
            }
        }
        // A snooze is a one-off alert, not a mutation of the note's recurring date.
        for note in todayNotes {
            if let due = FEWidgetSnoozeStore.date(for: note.id), due > now, due < midnight {
                dates.append(due)
                let end = due.addingTimeInterval(10)
                if end < midnight { dates.append(end) }
            }
        }
        // Keep the midnight rollover even if many alarms share one day.
        // I3b3j: cap expensive widget timeline snapshots.
        let otherDates = Array(Set(dates.filter { $0 != now && $0 != midnight })).sorted().prefix(36)
        let entries = ([now] + otherDates + [midnight]).map {
            FEWidgetEntry(date: $0, snapshot: snapshot,
                page: FEWidgetPaging.page(for: context.family),
                mirror: FEI3b3kMirror.read(on: $0, days: delivery.days),
                transportState: delivery.state)
        }
        completion(Timeline(entries: entries, policy: .after(midnight.addingTimeInterval(60))))
    }
}


// I2x2: WidgetKit cannot observe actual notification playback. The best
// available criterion is the scheduled final signal plus its ~3.5s audio.
// Do not change the persisted note: this is a widget-only visibility rule.
private enum FEWidgetReminderWindow {
    static func firstFire(_ note: FEWidgetNote, on day: Date,
                          calendar: Calendar = .current) -> Date? {
        guard ["REMINDER", "BIRTHDAY", "REPEATING"].contains(note.type),
              let millis = note.reminderAtMillis else { return nil }
        let original = Date(timeIntervalSince1970: TimeInterval(millis) / 1000)
        if note.type == "REMINDER" {
            return calendar.isDate(original, inSameDayAs: day) ? original : nil
        }
        if note.type == "BIRTHDAY" {
            let originalDay = calendar.dateComponents([.month, .day], from: original)
            let selectedDay = calendar.dateComponents([.month, .day], from: day)
            guard originalDay.month == selectedDay.month,
                  originalDay.day == selectedDay.day else { return nil }
        } else {
            guard FEWidgetBridge.dueToday(note, date: day) else { return nil }
        }
        let clock = calendar.dateComponents([.hour, .minute], from: original)
        guard let hour = clock.hour, let minute = clock.minute else { return nil }
        return calendar.date(bySettingHour: hour, minute: minute, second: 0, of: day)
    }

    static func finalSoundEnd(_ note: FEWidgetNote, on day: Date) -> Date? {
        guard let first = firstFire(note, on: day) else { return nil }
        let rawCount = note.alarmPlays ?? 1
        let count = [1, 3, 5].contains(rawCount) ? rawCount : 1
        // Matches the application's one-minute interval between signals.
        return Calendar.current.date(byAdding: .minute, value: count - 1, to: first)?
            .addingTimeInterval(5)
    }
}

// The note UUID is validated again by the containing app before showing editor.
private enum FEWidgetNoteLink {
    static func url(for id: String) -> URL {
        let safeID = UUID(uuidString: id)?.uuidString.lowercased() ?? id
        return URL(string: "norrnote21fe://note/\(safeID)")!
    }
}


// I3b.3 — read-only event tags from the containing application's App Group.
// Never mark yearly Dates completed and never hide them after their alarm.
private enum FEI3b3WidgetDates {
    static let suite = "group.su.norrvind.norrnote.fe.ios"
    static let key = "FEI3b3.DatesByUUID.v1"
    static func metadata(for uuid: String) -> [String: Any]? {
        let rows = UserDefaults(suiteName: suite)?.dictionary(forKey: key) as? [String: [String: Any]]
        return rows?[uuid.lowercased()]
    }
    static func due(_ uuid: String, on date: Date) -> Bool {
        guard let row = metadata(for: uuid),
              let raw = row["date"] as? String else { return false }
        let components = raw.split(separator: "-").compactMap { Int($0) }
        guard components.count == 3 else { return false }
        let calendar = Calendar.current
        let day = calendar.dateComponents([.year, .month, .day], from: date)
        if row["annual"] as? Bool != true {
            return day.year == components[0] && day.month == components[1] && day.day == components[2]
        }
        if components[1] == 2 && components[2] == 29 &&
            !(day.year.map { ($0 % 4 == 0 && $0 % 100 != 0) || $0 % 400 == 0 } ?? false) {
            return day.month == 2 && day.day == 28
        }
        return day.month == components[1] && day.day == components[2]
    }
    static func symbol(_ uuid: String) -> String? {
        guard let type = metadata(for: uuid)?["subtype"] as? String else { return nil }
        switch type {
        case "birthday": return "birthday.cake"
        case "wedding": return "heart.fill"
        case "anniversary": return "calendar.badge.clock"
        default: return "bookmark.fill"
        }
    }
    static func age(_ uuid: String, on date: Date) -> Int? {
        guard let data = metadata(for: uuid),
              data["subtype"] as? String == "birthday",
              data["yearKnown"] as? Bool == true,
              let raw = data["date"] as? String,
              let first = Int(raw.prefix(4)) else { return nil }
        let current = Calendar.current.component(.year, from: date)
        let age = current - first
        return age >= 0 && age < 150 ? age : nil
    }
}

// I3b.3b: a one-off snooze is kept in the shared App Group (not Sync21).
private enum FEWidgetSnoozeStore {
    static let key = "FEI3b3b.SnoozeUntil.v1"
    static func date(for uuid: String) -> Date? {
        guard let value = UserDefaults(suiteName: FEI3b3WidgetDates.suite)?
            .dictionary(forKey: key)?[uuid.lowercased()] as? Double else { return nil }
        return Date(timeIntervalSince1970: value)
    }
    static func set(_ date: Date, for uuid: String) {
        guard let defaults = UserDefaults(suiteName: FEI3b3WidgetDates.suite) else { return }
        var rows = defaults.dictionary(forKey: key) as? [String: Double] ?? [:]
        rows = rows.filter { $0.value > Date().addingTimeInterval(-3600).timeIntervalSince1970 }
        rows[uuid.lowercased()] = date.timeIntervalSince1970
        defaults.set(rows, forKey: key)
    }
}

// Executed from the interactive widget without opening the containing app.
// Tests on the actual iPhone are necessary to verify notification privileges.
struct FEWidgetSnoozeTenMinutesIntent: AppIntent {
    static var title: LocalizedStringResource = "Отложить на 10 минут"
    static var openAppWhenRun: Bool { false }
    @Parameter(title: "UUID заметки") var noteID: String

    init() { noteID = "" }
    init(noteID: String) { self.noteID = noteID }

    func perform() async throws -> some IntentResult {
        guard let id = UUID(uuidString: noteID)?.uuidString.lowercased(),
              let note = FEWidgetBridge.read()?.notes.first(where: {
                  $0.id.lowercased() == id && $0.reminderAtMillis != nil
              }) else {
            throw NSError(domain: "NorrNoteWidget", code: 710,
                 userInfo: [NSLocalizedDescriptionKey: "Напоминание не найдено"])
        }
        let center = UNUserNotificationCenter.current()
        let settings = await center.notificationSettings()
        guard [.authorized, .provisional, .ephemeral].contains(settings.authorizationStatus) else {
            throw NSError(domain: "NorrNoteWidget", code: 711,
                 userInfo: [NSLocalizedDescriptionKey: "Разрешите уведомления для NorrNote"])
        }
        let due = Date().addingTimeInterval(10 * 60)
        let content = UNMutableNotificationContent()
        content.title = note.title.isEmpty ? "NorrNote" : note.title
        content.body = UserDefaults(suiteName: FEI3b3WidgetDates.suite)?
            .dictionary(forKey: "FEI3b3b.WidgetPreviews.v1")?[id] as? String ?? "Напоминание"
        content.sound = .default
        content.userInfo = ["feNoteUUID": id, "feWidgetSnoozed": true]
        let request = UNNotificationRequest(
            identifier: "fe-widget-snooze-" + id,
            content: content,
            trigger: UNTimeIntervalNotificationTrigger(timeInterval: 600, repeats: false))
        // Do not announce success or hide alert unless the OS accepted the request.
        try await center.add(request)
        FEWidgetSnoozeStore.set(due, for: id)
        WidgetCenter.shared.reloadTimelines(ofKind: FEWidgetBridge.widgetKind)
        return .result()
    }
}

private enum FEWidgetAlertText {
    static func body(for uuid: String) -> String? {
        UserDefaults(suiteName: FEI3b3WidgetDates.suite)?
            .dictionary(forKey: "FEI3b3b.WidgetPreviews.v1")?[uuid.lowercased()] as? String
    }
}

private enum FEWidgetPalette {
    // I3b3c: Match note colors in app, including legacy colorIndex rendering.
    static let colors: [UInt32] = [0xC9B8E8, 0xA9E2CB, 0xF5C8AE, 0x4A3F5C]
    static func displayIndex(_ raw: Int) -> Int {
        switch raw {
        case 0...3: return raw
        case 4: return 0
        case 5, 6: return 2
        case 7: return 1
        default: return 0
        }
    }
    static func isDark(_ index: Int) -> Bool { displayIndex(index) == 3 }
    static func ink(_ index: Int) -> Color { isDark(index) ? .white : .black }
    static func color(_ index: Int) -> Color {
        let rgb = colors[displayIndex(index)]
        return Color(.sRGB, red: Double((rgb >> 16) & 255) / 255,
                     green: Double((rgb >> 8) & 255) / 255,
                     blue: Double(rgb & 255) / 255, opacity: 1)
    }
}

// I3b3k: resilient read of a read-only, minimal app-group mirror. It is not
// Sync21 and cannot expose note bodies or PIN-protected content.
fileprivate struct FEI3b3kMirrorNote: Identifiable {
    let id: String
    let title: String
    let colorIndex: Int
    let hasImage: Bool
    let hasFile: Bool
    let hasReminder: Bool
    let isDateEvent: Bool

    init?(_ raw: [String: Any]) {
        guard let sourceID = raw["id"] as? String,
              let uuid = UUID(uuidString: sourceID) else { return nil }
        id = uuid.uuidString.lowercased()
        title = raw["title"] as? String ?? ""
        colorIndex = (raw["color"] as? NSNumber)?.intValue ?? 0
        hasImage = raw["image"] as? Bool ?? false
        hasFile = raw["file"] as? Bool ?? false
        hasReminder = raw["alarm"] as? Bool ?? false
        isDateEvent = raw["dateEvent"] as? Bool ?? false
    }
}

// I3b3p: distinguish missing App Group from an empty day.
// Captured once by the TimelineProvider. The SwiftUI view never touches disk.
fileprivate struct FEI3b3pDelivery {
    let days: [String: [FEI3b3kMirrorNote]]?
    let state: String
}

private enum FEI3b3kMirror {
    private static let suite = "group.su.norrvind.norrnote.fe.ios"
    private static let key = "FEI3b3k.WidgetDays.v1"

    static func load() -> FEI3b3pDelivery {
        guard let folder = FileManager.default.containerURL(
            forSecurityApplicationGroupIdentifier: suite) else {
            return FEI3b3pDelivery(days: nil, state: "NO_APP_GROUP")
        }
        let fileURL = folder.appendingPathComponent("FEWidgetDays-v1.json")
        let diskBytes = try? Data(contentsOf: fileURL)
        let defaultsBytes = UserDefaults(suiteName: suite)?.data(forKey: key)
        var invalid = false
        for (name, bytes) in [("FILE", diskBytes), ("DEFAULTS", defaultsBytes)] {
            guard let bytes = bytes else { continue }
            guard let json = (try? JSONSerialization.jsonObject(with: bytes)) as? [String: Any],
                  (json["version"] as? Int) == 1,
                  let rawDays = json["days"] as? [String: [[String: Any]]] else {
                invalid = true
                continue
            }
            let parsed = rawDays.mapValues { $0.compactMap(FEI3b3kMirrorNote.init) }
            // Do not silently discard all rows if a persisted schema changes.
            let rawCount = rawDays.values.reduce(0) { $0 + $1.count }
            let parsedCount = parsed.values.reduce(0) { $0 + $1.count }
            if rawCount > 0 && parsedCount == 0 {
                return FEI3b3pDelivery(days: parsed, state: "BAD_NOTE_IDS")
            }
            return FEI3b3pDelivery(days: parsed, state: "OK_" + name)
        }
        return FEI3b3pDelivery(days: nil, state: invalid ? "BAD_SNAPSHOT" : "NO_SNAPSHOT")
    }

    static func read(on day: Date, days: [String: [FEI3b3kMirrorNote]]?) -> [FEI3b3kMirrorNote]? {
        let parts = Calendar.current.dateComponents([.year, .month, .day], from: day)
        let date = String(format: "%04d-%02d-%02d",
                          parts.year ?? 0, parts.month ?? 0, parts.day ?? 0)
        return days?[date]
    }
}

private struct FEI3b3kDisplayCard: Identifiable {
    let id: String
    let bridged: FEWidgetNote?
    let fallback: FEI3b3kMirrorNote?
}

private struct FEI3b3kFallbackRow: View {
    let note: FEI3b3kMirrorNote
    let compact: Bool
    let height: CGFloat
    let showAttachments: Bool
    @Environment(\.widgetRenderingMode) private var renderingMode

    private var ink: Color {
        renderingMode == .fullColor ? FEWidgetPalette.ink(note.colorIndex) : Color.primary
    }
    var body: some View {
        HStack(spacing: compact ? 2 : 7) {
            Link(destination: FEWidgetNoteLink.url(for: note.id)) {
                HStack(spacing: 6) {
                    Text(note.title.isEmpty ? "Без названия" : note.title)
                        .font(.system(size: compact ? 11 : 15, weight: .semibold, design: .rounded))
                        .lineLimit(1)
                        .minimumScaleFactor(0.75)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    if showAttachments {
                        if note.hasReminder { Image(systemName: "alarm") }
                        if note.hasImage { Image(systemName: "photo") }
                        if note.hasFile { Image(systemName: "doc") }
                    }
                }
                .foregroundStyle(ink)
                .frame(maxWidth: .infinity, minHeight: height - 10)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            if !note.isDateEvent {
                Button(intent: FEWidgetCompleteSilentlyIntent(noteID: note.id)) {
                    Circle()
                        .strokeBorder(ink.opacity(0.75), lineWidth: compact ? 1.5 : 2)
                        .frame(width: compact ? 21 : 25, height: compact ? 21 : 25)
                        .frame(width: compact ? 28 : 34, height: compact ? 28 : 34)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Отметить выполненной: \(note.title)")
            }
        }
        .padding(.leading, compact ? 9 : 15)
        .padding(.trailing, compact ? 4 : 7)
        .frame(maxWidth: .infinity, minHeight: height, maxHeight: height)
        .background {
            RoundedRectangle(cornerRadius: compact ? 13 : 18, style: .continuous)
                .fill(renderingMode == .fullColor
                      ? FEWidgetPalette.color(note.colorIndex) : Color.primary.opacity(0.09))
        }
    }
}

struct FEWidgetHomeView: View {
    let entry: FEWidgetEntry
    @Environment(\.widgetFamily) private var family
    @Environment(\.widgetRenderingMode) private var renderingMode

    private func isTodaysReminder(_ note: FEWidgetNote) -> Bool {
        FEWidgetReminderWindow.firstFire(note, on: entry.date) != nil
    }

    private func hasRemainingAlarm(_ note: FEWidgetNote) -> Bool {
        guard let end = FEWidgetReminderWindow.finalSoundEnd(note, on: entry.date)
        else { return false }
        return entry.date < end
    }

    // I2v: queued completions hide immediately in the widget, before the host
    // app next starts and merges them into its private Sync21 local database.
    private var shown: [FEWidgetNote] {
        let locallyCompleted = FEWidgetPendingCompletion.pendingIDs()
        return (entry.snapshot?.notes ?? []).filter { note in
            if let snooze = FEWidgetSnoozeStore.date(for: note.id),
               entry.date < snooze.addingTimeInterval(10),
               Calendar.current.isDate(snooze, inSameDayAs: entry.date) {
                return true
            }
            if FEI3b3WidgetDates.metadata(for: note.id) != nil {
                return FEI3b3WidgetDates.due(note.id, on: entry.date)
            }
            return !locallyCompleted.contains(note.id.lowercased()) &&
                !FEWidgetBridge.isCompletedToday(note, date: entry.date) &&
                (isTodaysReminder(note)
                    ? hasRemainingAlarm(note)
                    : (note.reminderAtMillis != nil &&
                       ["REMINDER", "BIRTHDAY", "REPEATING"].contains(note.type)
                        ? false : FEWidgetBridge.dueToday(note, date: entry.date)))
        }
    }

    // I3b3k: the same day list as the app, including repeat rules.
    // Preserve legacy results if the app has not yet published the mirror.
    private var displayCards: [FEI3b3kDisplayCard] {
        let primary = shown
        guard let mirrored = entry.mirror else {
            return primary.map { FEI3b3kDisplayCard(id: $0.id, bridged: $0, fallback: nil) }
        }
        let byID = Dictionary((entry.snapshot?.notes ?? []).map {
            ($0.id.lowercased(), $0)
        }, uniquingKeysWith: { first, _ in first })
        let pending = FEWidgetPendingCompletion.pendingIDs()
        let valid = mirrored.filter { !pending.contains($0.id) }
        let seen = Set(valid.map(\.id))
        let recovered = valid.map { item in
            FEI3b3kDisplayCard(id: item.id, bridged: byID[item.id], fallback: item)
        }
        // Do not hide valid legacy cards if a stale mirror has fewer notes.
        return recovered + primary.filter { !seen.contains($0.id.lowercased()) }.map {
            FEI3b3kDisplayCard(id: $0.id, bridged: $0, fallback: nil)
        }
    }

    // Best-effort STATIC alarm highlight, NOT a flashing animation.
    // A local notification doesn't execute the widget extension; the OS
    // controls when a precomputed timeline entry actually becomes visible.
    private var highlightedAlarm: FEWidgetNote? {
        shown.first { note in
            if let snooze = FEWidgetSnoozeStore.date(for: note.id) {
                if entry.date < snooze { return false }
                if entry.date < snooze.addingTimeInterval(10) { return true }
            }
            guard isTodaysReminder(note),
                  let first = FEWidgetReminderWindow.firstFire(note, on: entry.date)
            else { return false }
            let rawCount = note.alarmPlays ?? 1
            let count = [1, 3, 5].contains(rawCount) ? rawCount : 1
            return (0..<count).contains { index in
                let begin = first.addingTimeInterval(TimeInterval(index * 60))
                return entry.date >= begin && entry.date < begin.addingTimeInterval(10)
            }
        }
    }
    // I2r: visual layout follows the supplied NorrNote reference image.
    // Layout is intentionally compact because iOS widget sizes differ by device.
    private var isSmall: Bool { family == .systemSmall }
    private var isLarge: Bool { family == .systemLarge }
    private var visibleCount: Int { isLarge ? 5 : 2 }
    private var pageCount: Int { max(1, (displayCards.count + visibleCount - 1) / visibleCount) }
    private var safePage: Int { min(max(0, entry.page), pageCount - 1) }
    private var pagedCards: [FEI3b3kDisplayCard] {
        Array(displayCards.dropFirst(safePage * visibleCount).prefix(visibleCount))
    }
    private var cardHeight: CGFloat { isSmall ? 36 : (isLarge ? 43 : 42) }
    private var cardSpacing: CGFloat { isLarge ? 8 : 6 }
    private var outerInset: CGFloat { isSmall ? 9 : (isLarge ? 14 : 10) }
    private var headerHeight: CGFloat { isSmall ? 31 : (isLarge ? 40 : 36) }
    private var headerGap: CGFloat { isSmall ? 6 : (isLarge ? 11 : 8) }

    private var navyInk: Color {
        Color(.sRGB, red: 0.075, green: 0.14, blue: 0.245, opacity: 1)
    }

    // I2u: pager is centered on the VISIBLE CARDS block, not on the widget/header.
    // Apple WidgetKit does not allow free finger-scrolling inside the widget.
    private var pager: some View {
        VStack(spacing: 3) {
            Button(intent: FEWidgetSetPageIntent(
                familyKey: FEWidgetPaging.familyKey(family), page: max(0, safePage - 1))) {
                Image(systemName: "chevron.up")
                    .font(.system(size: 17, weight: .bold))
                    .frame(width: 34, height: 31)
                    .contentShape(Rectangle())
            }
            .disabled(safePage == 0)
            .accessibilityLabel("Заметки выше")

            // Count CARD positions instead of only the current page.
            // Example: 3–4/9 means cards 3 and 4 of nine available notes.
            Text("\(safePage * visibleCount + 1)–\(min(displayCards.count, (safePage + 1) * visibleCount))/\(displayCards.count)")
                .font(.system(size: isSmall ? 8.5 : 10, weight: .semibold, design: .rounded))
                .monospacedDigit()
                .minimumScaleFactor(0.72)
                .lineLimit(1)
                .accessibilityLabel("Заметки \(safePage * visibleCount + 1)–\(min(displayCards.count, (safePage + 1) * visibleCount)) из \(displayCards.count)")

            Button(intent: FEWidgetSetPageIntent(
                familyKey: FEWidgetPaging.familyKey(family), page: min(pageCount - 1, safePage + 1))) {
                Image(systemName: "chevron.down")
                    .font(.system(size: 17, weight: .bold))
                    .frame(width: 34, height: 31)
                    .contentShape(Rectangle())
            }
            .disabled(safePage >= pageCount - 1)
            .accessibilityLabel("Заметки ниже")
        }
        .frame(width: isSmall ? 38 : 47)
        .buttonStyle(.plain)
        .foregroundStyle(renderingMode == .fullColor ? navyInk : Color.primary)
        .opacity(0.82)
        .accessibilityElement(children: .contain)
    }

    private var brandHeader: some View {
        HStack(alignment: .center, spacing: isSmall ? 6 : 9) {
            Image("NorrNoteShip")
                .resizable()
                .scaledToFit()
                .frame(width: isSmall ? 21 : (isLarge ? 33 : 27),
                       height: isSmall ? 21 : (isLarge ? 33 : 27))
                .widgetAccentable()
                .accessibilityHidden(true)

            Text("NorrNote")
                .font(.system(size: isSmall ? 14 : (isLarge ? 21 : 19),
                              weight: .semibold, design: .rounded))
                .foregroundStyle(renderingMode == .fullColor ? navyInk : Color.primary)
                .lineLimit(1)
                .minimumScaleFactor(0.75)
                .widgetAccentable()

            Spacer(minLength: 0)

            // I2v: real deep link. Never create a note inside the widget
            // extension: the host store is the single source of truth.
            Link(destination: URL(string: "norrnote21fe://new")!) {
                Image(systemName: "plus")
                    .font(.system(size: isSmall ? 19 : 23, weight: .semibold))
                    .foregroundStyle(renderingMode == .fullColor ? navyInk : Color.primary)
                    .frame(width: isSmall ? 30 : 38, height: isSmall ? 30 : 38)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Создать заметку")
        }
        .frame(height: headerHeight)
        // Symmetric ship/+ clearances from rounded outer corners.
        .padding(.leading, isSmall ? 5 : 9)
        .padding(.trailing, isSmall ? 5 : 9)
    }

    @ViewBuilder private func alertScreen(for note: FEWidgetNote) -> some View {
        let alarmInk = renderingMode == .fullColor ? FEWidgetPalette.ink(note.colorIndex) : Color.primary
        VStack(alignment: .leading, spacing: isSmall ? 6 : 10) {
            HStack(spacing: 7) {
                Image(systemName: FEI3b3WidgetDates.symbol(note.id) ?? "alarm.fill")
                    .foregroundStyle(alarmInk)
                Text("NorrNote")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(alarmInk.opacity(0.65))
            }
            Text(note.title + (FEI3b3WidgetDates.age(note.id, on: entry.date)
                              .map { " — \($0) лет" } ?? ""))
                .font(.system(size: isSmall ? 16 : 21, weight: .bold, design: .rounded))
                .foregroundStyle(alarmInk)
                .lineLimit(isSmall ? 2 : 3)
            if let description = FEWidgetAlertText.body(for: note.id), !description.isEmpty {
                Text(description)
                    .font(.system(size: isSmall ? 11 : 14))
                    .foregroundStyle(alarmInk.opacity(0.82))
                    .lineLimit(isSmall ? 2 : 4)
            }
            Spacer(minLength: 1)
            Button(intent: FEWidgetSnoozeTenMinutesIntent(noteID: note.id)) {
                Text("Отложить на 10 минут")
                    .font(.system(size: isSmall ? 10 : 13, weight: .semibold))
                    .foregroundStyle(Color(red: 0.13, green: 0.39, blue: 0.27))
                    .lineLimit(1)
                    .minimumScaleFactor(0.65)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, isSmall ? 7 : 11)
                    .background(.white.opacity(0.80), in: Capsule())
                    .overlay(Capsule().stroke(Color.green.opacity(0.22), lineWidth: 1))
            }
            .buttonStyle(.plain)
        }
        .padding(isSmall ? 12 : 17)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            if let alarm = highlightedAlarm {
                alertScreen(for: alarm)
            } else {
            brandHeader
                .padding(.bottom, headerGap)

            if displayCards.isEmpty {
                Spacer(minLength: 0)
                Text(entry.transportState == "NO_APP_GROUP"
                     ? "Нет доступа к App Group"
                     : entry.snapshot == nil && entry.mirror == nil
                         ? "Откройте NorrNote и обновите виджет"
                         : "На сегодня нет записей")
                    .font(.system(size: isSmall ? 11 : 13, weight: .medium))
                    .foregroundStyle(renderingMode == .fullColor
                                     ? navyInk.opacity(0.65) : Color.secondary)
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: .infinity)
                #if DEBUG
                Text("Widget: \(entry.transportState) · notes=\(entry.mirror?.count ?? -1)")
                    .font(.system(size: 9, weight: .regular))
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.6)
                    .frame(maxWidth: .infinity)
                #endif
                Spacer(minLength: 0)
            } else {
                HStack(alignment: .center, spacing: 5) {
                    VStack(spacing: cardSpacing) {
                        ForEach(pagedCards) { card in
                            if let note = card.bridged {
                                FEWidgetRow(note: note,
                                            onDate: entry.date,
                                            rowHeight: cardHeight,
                                            compact: isSmall,
                                            showAttachments: !isSmall)
                            } else if let fallback = card.fallback {
                                FEI3b3kFallbackRow(note: fallback,
                                                     compact: isSmall,
                                                     height: cardHeight,
                                                     showAttachments: !isSmall)
                            }
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    if pageCount > 1 { pager }
                }
                Spacer(minLength: 0)
            }
            }
        }
        .padding(highlightedAlarm == nil ? outerInset : 0)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        // I3b3j: stable SwiftUI widget backdrop; no oversized image or GeometryReader.
        // The ship, brand, controls and empty-state text remain visible even
        // if an image asset is missing. The system can remove this background
        // in Tinted/StandBy modes, as required by WidgetKit.
        .containerBackground(for: .widget) {
            ZStack {
                LinearGradient(
                    colors: [
                        Color(red: 0.970, green: 0.959, blue: 0.988),
                        Color(red: 0.932, green: 0.918, blue: 0.973)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                if let alarm = highlightedAlarm, renderingMode == .fullColor {
                    FEWidgetPalette.color(alarm.colorIndex)
                        .opacity(FEWidgetPalette.isDark(alarm.colorIndex) ? 0.98 : 0.16)
                }
            }
        }
    }
}

private struct FEWidgetRow: View {
    let note: FEWidgetNote
    let onDate: Date
    let rowHeight: CGFloat
    let compact: Bool
    let showAttachments: Bool
    @Environment(\.widgetRenderingMode) private var renderingMode

    private var navyInk: Color {
        Color(.sRGB, red: 0.075, green: 0.14, blue: 0.245, opacity: 1)
    }

    private var rowInk: Color { FEWidgetPalette.ink(note.colorIndex) }

    private var roundness: CGFloat { compact ? 13 : 18 }

    private var cardSurface: some View {
        let shape = RoundedRectangle(cornerRadius: roundness, style: .continuous)
        return shape
            .fill(renderingMode == .fullColor
                  ? FEWidgetPalette.color(note.colorIndex)
                  : Color.primary.opacity(0.09))
            .overlay {
                shape.strokeBorder(renderingMode == .fullColor
                    ? (FEWidgetPalette.isDark(note.colorIndex) ? Color.white.opacity(0.28) : Color.black.opacity(0.07))
                    : Color.white.opacity(0.17), lineWidth: 1)
            }
            .shadow(color: renderingMode == .fullColor
                    ? navyInk.opacity(0.085) : Color.clear,
                    radius: 5, x: 0, y: 3)
    }

    var body: some View {
        HStack(spacing: compact ? 2 : 7) {
            Link(destination: FEWidgetNoteLink.url(for: note.id)) {
                HStack(spacing: compact ? 2 : 7) {
                    if let symbol = FEI3b3WidgetDates.symbol(note.id) {
                        Image(systemName: symbol)
                            .font(.system(size: compact ? 11 : 15, weight: .semibold))
                            .foregroundStyle(renderingMode == .fullColor ? rowInk : Color.primary)
                            .accessibilityHidden(true)
                    }
                    Text((note.title.isEmpty ? "Без названия" : note.title) +
                         (FEI3b3WidgetDates.age(note.id, on: onDate)
                          .map { " · \($0)" } ?? ""))
                        .font(.system(size: compact ? 11 : 15,
                                      weight: .semibold, design: .rounded))
                        .foregroundStyle(renderingMode == .fullColor ? rowInk : Color.primary)
                        .lineLimit(1)
                        .minimumScaleFactor(0.75)
                        .frame(maxWidth: .infinity, alignment: .leading)

                    if showAttachments {
                        HStack(spacing: 5) {
                            if note.reminderAtMillis != nil {
                                Image(systemName: "alarm")
                                    .accessibilityLabel("Напоминание")
                            }
                            if note.hasImage {
                                Image(systemName: "photo")
                                    .accessibilityLabel("Изображение")
                            }
                            if note.hasFile {
                                Image(systemName: "doc")
                                    .accessibilityLabel("Файл")
                            }
                        }
                        .font(.system(size: 15, weight: .medium))
                        .foregroundStyle(renderingMode == .fullColor
                                         ? rowInk.opacity(0.82) : Color.secondary)
                        .fixedSize(horizontal: true, vertical: false)
                    }

                }
                .frame(maxWidth: .infinity, minHeight: rowHeight - 10, alignment: .leading)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Редактировать: \(note.title)")

            // I2v: extension-local AppIntent; NEVER opens the containing app.
            // Durable action is replayed into FEiOSStore when it becomes active.
            if FEI3b3WidgetDates.metadata(for: note.id) == nil {
                Button(intent: FEWidgetCompleteSilentlyIntent(noteID: note.id)) {
                Circle()
                    .fill(Color.clear) // I2u: transparent completion marker, no colored disc.
                    .overlay {
                        Circle().strokeBorder(renderingMode == .fullColor
                                              ? rowInk.opacity(0.76) : Color.primary.opacity(0.68),
                                              lineWidth: compact ? 1.5 : 2)
                    }
                    .frame(width: compact ? 21 : 25, height: compact ? 21 : 25)
                    .frame(width: compact ? 28 : 34, height: compact ? 28 : 34)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Отметить выполненной: \(note.title)")
            }
        }
        .padding(.leading, compact ? 9 : 15)
        .padding(.trailing, compact ? 4 : 7)
        .frame(maxWidth: .infinity, minHeight: rowHeight, maxHeight: rowHeight)
        .background { cardSurface }
    }
}

struct NorrNoteHomeWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: FEWidgetBridge.widgetKind, provider: FEI3b3rProvider()) { entry in
            FEI3b3rView(entry: entry)
        }
        .configurationDisplayName("NorrNote — на день")
        .description("Дневные невыполненные заметки. Нажмите кружок для выполнения.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge])
        .contentMarginsDisabled()
    }
}

@main
struct NorrNoteWidgetBundle: WidgetBundle {
    var body: some Widget {
        NorrNoteHomeWidget()
        // I3b3s: the test widget is ALWAYS compiled now. Before I3b3s it was
        // wrapped in #if DEBUG, but the widget target overrode DEBUG with
        // WIDGET_EXTENSION, so it never reached the iPhone widget gallery.
        // Remove this line after the diagnosis is finished.
        FEI3b3qDiagnosticWidget()
    }
}


// I3b3q/I3b3s — independent, diagnostic WidgetKit view.
// No dependency on the original card UI, AppIntents, images or FEWidgetBridge.
private struct FEI3b3qEntry: TimelineEntry {
    let date: Date
    let titles: [String]
    let state: String
}

private enum FEI3b3qReader {
    private static let group = "group.su.norrvind.norrnote.fe.ios"
    private static let defaultsKey = "FEI3b3k.WidgetDays.v1"

    static func read(_ now: Date) -> FEI3b3qEntry {
        guard let folder = FileManager.default.containerURL(
            forSecurityApplicationGroupIdentifier: group) else {
            return FEI3b3qEntry(date: now, titles: [], state: "NO_GROUP")
        }
        let parts = Calendar.current.dateComponents([.year, .month, .day], from: now)
        let key = String(format: "%04d-%02d-%02d", parts.year ?? 0,
                         parts.month ?? 0, parts.day ?? 0)
        let file = folder.appendingPathComponent("FEWidgetDays-v1.json")
        let disk = try? Data(contentsOf: file)
        let defaults = UserDefaults(suiteName: group)?.data(forKey: defaultsKey)
        for (label, bytes) in [("FILE", disk), ("DEFAULTS", defaults)] {
            guard let bytes = bytes,
                  let json = (try? JSONSerialization.jsonObject(with: bytes)) as? [String: Any],
                  let days = json["days"] as? [String: Any] else { continue }
            let cards = days[key] as? [[String: Any]] ?? []
            let titles = cards.prefix(5).map { ($0["title"] as? String).flatMap {
                $0.isEmpty ? nil : $0
            } ?? "Без названия" }
            return FEI3b3qEntry(date: now, titles: titles,
                                state: "OK_\(label): \(cards.count)")
        }
        return FEI3b3qEntry(date: now, titles: [],
                            state: disk == nil ? "NO_FILE" : "BAD_JSON")
    }
}

private struct FEI3b3qProvider: TimelineProvider {
    func placeholder(in context: Context) -> FEI3b3qEntry {
        FEI3b3qEntry(date: Date(), titles: ["Пример заметки"], state: "PLACEHOLDER")
    }
    func getSnapshot(in context: Context, completion: @escaping (FEI3b3qEntry) -> Void) {
        completion(FEI3b3qReader.read(Date()))
    }
    func getTimeline(in context: Context, completion: @escaping (Timeline<FEI3b3qEntry>) -> Void) {
        let now = Date()
        completion(Timeline(entries: [FEI3b3qReader.read(now)],
                            policy: .after(now.addingTimeInterval(15 * 60))))
    }
}

private struct FEI3b3qView: View {
    let entry: FEI3b3qEntry
    @Environment(\.widgetFamily) private var family
    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack(spacing: 7) {
                Image(systemName: "sailboat.fill")
                    .foregroundStyle(Color(red: 0.36, green: 0.26, blue: 0.56))
                Text("NorrNote · TEST I3b3s")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.black)
            }
            Text(entry.state)
                .font(.system(size: 11, weight: .medium, design: .monospaced))
                .foregroundStyle(Color(red: 0.25, green: 0.31, blue: 0.42))
            if entry.titles.isEmpty {
                Text("Заметок не получено")
                    .font(.system(size: 12))
                    .foregroundStyle(.black)
            } else {
                ForEach(Array(entry.titles.prefix(family == .systemLarge ? 5 : 2).enumerated()),
                        id: \.offset) { item in
                    Text("• " + item.element)
                        .font(.system(size: 12, weight: .medium))
                        .foregroundStyle(.black)
                        .lineLimit(1)
                }
            }
            Spacer(minLength: 0)
        }
        .padding(12)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .containerBackground(for: .widget) {
            Color(red: 0.94, green: 0.90, blue: 0.98)
        }
    }
}

private struct FEI3b3qDiagnosticWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "su.norrvind.norrnote.fe.ios.widget.diag.i3b3q",
                            provider: FEI3b3qProvider()) { entry in
            FEI3b3qView(entry: entry)
        }
        .configurationDisplayName("NorrNote — проверка")
        .description("Проверка запуска виджета и чтения заметок на iPhone")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge])
        .contentMarginsDisabled()
    }
}

// I3b3v: interactive completion queue for the active production widget.
// The widget extension cannot safely write the main app's private database.
// A validated, atomic request is stored in the App Group and persisted by the
// app when it next becomes active. Each note ID has its own idempotent file.
private enum FEI3b3vCompletedQueue {
    static let group = "group.su.norrvind.norrnote.fe.ios"
    static let folderName = "WidgetCompletionRequests-v1"

    static func directory() -> URL? {
        FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group)?
            .appendingPathComponent(folderName, isDirectory: true)
    }

    static func pendingIDs() -> Set<String> {
        guard let dir = directory(),
              let names = try? FileManager.default.contentsOfDirectory(atPath: dir.path) else { return [] }
        return Set(names.compactMap { name in
            guard name.hasSuffix(".json") else { return nil }
            let id = String(name.dropLast(5))
            return UUID(uuidString: id)?.uuidString.lowercased()
        })
    }
}

struct FEI3b3vMarkCompletedIntent: AppIntent {
    static var title: LocalizedStringResource = "Отметить заметку выполненной"
    static var openAppWhenRun: Bool = false

    @Parameter(title: "Идентификатор заметки") var noteID: String

    init() { noteID = "" }
    init(noteID: String) { self.noteID = noteID }

    func perform() async throws -> some IntentResult {
        guard let id = UUID(uuidString: noteID)?.uuidString.lowercased(),
              let dir = FEI3b3vCompletedQueue.directory() else { return .result() }
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let record: [String: Any] = [
            "id": id,
            "atMillis": Int64(Date().timeIntervalSince1970 * 1000)
        ]
        let bytes = try JSONSerialization.data(withJSONObject: record)
        try bytes.write(to: dir.appendingPathComponent(id + ".json"), options: [.atomic])
        WidgetCenter.shared.reloadTimelines(ofKind: FEWidgetBridge.widgetKind)
        return .result()
    }
}

// I3b3r — stable production home widget. The independent I3b3q test widget
// rendered real cards on iPhone, so both the reader and renderer are intentionally
// small and share its verified JSON source. The previous complex view is retained
// for reference but is no longer connected to the active main Widget configuration.
private struct FEI3b3rCard: Identifiable {
    let id: String
    let title: String
    let color: Int
    let hasImage: Bool
    let hasFile: Bool
    let hasAlarm: Bool
    let isDateEvent: Bool

    init?(_ fields: [String: Any]) {
        guard let string = fields["id"] as? String,
              let uuid = UUID(uuidString: string) else { return nil }
        id = uuid.uuidString.lowercased()
        title = (fields["title"] as? String).flatMap { $0.isEmpty ? nil : $0 } ?? "Без названия"
        color = (fields["color"] as? NSNumber)?.intValue ?? 0
        hasImage = fields["image"] as? Bool ?? false
        hasFile = fields["file"] as? Bool ?? false
        hasAlarm = fields["alarm"] as? Bool ?? false
        isDateEvent = fields["dateEvent"] as? Bool ?? false
    }
}

private struct FEI3b3rEntry: TimelineEntry {
    let date: Date
    let cards: [FEI3b3rCard]
    let status: String
    let page: Int
}

private enum FEI3b3rSource {
    static let group = "group.su.norrvind.norrnote.fe.ios"
    static let key = "FEI3b3k.WidgetDays.v1"

    static func read(at time: Date, family: WidgetFamily) -> FEI3b3rEntry {
        let page = FEWidgetPaging.page(for: family)
        guard let folder = FileManager.default.containerURL(
            forSecurityApplicationGroupIdentifier: group) else {
            return FEI3b3rEntry(date: time, cards: [], status: "NO_GROUP", page: page)
        }
        let file = folder.appendingPathComponent("FEWidgetDays-v1.json")
        let disk = try? Data(contentsOf: file)
        let stored = UserDefaults(suiteName: group)?.data(forKey: key)
        let parts = Calendar.current.dateComponents([.year, .month, .day], from: time)
        let today = String(format: "%04d-%02d-%02d", parts.year ?? 0,
                           parts.month ?? 0, parts.day ?? 0)
        for (origin, bytes) in [("FILE", disk), ("DEFAULTS", stored)] {
            guard let bytes = bytes,
                  let json = (try? JSONSerialization.jsonObject(with: bytes)) as? [String: Any],
                  (json["version"] as? NSNumber)?.intValue == 1,
                  let days = json["days"] as? [String: Any] else { continue }
            let records = days[today] as? [[String: Any]] ?? []
            let pending = FEI3b3vCompletedQueue.pendingIDs()
            let visible = records.compactMap(FEI3b3rCard.init)
                .filter { !pending.contains($0.id) }
            return FEI3b3rEntry(date: time, cards: visible,
                                 status: "OK_\(origin)", page: page)
        }
        return FEI3b3rEntry(date: time, cards: [],
                             status: disk == nil ? "NO_FILE" : "BAD_JSON", page: page)
    }
}

private struct FEI3b3rProvider: TimelineProvider {
    func placeholder(in context: Context) -> FEI3b3rEntry {
        FEI3b3rEntry(date: Date(), cards: [], status: "PLACEHOLDER", page: 0)
    }
    func getSnapshot(in context: Context, completion: @escaping (FEI3b3rEntry) -> Void) {
        completion(FEI3b3rSource.read(at: Date(), family: context.family))
    }
    func getTimeline(in context: Context, completion: @escaping (Timeline<FEI3b3rEntry>) -> Void) {
        let now = Date()
        let entry = FEI3b3rSource.read(at: now, family: context.family)
        // Keep scheduling inexpensive on real devices. iOS decides the exact
        // reload moment; the app's WidgetCenter request handles note edits.
        completion(Timeline(entries: [entry], policy: .after(now.addingTimeInterval(15 * 60))))
    }
}

private struct FEI3b3rView: View {
    let entry: FEI3b3rEntry
    @Environment(\.widgetFamily) private var family
    // I3b3s: in Tinted / Clear home-screen modes iOS removes the background and
    // repaints every opaque shape with the tint color. Opaque card fills then
    // turn into solid white blocks covering the (also white) text.
    @Environment(\.widgetRenderingMode) private var renderingMode
    private var fullColor: Bool { renderingMode == .fullColor }

    private var compact: Bool { family == .systemSmall }
    private var large: Bool { family == .systemLarge }
    private var itemsPerPage: Int { large ? 5 : 2 }
    private var pageCount: Int { max(1, (entry.cards.count + itemsPerPage - 1) / itemsPerPage) }
    private var safePage: Int { min(max(entry.page, 0), pageCount - 1) }
    private var visible: [FEI3b3rCard] {
        Array(entry.cards.dropFirst(safePage * itemsPerPage).prefix(itemsPerPage))
    }
    private var ink: Color { fullColor ? Color(red: 0.13, green: 0.17, blue: 0.27) : .primary }

    private func surface(for color: Int) -> Color {
        guard fullColor else { return Color.primary.opacity(0.12) }
        switch FEWidgetPalette.displayIndex(color) {
        case 0: return Color(red: 0.79, green: 0.72, blue: 0.91)
        case 1: return Color(red: 0.66, green: 0.89, blue: 0.79)
        case 2: return Color(red: 0.96, green: 0.78, blue: 0.68)
        default: return Color(red: 0.29, green: 0.25, blue: 0.36)
        }
    }
    private func foreground(for color: Int) -> Color {
        guard fullColor else { return .primary }
        return FEWidgetPalette.displayIndex(color) == 3 ? .white : .black
    }

    private func card(_ item: FEI3b3rCard) -> some View {
        let textColor = foreground(for: item.color)
        return HStack(spacing: compact ? 5 : 8) {
            Link(destination: FEWidgetNoteLink.url(for: item.id)) {
                HStack(spacing: 5) {
                    Text(item.title)
                        .font(.system(size: compact ? 11 : 14, weight: .semibold))
                        .lineLimit(1)
                        .minimumScaleFactor(0.75)
                    Spacer(minLength: 0)
                    if !compact {
                        if item.hasAlarm { Image(systemName: "alarm") }
                        if item.hasImage { Image(systemName: "photo") }
                        if item.hasFile { Image(systemName: "doc") }
                    }
                }
                .foregroundStyle(textColor)
                .frame(maxWidth: .infinity, minHeight: compact ? 30 : 36)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            if !item.isDateEvent {
                Button(intent: FEI3b3vMarkCompletedIntent(noteID: item.id)) {
                    Circle()
                        .strokeBorder(textColor.opacity(0.8), lineWidth: 2)
                        .frame(width: compact ? 20 : 23, height: compact ? 20 : 23)
                        .frame(width: compact ? 25 : 29, height: compact ? 25 : 29)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Отметить выполненной: \(item.title)")
            }
        }
        .padding(.horizontal, compact ? 7 : 10)
        .frame(maxWidth: .infinity)
        .background(surface(for: item.color), in: RoundedRectangle(cornerRadius: 12))
    }

    private var controls: some View {
        HStack(spacing: 10) {
            Button(intent: FEWidgetSetPageIntent(
                familyKey: FEWidgetPaging.familyKey(family), page: max(0, safePage - 1))) {
                Image(systemName: "chevron.left")
            }
            .disabled(safePage == 0)
            Text("\(safePage + 1) / \(pageCount)")
                .font(.system(size: 11, weight: .semibold))
                .monospacedDigit()
            Button(intent: FEWidgetSetPageIntent(
                familyKey: FEWidgetPaging.familyKey(family), page: min(pageCount - 1, safePage + 1))) {
                Image(systemName: "chevron.right")
            }
            .disabled(safePage == pageCount - 1)
        }
        .buttonStyle(.plain)
        .foregroundStyle(ink)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: compact ? 5 : 7) {
            HStack(spacing: 7) {
                // Exact NORRVIND ship asset copied into the widget target by the installer.
                Image("NorrNoteShip")
                    .resizable()
                    .scaledToFit()
                    .frame(width: compact ? 23 : 30, height: compact ? 23 : 30)
                    .widgetAccentable()
                Text("NorrNote")
                    .font(.system(size: compact ? 14 : (large ? 19 : 17), weight: .bold))
                    .lineLimit(1)
                    .widgetAccentable()
                Spacer(minLength: 0)
                Link(destination: URL(string: "norrnote21fe://new")!) {
                    Image(systemName: "plus")
                        .font(.system(size: compact ? 16 : 20, weight: .semibold))
                        .frame(width: 30, height: 30)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Добавить заметку")
            }
            .foregroundStyle(ink)
            if entry.cards.isEmpty {
                Spacer(minLength: 0)
                Text(entry.status.hasPrefix("OK_")
                     ? "На сегодня нет записей"
                     : "Нет доступа к заметкам: \(entry.status)")
                    .font(.system(size: compact ? 11 : 13))
                    .foregroundStyle(ink)
                    .lineLimit(3)
                Spacer(minLength: 0)
            } else {
                ForEach(visible) { item in card(item) }
                if pageCount > 1 { controls }
                Spacer(minLength: 0)
            }
        }
        .padding(compact ? 9 : 12)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .containerBackground(for: .widget) {
            Color(red: 0.95, green: 0.93, blue: 0.98)
        }
    }
}
