# NorrNote21FE iOS — I3b3v

**Baseline:** installed I3b3u, `CURRENT_PROJECT_VERSION=101`. **Target build:** 102.

This is a targeted iOS patch with three changes:

1. **Widget completion button:** The production `FEI3b3rView` now uses the `FEI3b3vMarkCompletedIntent`. It atomically writes a request per UUID to the shared App Group, then reloads the widget. The production timeline hides queued notes immediately. The containing app reads those requests when started/activated and persists `toggleCompleted` on the date of the tap, idempotently. This is **not** a private-database write from the widget. Completion is fully persisted only after the app runs. Annual Date events remain excluded.
2. **Original ship image:** `sailboat.fill` in the production widget header is replaced with `Image("NorrNoteShip")`. The installer copies the user's existing branded app imageset/icon into the widget asset catalog, only when necessary. If no real asset exists, installation stops before modifying the project.
3. **Speech error `kAFAssistantErrorDomain 216`:** Protects against stale callbacks and overlapping starts; ordinary stops call `finish()` instead of `cancel()`. With ordinary notes, one fallback from on-device to Apple speech service is attempted on error 216; PIN-protected notes never use network recognition. Already-transcribed words are retained. This is a defensive mitigation: the code 216 itself is not precisely documented by Apple.

The install script validates SHA-256 of all three original I3b3u project files, backs them up, applies only these files and the logo asset, checks Xcode simulator build and rolls back on failure. Any other state aborts safely. It doesn't touch existing local note databases or Sync21, and it does not install onto the phone.

## Install

Download the ZIP from the project's GitHub artifacts folder; expand it and run `bash install.sh` from the extracted package. Rebuild/install on the **physical iPhone** with `Product → Run` in Xcode. If the widget doesn't refresh after updating to build 102, remove/re-add the home screen widget, then restart the iPhone without deleting the app or its data.

## Test on iPhone

- Tap the circle in the widget: the note disappears from the widget; reopen the containing app and check the note is completed. Repeat for several notes, including a repeating note, and verify annual Date cards have no completion circle.
- Header displays the branded NORRVIND ship in the standard appearance, not the SF Symbols boat. Check standard and tinted/clear modes.
- Start microphone transcription, dictate 3 or more phrases with pauses, stop manually, repeat. If `216` persists, capture the device's console messages **from `NorrNote21FEiOS` and `assistantd`**, not all system processes.
- Modify title, body, date and time of a note, save, reopen and restart, to ensure I3b3u's editor persistence fixes weren't regressed.

**Not yet verified:** real Xcode build, hardware App Intent execution, hardware speech recognition. All these checks run on the user's Mac and iPhone.
