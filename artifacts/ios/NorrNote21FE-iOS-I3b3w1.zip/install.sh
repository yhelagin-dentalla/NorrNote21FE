#!/usr/bin/env bash
# NORRVIND • NorrNote21FE iOS I3b3w1 installer (build 103)
# Real-device installation is mandatory; build-for-simulator alone is not success.
set -euo pipefail

PACKAGE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
BASE="${NORRNOTE21FE_ROOT:-$HOME/Projects/NorrNote21FE}"
for cmd in shasum find xcodebuild xcrun plutil sips; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "STOP: required command missing: $cmd" >&2; exit 2; }
done
[[ -d "$BASE" ]] || { echo "STOP: project not found: $BASE" >&2; exit 2; }

# Device selector and source project selector are separate, never rely on
# lexicographic 'find | sort | head -1' to guess the working Xcode project.
EXPLICIT_ROOT="${NORRNOTE21FE_PROJECT_ROOT:-}"
DEVICE_ARG=''
LIST_ONLY=0
while (( $# )); do
  case "$1" in
    --project)
      [[ $# -ge 2 && -n "$2" ]] || { echo 'Usage: --project /absolute/path/to/project-root' >&2; exit 2; }
      EXPLICIT_ROOT="$2"; shift 2 ;;
    --device)
      [[ $# -ge 2 && -n "$2" ]] || { echo 'Usage: --device iPhone-ID' >&2; exit 2; }
      DEVICE_ARG="$2"; shift 2 ;;
    --list-projects)
      LIST_ONLY=1; shift ;;
    --*) echo "STOP: unknown option $1" >&2; exit 2 ;;
    *)
      [[ -z "$DEVICE_ARG" ]] || { echo "STOP: unknown extra argument $1" >&2; exit 2; }
      DEVICE_ARG="$1"; shift ;;
  esac
done

PAYLOAD="$PACKAGE/payload"
FILES=(NorrNoteWidget/NorrNoteHomeWidget.swift NorrNote21FEiOS/FEiOSRootView.swift NorrNote21FEiOS.xcodeproj/project.pbxproj)
# Exact, immutable package hashes: supported bases I3b3u/101, I3b3v/102,
# and a fully applied I3b3w/103 (for re-installing onto a physical iPhone).
SHA_U=(b7741970fc0c36a2e3f92c4398cb832adc7a40ddcac454b696a2265696e81e1b 25d28769fc38a95a456e4e7e0cdd9a4d65e4ff0e672a6cc1e44c26b8f94fab02 0d4575f489c158ed9f973e051dc1b36aaaba204381d3cd59e9c9aa8abaa0cb57)
SHA_V=(ae4a0e0457a5166c0eeb14a1259bea46ca49f61d3d4b3a602fb971669cf410ae 4386dcc88f2e4bb29cc31ca027a00efc9424b3dd9ac735f82346b474f6a1bef8 7b7dbf864d8ca416ec5e3e48ade70ff4d9cb62847b67478e7fbcca3e4ee9e04e)
SHA_W=(f777938b6da72f258adf4e33a6e7696b9ef8d191ceec3504724e6ce806bee8b3 629c0dcc524eca6727a639e29029d1c64cf04d72fda5e0fa178e32ba2ed3eee8 fc0b79fda0685c279832da3e7c03c7afa9f8f4569879518e5df2ac22e0c6b6bc)

if [[ -n "$EXPLICIT_ROOT" ]]; then
  if [[ "$EXPLICIT_ROOT" == *.xcodeproj ]]; then EXPLICIT_ROOT="$(dirname "$EXPLICIT_ROOT")"; fi
  [[ -d "$EXPLICIT_ROOT" ]] || { echo "STOP: selected project root does not exist: $EXPLICIT_ROOT" >&2; exit 3; }
  EXPLICIT_ROOT="$(cd "$EXPLICIT_ROOT" && pwd -P)"
  case "$EXPLICIT_ROOT/" in
    */Tests/*|*/tests/*|*/Fixtures/*|*/fixtures/*|*/Backups/*|*/DerivedData/*)
      echo "STOP: selected path is a test fixture or backup, not a working project: $EXPLICIT_ROOT" >&2
      exit 3 ;;
  esac
fi

projects=()
if [[ -n "$EXPLICIT_ROOT" ]]; then
  projects+=("$EXPLICIT_ROOT/NorrNote21FEiOS.xcodeproj")
else
  # Important: skip nested test fixtures and backups, which can contain a
  # complete-looking but outdated NorrNote21FEiOS.xcodeproj.
  while IFS= read -r p; do projects+=("$p"); done < <(
    find "$BASE" \
      \( -type d \( -iname 'Tests' -o -iname 'Fixtures' -o -iname 'Backups' -o -iname 'Archives' -o -iname 'DerivedData' -o -name '.patch-backups' -o -name '.git' -o -name 'node_modules' \) -prune \) -o \
      \( -type d -name NorrNote21FEiOS.xcodeproj -print \) | LC_ALL=C sort
  )
fi
(( ${#projects[@]} )) || { echo 'STOP: no non-fixture iOS Xcode projects found.' >&2; exit 3; }

matching=()
matching_versions=()
printf 'Looking for a verified iOS project (never selecting Tests/Fixtures):\n'
for candidate in "${projects[@]}"; do
  root="$(dirname "$candidate")"
  if [[ ! -f "$candidate/project.pbxproj" ]]; then
    printf '  INCOMPLETE: %s (no .pbxproj)\n' "$root"
    continue
  fi
  hashes=()
  missing=''
  for rel in "${FILES[@]}"; do
    if [[ ! -f "$root/$rel" ]]; then missing="$rel"; break; fi
    hashes+=("$(shasum -a 256 "$root/$rel" | awk '{print $1}')")
  done
  if [[ -n "$missing" ]]; then
    printf '  INCOMPLETE: %s (missing %s)\n' "$root" "$missing"
    continue
  fi
  version=''
  is_match=1
  for i in "${!FILES[@]}"; do [[ "${hashes[$i]}" == "${SHA_U[$i]}" ]] || is_match=0; done
  if (( is_match )); then version='I3b3u'; fi
  if [[ -z "$version" ]]; then
    is_match=1
    for i in "${!FILES[@]}"; do [[ "${hashes[$i]}" == "${SHA_V[$i]}" ]] || is_match=0; done
    if (( is_match )); then version='I3b3v'; fi
  fi
  if [[ -z "$version" ]]; then
    is_match=1
    for i in "${!FILES[@]}"; do [[ "${hashes[$i]}" == "${SHA_W[$i]}" ]] || is_match=0; done
    if (( is_match )); then version='I3b3w'; fi
  fi
  if [[ -n "$version" ]]; then
    printf '  VERIFIED %-7s %s\n' "$version" "$root"
    matching+=("$candidate")
    matching_versions+=("$version")
  else
    printf '  OTHER   %-13s %s\n' "widget=${hashes[0]:0:12}" "$root"
  fi
done

if (( LIST_ONLY )); then
  printf 'Matching candidates: %s. Listing only; no files changed.\n' "${#matching[@]}"
  exit 0
fi
if (( ${#matching[@]} == 0 )); then
  echo 'STOP: no actual Xcode project matches an exact I3b3u, I3b3v or I3b3w baseline.' >&2
  echo 'No changes made. If an I3b3u/v/w project has extra edits, provide its current source files; do not force an overwrite.' >&2
  exit 3
fi
if (( ${#matching[@]} > 1 )); then
  echo 'STOP: several matching projects found. Automatic selection would be unsafe.' >&2
  echo 'Rerun with: bash install.sh --project "/full/path/to/the/real/project"' >&2
  echo 'No changes made.' >&2
  exit 3
fi
PROJECT="${matching[0]}"
ROOT="$(dirname "$PROJECT")"
SOURCE_BASELINE="${matching_versions[0]}"
printf 'Selected project: %s\nVerified source version: %s\n' "$ROOT" "$SOURCE_BASELINE"
for rel in "${FILES[@]}"; do
  [[ -f "$PAYLOAD/$rel" ]] || { echo "STOP: missing package file $rel" >&2; exit 3; }
done
plutil -lint "$PAYLOAD/NorrNote21FEiOS.xcodeproj/project.pbxproj" >/dev/null
[[ $(grep -c 'CURRENT_PROJECT_VERSION = 103;' "$PAYLOAD/NorrNote21FEiOS.xcodeproj/project.pbxproj") == 4 ]] || {
  echo 'STOP: invalid patch build number' >&2; exit 3;
}

# Select an existing genuine NORRVIND logo. Do not invent a substitute SF Symbol.
APP_ASSETS="$ROOT/NorrNote21FEiOS/Assets.xcassets"
WIDGET_ASSETS="$ROOT/NorrNoteWidget/Assets.xcassets"
TARGET="$WIDGET_ASSETS/NorrNoteShip.imageset"
[[ -d "$APP_ASSETS" ]] || { echo "STOP: app assets not found: $APP_ASSETS" >&2; exit 4; }
MODE=''
SOURCE=''
if [[ -f "$APP_ASSETS/NorrNoteShip.imageset/Contents.json" ]]; then
  MODE='imageset'; SOURCE="$APP_ASSETS/NorrNoteShip.imageset"
else
  # Find an explicitly branded ship-logo asset before considering the app icon.
  SOURCE="$(find "$APP_ASSETS" -type d \( -iname '*Ship*.imageset' -o -iname '*Norr*Logo*.imageset' \) -print | LC_ALL=C sort | head -n 1 || true)"
  if [[ -n "$SOURCE" && -f "$SOURCE/Contents.json" ]]; then MODE='imageset'; else SOURCE=''; fi
fi
if [[ -z "$MODE" ]]; then
  # The user selected the ship as the app icon. Pick the HIGHEST RESOLUTION
  # file instead of the first arbitrary image in AppIcon.appiconset.
  ICONSET="$APP_ASSETS/AppIcon.appiconset"
  if [[ -d "$ICONSET" ]]; then
    biggest=0
    while IFS= read -r path; do
      w="$(sips -g pixelWidth "$path" 2>/dev/null | awk '/pixelWidth:/ {print $2}')"
      h="$(sips -g pixelHeight "$path" 2>/dev/null | awk '/pixelHeight:/ {print $2}')"
      [[ "$w" =~ ^[0-9]+$ && "$h" =~ ^[0-9]+$ ]] || continue
      area=$(( w * h ))
      if (( area > biggest )); then biggest="$area"; SOURCE="$path"; fi
    done < <(find "$ICONSET" -type f \( -iname '*.png' -o -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.heic' \) -print | LC_ALL=C sort)
    if (( biggest >= 16384 )); then MODE='icon'; fi
  fi
fi
if [[ -z "$MODE" ]]; then
  echo 'STOP: no verified ship image in app assets. Refusing generic sailboat fallback.' >&2
  echo 'No changes made. Supply the real NorrNoteShip.imageset in the app assets.' >&2
  exit 4
fi
printf 'NORRVIND icon source: %s\n' "$SOURCE"

# Do not modify local sources if no physical iPhone is available to receive them.
DEVICE="${NORRNOTE_DEVICE:-$DEVICE_ARG}"
TEMP="$(mktemp -d "${TMPDIR:-/tmp}/norrnote-i3b3w.XXXXXX")"
cleanup_tmp() { rm -rf "$TEMP"; }
trap cleanup_tmp EXIT
if [[ -z "$DEVICE" ]]; then
  if xcrun devicectl list devices --json-output "$TEMP/devices.json" >"$TEMP/devices.log" 2>&1 && command -v python3 >/dev/null; then
    DEVICE="$(python3 - "$TEMP/devices.json" <<'PY'
import json,sys
try:
 d=json.load(open(sys.argv[1])).get('result',{}).get('devices',[])
 candidates=[]
 for x in d:
  props=x.get('deviceProperties') or x.get('properties') or {}
  hw=x.get('hardwareProperties') or {}
  name=str(props.get('name') or x.get('name') or '')
  dtype=str(props.get('deviceType') or props.get('productType') or hw.get('productType') or '')
  ident=x.get('identifier') or ''
  if ident and ('iphone' in (name+' '+dtype).lower()):
   candidates.append(ident)
 if len(candidates)==1: print(candidates[0])
except Exception: pass
PY
)"
  fi
fi
if [[ -z "$DEVICE" ]]; then
  echo 'Connect/unlock the physical iPhone; authorize it in Xcode if needed.'
  xcrun devicectl list devices || true
  echo 'STOP: could not uniquely determine the physical iPhone.' >&2
  echo 'Run again as: bash install.sh <iPhone ID from devicectl list devices>' >&2
  exit 5
fi
echo "Target physical device: $DEVICE"

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$ROOT/.patch-backups/I3b3w1-$STAMP"
mkdir -p "$BACKUP/original"
for rel in "${FILES[@]}"; do
  mkdir -p "$BACKUP/original/$(dirname "$rel")"
  cp -p "$ROOT/$rel" "$BACKUP/original/$rel"
done
ASSET_EXISTED=0
if [[ -d "$TARGET" ]]; then
  ASSET_EXISTED=1
  mkdir -p "$BACKUP/original/NorrNoteWidget/Assets.xcassets"
  cp -R "$TARGET" "$BACKUP/original/NorrNoteWidget/Assets.xcassets/"
fi

PATCH_STARTED=0
INSTALL_SUCCEEDED=0
restore_sources() {
  echo "ROLLBACK: restoring $SOURCE_BASELINE source files and icon assets." >&2
  for rel in "${FILES[@]}"; do
    cp -p "$BACKUP/original/$rel" "$ROOT/$rel"
  done
  rm -rf "$TARGET"
  if (( ASSET_EXISTED == 1 )); then
    cp -R "$BACKUP/original/NorrNoteWidget/Assets.xcassets/NorrNoteShip.imageset" "$TARGET"
  fi
}
exit_handler() {
  rc="$1"
  trap - EXIT
  if (( rc != 0 && PATCH_STARTED == 1 && INSTALL_SUCCEEDED == 0 )); then restore_sources; fi
  cleanup_tmp
  exit "$rc"
}
trap 'exit_handler "$?"' EXIT
PATCH_STARTED=1
for rel in "${FILES[@]}"; do cp "$PAYLOAD/$rel" "$ROOT/$rel"; done
rm -rf "$TARGET"
mkdir -p "$WIDGET_ASSETS"
if [[ "$MODE" == 'imageset' ]]; then
  cp -R "$SOURCE" "$TARGET"
else
  mkdir -p "$TARGET"
  sips -s format png -Z 512 "$SOURCE" --out "$TARGET/ship-logo.png" >/dev/null
  cat > "$TARGET/Contents.json" <<'JSON'
{
  "images": [{ "filename": "ship-logo.png", "idiom": "universal" }],
  "info": { "author": "xcode", "version": 1 }
}
JSON
fi

[[ -f "$TARGET/Contents.json" ]] || { echo 'STOP: image asset failed' >&2; exit 6; }
# Validate source image references before building. The image source must
# contain a filename resolvable inside the widget imageset.
files_found="$(find "$TARGET" -maxdepth 1 -type f \( -iname '*.png' -o -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.heic' -o -iname '*.pdf' -o -iname '*.svg' \) -print | wc -l | tr -d ' ')"
(( files_found >= 1 )) || { echo 'STOP: ship asset has no image files' >&2; exit 6; }

echo 'Building SIGNED application for physical iPhone (not Simulator)...'
set +e
xcodebuild -project "$PROJECT" -scheme NorrNote21FEiOS -configuration Debug \
  -destination "platform=iOS,id=$DEVICE" -derivedDataPath "$TEMP/DerivedData" \
  -allowProvisioningUpdates build > "$BACKUP/xcodebuild-device.log" 2>&1
rc=$?
set -e
if (( rc != 0 )); then
  echo 'STOP: Xcode physical-device build failed. Not installed.' >&2
  tail -n 65 "$BACKUP/xcodebuild-device.log" >&2
  exit "$rc"
fi
APP="$TEMP/DerivedData/Build/Products/Debug-iphoneos/NorrNote21FEiOS.app"
EXT="$APP/PlugIns/NorrNoteHomeWidget.appex"
[[ -d "$APP" && -d "$EXT" && -f "$EXT/Assets.car" ]] || {
  echo 'STOP: signed app, embedded widget or compiled Assets.car missing' >&2; exit 7;
}
APP_VER="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleVersion' "$APP/Info.plist")"
EXT_VER="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleVersion' "$EXT/Info.plist")"
[[ "$APP_VER" == 103 && "$EXT_VER" == 103 ]] || {
  echo "STOP: app/extension version mismatch: $APP_VER / $EXT_VER" >&2; exit 7;
}
echo 'Verified built bundles: app=103 widget=103.'
# assetutil is an Apple tool; if available, verify the brand asset was really
# compiled into the widget instead of only existing in source assets.
if xcrun --find assetutil >/dev/null 2>&1; then
  if xcrun assetutil --info "$EXT/Assets.car" >"$BACKUP/compiled-assets.json" 2>/dev/null; then
    if ! grep -Fq 'NorrNoteShip' "$BACKUP/compiled-assets.json"; then
      echo 'STOP: NorrNoteShip missing from compiled widget asset catalog' >&2; exit 7
    fi
    echo 'Verified NorrNoteShip is present in the compiled widget assets.'
  fi
fi

echo 'Installing build 103 onto the PHYSICAL iPhone; existing user data will stay.'
if ! xcrun devicectl device install app --device "$DEVICE" "$APP" \
  >"$BACKUP/devicectl-install.log" 2>&1; then
  cat "$BACKUP/devicectl-install.log" >&2
  echo 'STOP: device installation failed. No success reported.' >&2
  exit 8
fi
INSTALL_SUCCEEDED=1
if ! xcrun devicectl device process launch --device "$DEVICE" su.norrvind.norrnote.fe.ios \
  >"$BACKUP/devicectl-launch.log" 2>&1; then
  echo 'NOTE: build installed, but app did not launch automatically. Open it on iPhone.' >&2
fi
printf '\nINSTALLED: NorrNote21FE iOS build 103 on physical iPhone.\n'
printf 'BACKUP: %s\n' "$BACKUP"
echo 'Widget cache: REMOVE ONLY the old home-screen widget and ADD NorrNote — на день again.'
echo 'Look for the small W103 marker beside NorrNote and the authentic ship icon.'
echo 'Tap the entire circle area (44 x 44). The note should disappear without opening editor.'
echo 'If W103 is not shown, restart iPhone; do not delete the app or note data.'
