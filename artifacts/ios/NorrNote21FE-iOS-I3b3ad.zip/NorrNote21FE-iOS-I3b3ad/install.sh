#!/usr/bin/env bash
# I3b3ad: verified local 107 or 108 -> build 109; target iPhone 103-108.
# Widget/UI/assets and notes are never modified by this patch.
set -euo pipefail

PACKAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
PROJECT_ROOT="${NORRNOTE21FE_PROJECT_ROOT:-$HOME/Projects/NorrNote21FE/iOS/NorrNote21FE-iOS-I1}"
DEVICE_NAME="${NORRNOTE_DEVICE_NAME:-DarthVader_iPhone}"
DEVICE="${NORRNOTE_DEVICE:-}"
CHECK_ONLY=0
while (( $# )); do
  case "$1" in
    --check) CHECK_ONLY=1; shift ;;
    --project) [[ $# -ge 2 ]] || exit 2; PROJECT_ROOT="$2"; shift 2 ;;
    --device-name) [[ $# -ge 2 ]] || exit 2; DEVICE_NAME="$2"; shift 2 ;;
    --device) [[ $# -ge 2 ]] || exit 2; DEVICE="$2"; shift 2 ;;
    *) echo "STOP: unknown argument: $1" >&2; exit 2 ;;
  esac
done
for tool in shasum python3 xcrun xcodebuild plutil; do
  command -v "$tool" >/dev/null || { echo "STOP: missing $tool" >&2; exit 2; }
done
[[ -x /usr/libexec/PlistBuddy ]] || { echo 'STOP: PlistBuddy unavailable' >&2; exit 2; }
[[ -d "$PROJECT_ROOT" ]] || { echo "STOP: no project root: $PROJECT_ROOT" >&2; exit 2; }
PROJECT_ROOT="$(cd "$PROJECT_ROOT" && pwd -P)"
case "$PROJECT_ROOT/" in
  */Tests/*|*/Fixtures/*|*/Backups/*|*/I3b3u-Backup/*|*/DerivedData/*|*/.patch-backups/*)
    echo 'STOP: refusing fixture/backup directory' >&2; exit 3 ;;
esac
PROJECT="$PROJECT_ROOT/NorrNote21FEiOS.xcodeproj"
[[ -f "$PROJECT/project.pbxproj" ]] || { echo 'STOP: not an iOS Xcode project' >&2; exit 3; }
EDITOR='NorrNote21FEiOS/FEiOSRootView.swift'
PBX='NorrNote21FEiOS.xcodeproj/project.pbxproj'
WIDGET='NorrNoteWidget/NorrNoteHomeWidget.swift'
BASE_EDITOR='0ed4364e4f2ed330153f3e5b8ba8b679f39491e13bef96d5922f4d5c343eb94c'
BASE_PBX='7084761cffadf01dec31062e4650ca27096a6c8ff2cb2651cfec0d8f8451e310'
BASE107_EDITOR='b1733cd65b55b71ce24dbf10359e912e55971be7495b59b84beed3ab41f82e49'
BASE107_PBX='a100a760eca699d6d96a425008db4486b5d45a8406f3b93d383db9b0a52fcf59'
BASE_WIDGET='dd7e99a9b63db15fc48dd57207a1c4f91722068a21a91d081688d791ca8366fa'
NEW_EDITOR='9781ef83213e555cfd3f2c4d1118e3485723180d0eb3e202ffa51aa721be10dc'
NEW_PBX='14924fbd77a23436ffa849aa157f6fdcb3fe014d5f992be0e0506f2e999efe2f'
BUNDLE='su.norrvind.norrnote.fe.ios'
sha() { shasum -a 256 "$1" | awk '{print $1}'; }
verify() {
  local path="$1" expected="$2" actual
  [[ -f "$path" ]] || { echo "STOP: missing $path" >&2; exit 4; }
  actual="$(sha "$path")"
  [[ "$actual" == "$expected" ]] || { echo "STOP: source version mismatch: $path" >&2; printf ' expected: %s\n actual: %s\n' "$expected" "$actual" >&2; echo 'No changes made.' >&2; exit 4; }
}
# Verify editor and project configuration AS A MATCHED PAIR, never mix
# a source file from one build with the configuration of another.
CURRENT_EDITOR_HASH="$(sha "$PROJECT_ROOT/$EDITOR")"
CURRENT_PBX_HASH="$(sha "$PROJECT_ROOT/$PBX")"
if [[ "$CURRENT_EDITOR_HASH" == "$BASE_EDITOR" && "$CURRENT_PBX_HASH" == "$BASE_PBX" ]]; then
  SOURCE_BUILD=108
elif [[ "$CURRENT_EDITOR_HASH" == "$BASE107_EDITOR" && "$CURRENT_PBX_HASH" == "$BASE107_PBX" ]]; then
  SOURCE_BUILD=107
else
  echo 'STOP: local editor/project hashes do not match a complete, verified build 107 or 108. No changes made.' >&2
  printf ' editor SHA256: %s\n project SHA256: %s\n' "$CURRENT_EDITOR_HASH" "$CURRENT_PBX_HASH" >&2
  exit 4
fi
verify "$PROJECT_ROOT/$WIDGET" "$BASE_WIDGET"
verify "$PACKAGE/payload/$EDITOR" "$NEW_EDITOR"
verify "$PACKAGE/payload/$PBX" "$NEW_PBX"
plutil -lint "$PACKAGE/payload/$PBX" >/dev/null
[[ $(grep -c 'CURRENT_PROJECT_VERSION = 109;' "$PACKAGE/payload/$PBX") -eq 4 ]] || { echo 'STOP: incorrect build 109 configuration' >&2; exit 4; }
[[ $(grep -c "CURRENT_PROJECT_VERSION = $SOURCE_BUILD;" "$PROJECT_ROOT/$PBX") -eq 4 ]] || { echo 'STOP: project build number does not match verified source' >&2; exit 4; }
[[ -f "$PROJECT_ROOT/NorrNoteWidget/Assets.xcassets/NorrNoteShip.imageset/Contents.json" ]] || { echo 'STOP: branded ship asset not found' >&2; exit 4; }

TMP="$(mktemp -d "${TMPDIR:-/tmp}/norrnote-voice-delivery.XXXXXX")"
BACKUP=''
PATCH_STARTED=0
DEVICE_INSTALLED=0
restore() {
  [[ -n "$BACKUP" && -d "$BACKUP/original" ]] || return 0
  echo "ROLLBACK: restoring original build $SOURCE_BUILD sources" >&2
  cp -p "$BACKUP/original/$EDITOR" "$PROJECT_ROOT/$EDITOR"
  cp -p "$BACKUP/original/$PBX" "$PROJECT_ROOT/$PBX"
}
exit_handler() {
  local result="$1"
  trap - EXIT
  if (( result != 0 && PATCH_STARTED == 1 && DEVICE_INSTALLED == 0 )); then restore; fi
  if (( result != 0 && DEVICE_INSTALLED == 1 )); then
    echo 'NOTE: installation command succeeded, but build 109 could not be verified on device. Local source is retained; investigate before retrying.' >&2
  fi
  rm -rf "$TMP"
  exit "$result"
}
trap 'exit_handler "$?"' EXIT

if [[ -z "$DEVICE" ]]; then
  xcrun devicectl list devices --json-output "$TMP/devices.json" >"$TMP/devices.log" 2>&1 || { echo 'STOP: cannot list devices' >&2; exit 5; }
  DEVICE="$(python3 - "$TMP/devices.json" "$DEVICE_NAME" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f: devices=json.load(f).get('result',{}).get('devices',[])
name=sys.argv[2]
found=[]
for d in devices:
 p=d.get('deviceProperties') or d.get('properties') or {}
 h=d.get('hardwareProperties') or {}
 kind=' '.join(str(x) for x in (h.get('marketingName'),p.get('productType'),h.get('productType')) if x).lower()
 if p.get('name')==name and 'iphone' in (kind+' '+name.lower()) and d.get('identifier'):found.append(d['identifier'])
if len(found)!=1:sys.exit(f'STOP: expected one device named {name}, found {len(found)}')
print(found[0])
PY
)" || exit 5
fi
read_installed_build() {
 xcrun devicectl device info apps --device "$DEVICE" --json-output "$TMP/apps.json" >"$TMP/apps.log" 2>&1 || { echo 'STOP: cannot read installed app version' >&2; return 1; }
 python3 - "$TMP/apps.json" "$BUNDLE" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f: apps=json.load(f).get('result',{}).get('apps',[])
found=[a for a in apps if a.get('bundleIdentifier')==sys.argv[2]]
if len(found)!=1:sys.exit('STOP: app not uniquely installed')
print(str(found[0].get('bundleVersion','unknown')))
PY
}
BEFORE="$(read_installed_build)" || exit 5
# The source must be verified local build 107 or 108. Previously, patch installation
# sometimes updated Mac sources without reaching the iPhone. Allow upgrading
# a known older app build 103–108 on this uniquely selected device.
[[ "$BEFORE" =~ ^(103|104|105|106|107|108)$ ]] || { echo "STOP: expected on-device build 103–108; found $BEFORE. No changes made." >&2; exit 5; }
echo "PRECHECK PASS: verified local source $SOURCE_BUILD; device $DEVICE_NAME build $BEFORE. Delivering build 109."
if (( CHECK_ONLY )); then echo 'CHECK ONLY: no files changed'; exit 0; fi

BACKUP="$PROJECT_ROOT/.patch-backups/I3b3ad-$(date '+%Y%m%d-%H%M%S')"
mkdir -p "$BACKUP/original/$(dirname "$EDITOR")" "$BACKUP/original/$(dirname "$PBX")"
cp -p "$PROJECT_ROOT/$EDITOR" "$BACKUP/original/$EDITOR"
cp -p "$PROJECT_ROOT/$PBX" "$BACKUP/original/$PBX"
PATCH_STARTED=1
cp -p "$PACKAGE/payload/$EDITOR" "$PROJECT_ROOT/$EDITOR"
cp -p "$PACKAGE/payload/$PBX" "$PROJECT_ROOT/$PBX"
verify "$PROJECT_ROOT/$EDITOR" "$NEW_EDITOR"
verify "$PROJECT_ROOT/$PBX" "$NEW_PBX"

echo 'Building signed iOS app and Widget Extension for physical iPhone...'
if ! xcodebuild -project "$PROJECT" -scheme NorrNote21FEiOS -configuration Debug -destination "platform=iOS,id=$DEVICE" -derivedDataPath "$TMP/DerivedData" -allowProvisioningUpdates build >"$BACKUP/xcodebuild-device.log" 2>&1; then
  echo 'STOP: Xcode build failed; restoring original build $SOURCE_BUILD sources.' >&2
  tail -n 60 "$BACKUP/xcodebuild-device.log" >&2
  exit 6
fi
APP="$TMP/DerivedData/Build/Products/Debug-iphoneos/NorrNote21FEiOS.app"
EXT="$APP/PlugIns/NorrNoteHomeWidget.appex"
[[ -d "$APP" && -d "$EXT" && -f "$EXT/Assets.car" ]] || { echo 'STOP: signed app, widget extension or assets missing' >&2; exit 7; }
plist() { /usr/libexec/PlistBuddy -c "Print :$2" "$1"; }
APP_VERSION="$(plist "$APP/Info.plist" CFBundleVersion)"
EXT_VERSION="$(plist "$EXT/Info.plist" CFBundleVersion)"
APP_ID="$(plist "$APP/Info.plist" CFBundleIdentifier)"
EXT_POINT="$(plist "$EXT/Info.plist" NSExtension:NSExtensionPointIdentifier)"
[[ "$APP_VERSION" == 109 && "$EXT_VERSION" == 109 && "$APP_ID" == "$BUNDLE" && "$EXT_POINT" == 'com.apple.widgetkit-extension' ]] || {
  echo "STOP: built versions/identities incorrect app=$APP_VERSION widget=$EXT_VERSION bundle=$APP_ID extension=$EXT_POINT" >&2; exit 7;
}
if xcrun --find assetutil >/dev/null 2>&1 && xcrun assetutil --info "$EXT/Assets.car" >"$BACKUP/compiled-assets.json" 2>/dev/null; then
  grep -Fq NorrNoteShip "$BACKUP/compiled-assets.json" || { echo 'STOP: branded ship absent from compiled widget assets' >&2; exit 7; }
fi
if ! xcrun devicectl device install app --device "$DEVICE" "$APP" >"$BACKUP/devicectl-install.log" 2>&1; then
  echo 'STOP: device installation failed; restoring local source' >&2
  tail -n 20 "$BACKUP/devicectl-install.log" >&2
  exit 8
fi
DEVICE_INSTALLED=1
AFTER="$(read_installed_build)" || exit 9
[[ "$AFTER" == 109 ]] || { echo "STOP: installed build is $AFTER not 109" >&2; exit 9; }
xcrun devicectl device process launch --device "$DEVICE" "$BUNDLE" >"$BACKUP/devicectl-launch.log" 2>&1 || echo 'NOTE: launch app manually on iPhone'
printf '\nSUCCESS: build 109 verified on %s.\nBACKUP: %s\n' "$DEVICE_NAME" "$BACKUP"
echo 'Voice overlap merge restored from I3b3v; partial revisions, late finalization and editor feedback handling preserved. Widget not modified.'
