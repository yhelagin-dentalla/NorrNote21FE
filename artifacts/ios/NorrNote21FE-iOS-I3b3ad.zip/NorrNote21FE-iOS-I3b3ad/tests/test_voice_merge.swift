import Foundation
struct Segment { let timestamp: Double; let duration: Double }
struct SFTranscription { let segments: [Segment] }
final class VoiceState {
    private var committed = ""
    private var lastPartial = ""
    private var lastPartialAudioEnd: TimeInterval?
    private(set) var transcript = ""
    private static func words(_ text: String) -> [String] {
        text.lowercased()
            .split(whereSeparator: { $0.isWhitespace })
            .map { String($0.filter { $0.isLetter || $0.isNumber }) }
            .filter { !$0.isEmpty }
    }

    private static func join(_ lhs: String, _ rhs: String) -> String {
        let left = lhs.trimmingCharacters(in: .whitespacesAndNewlines)
        let right = rhs.trimmingCharacters(in: .whitespacesAndNewlines)
        if left.isEmpty { return right }
        if right.isEmpty { return left }
        return left + " " + right
    }

    // Longest word overlap between committed text and the new recognizer
    // fragment. Also handles a recognizer sending the entire phrase again.
    // This is intentionally NOT run between successive partial hypotheses.
    private static func merge(_ previous: String, _ next: String) -> String {
        let left = words(previous), right = words(next)
        if left.isEmpty { return next.trimmingCharacters(in: .whitespacesAndNewlines) }
        if right.isEmpty { return previous }
        if right.count >= left.count && Array(right.prefix(left.count)) == left {
            return next.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        var overlap = min(left.count, right.count)
        while overlap > 0 && Array(left.suffix(overlap)) != Array(right.prefix(overlap)) {
            overlap -= 1
        }
        if overlap == 0 { return join(previous, next) }
        let tokens = next.split(whereSeparator: { $0.isWhitespace }).map(String.init)
        var consumedWords = 0
        var index = 0
        while index < tokens.count && consumedWords < overlap {
            if tokens[index].contains(where: { $0.isLetter || $0.isNumber }) {
                consumedWords += 1
            }
            index += 1
        }
        return join(previous, tokens.dropFirst(index).joined(separator: " "))
    }

    func accept(_ text: String, transcription: SFTranscription, isFinal: Bool) {
        let segments = transcription.segments
        let firstAudioTime = segments.first?.timestamp
        let lastAudioTime = segments.last.map { $0.timestamp + $0.duration }
        if !Self.words(text).isEmpty {
            if !lastPartial.isEmpty,
               let firstAudioTime, let lastPartialAudioEnd,
               firstAudioTime >= lastPartialAudioEnd + 0.30 {
                // Recognition dropped the previous utterance. Preserve it once
                // and deduplicate any overlapping words with I3b3v's merger.
                committed = Self.merge(committed, lastPartial)
            }
            lastPartial = text
            transcript = Self.merge(committed, text)
        }
        // Blank final snapshots must not erase already recognised words.
        if let lastAudioTime { lastPartialAudioEnd = lastAudioTime }
        if isFinal {
            committed = transcript
            lastPartial = ""
            lastPartialAudioEnd = nil
        }
    }


}
func feed(_ state: VoiceState, _ text: String, _ first: Double, _ end: Double, _ final: Bool = false) {
    state.accept(text, transcription: SFTranscription(segments: [Segment(timestamp: first, duration: end-first)]), isFinal: final)
}
func eq(_ a: String, _ b: String, _ name: String) {
    guard a == b else { fatalError("FAIL \(name): got [\(a)] expected [\(b)]") }
    print("PASS \(name): \(a)")
}
let a = VoiceState()
feed(a,"Пробуем",0,0.5)
feed(a,"Пробуем записать",0,1.3)
feed(a,"Пробуем записать фразу",0,2.1)
eq(a.transcript,"Пробуем записать фразу","partial revisions replace")
feed(a,"Пробуем записать",0,1.3)
eq(a.transcript,"Пробуем записать","shortening is revision")
feed(a,"Пробуем записать фразу",0,2.1)
feed(a,"фразу ещё раз",2.50,3.5)
eq(a.transcript,"Пробуем записать фразу ещё раз","gapped new audio with lexical overlap")
feed(a,"фразу ещё раз всё",2.50,3.95)
eq(a.transcript,"Пробуем записать фразу ещё раз всё","partial revision of second phrase")
feed(a,"",2.50,3.95,true)
eq(a.transcript,"Пробуем записать фразу ещё раз всё","blank final preserves")
let b=VoiceState()
feed(b,"Я читаю",0,1.1)
feed(b,"Я читаю новую книгу",0,2.7,true)
eq(b.transcript,"Я читаю новую книгу","final")
let c=VoiceState()
feed(c,"Да да",0,1.0)
eq(c.transcript,"Да да","legitimate repeated words remain")
let d=VoiceState()
feed(d,"Первая фраза",0,1.0)
feed(d,"Потом другая",1.5,2.2)
eq(d.transcript,"Первая фраза Потом другая","distinct audio append")
let e=VoiceState()
feed(e,"Завтра",0,0.4)
feed(e,"Завтра мы поедем",0,1.0)
feed(e,"Завтра мы поедем домой",0,1.6,true)
eq(e.transcript,"Завтра мы поедем домой","no additive partials")
