#!/usr/bin/env bash
# NorrNote21FE iOS I3b3x / build 104 — VISUAL-ONLY widget update.
# Strictly targets the confirmed project and DarthVader_iPhone. Never removes app/data.
set -euo pipefail

PACKAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
PROJECT_ROOT="${NORRNOTE21FE_PROJECT_ROOT:-$HOME/Projects/NorrNote21FE/iOS/NorrNote21FE-iOS-I1}"
DEVICE_NAME="${NORRNOTE_DEVICE_NAME:-DarthVader_iPhone}"
EXPLICIT_DEVICE="${NORRNOTE_DEVICE:-}"
CHECK_ONLY=0

usage() { echo 'Usage: bash install.sh [--check] [--project /absolute/path] [--device-name exactName] [--device exactID]'; }
while (( $# )); do
  case "$1" in
    --check) CHECK_ONLY=1; shift ;;
    --project) [[ $# -ge 2 ]] || { usage; exit 2; }; PROJECT_ROOT="$2"; shift 2 ;;
    --device-name) [[ $# -ge 2 ]] || { usage; exit 2; }; DEVICE_NAME="$2"; shift 2 ;;
    --device) [[ $# -ge 2 ]] || { usage; exit 2; }; EXPLICIT_DEVICE="$2"; shift 2 ;;
    *) echo "STOP: unknown argument $1" >&2; usage; exit 2 ;;
  esac
done

for tool in shasum python3 xcrun xcodebuild plutil; do
  command -v "$tool" >/dev/null 2>&1 || { echo "STOP: missing required tool $tool" >&2; exit 2; }
done
[[ -x /usr/libexec/PlistBuddy ]] || { echo 'STOP: macOS PlistBuddy not available.' >&2; exit 2; }
[[ -d "$PROJECT_ROOT" ]] || { echo "STOP: missing Xcode project root $PROJECT_ROOT" >&2; exit 3; }
PROJECT_ROOT="$(cd "$PROJECT_ROOT" && pwd -P)"
case "$PROJECT_ROOT/" in
  */Tests/*|*/Fixtures/*|*/Backups/*|*/I3b3u-Backup/*|*/DerivedData/*|*/.patch-backups/*)
    echo 'STOP: refusing to patch a fixture/backup.' >&2; exit 3 ;;
esac
PROJECT="$PROJECT_ROOT/NorrNote21FEiOS.xcodeproj"
[[ -f "$PROJECT/project.pbxproj" ]] || { echo "STOP: not a valid iOS project: $PROJECT" >&2; exit 3; }

WIDGET='NorrNoteWidget/NorrNoteHomeWidget.swift'
PBX='NorrNote21FEiOS.xcodeproj/project.pbxproj'
EDITOR='NorrNote21FEiOS/FEiOSRootView.swift'
BASE_WIDGET='f777938b6da72f258adf4e33a6e7696b9ef8d191ceec3504724e6ce806bee8b3'
BASE_PBX='fc0b79fda0685c279832da3e7c03c7afa9f8f4569879518e5df2ac22e0c6b6bc'
BASE_EDITOR='629c0dcc524eca6727a639e29029d1c64cf04d72fda5e0fa178e32ba2ed3eee8'
NEW_WIDGET='f0dc3a2d6876d271acb6f863456cd38f7a20fc34ceb37f831ef1aa75ffac750e'
NEW_PBX='c2d380a9d5cc8fc4683afbb3ab90e6d5e8981b07c3a628e5a87ff280e59f8ea4'
BUNDLE='su.norrvind.norrnote.fe.ios'

sha() { shasum -a 256 "$1" | awk '{print $1}'; }
verify_sha() {
  local path="$1" expected="$2"
  [[ -f "$path" ]] || { echo "STOP: missing file: $path" >&2; exit 4; }
  local actual; actual="$(sha "$path")"
  [[ "$actual" == "$expected" ]] || {
    printf 'STOP: unexpected SHA256 for %s\n  expected %s\n  actual   %s\n' "$path" "$expected" "$actual" >&2
    echo 'No changes made. This project has a different version; do not overwrite.' >&2
    exit 4
  }
}
verify_sha "$PROJECT_ROOT/$WIDGET" "$BASE_WIDGET"
verify_sha "$PROJECT_ROOT/$PBX" "$BASE_PBX"
verify_sha "$PROJECT_ROOT/$EDITOR" "$BASE_EDITOR"
verify_sha "$PACKAGE/payload/$WIDGET" "$NEW_WIDGET"
verify_sha "$PACKAGE/payload/$PBX" "$NEW_PBX"
plutil -lint "$PACKAGE/payload/$PBX" >/dev/null
[[ $(grep -c 'CURRENT_PROJECT_VERSION = 104;' "$PACKAGE/payload/$PBX") -eq 4 ]] || {
  echo 'STOP: patch build number 104 is missing or inconsistent' >&2; exit 4;
}
if grep -q 'Text("W103")' "$PACKAGE/payload/$WIDGET"; then
  echo 'STOP: debug marker is still present in patch payload' >&2; exit 4
fi
if ! grep -q 'FEI3b3wMarkCompletedIntent(noteID: item.id)' "$PACKAGE/payload/$WIDGET" ||
   ! grep -Fq 'Image("NorrNoteShip")' "$PACKAGE/payload/$WIDGET"; then
  echo 'STOP: expected working button/logo is missing from patch payload' >&2; exit 4
fi
# The branded asset must already be installed in the working widget. Do not touch it.
BRAND="$PROJECT_ROOT/NorrNoteWidget/Assets.xcassets/NorrNoteShip.imageset"
[[ -f "$BRAND/Contents.json" ]] || { echo 'STOP: existing branded ship asset is missing; no changes made' >&2; exit 4; }
[[ $(find "$BRAND" -maxdepth 1 -type f \( -iname '*.png' -o -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.heic' -o -iname '*.pdf' \) | wc -l | tr -d ' ') -ge 1 ]] || {
  echo 'STOP: existing brand asset contains no image; no changes made' >&2; exit 4
}

TEMP="$(mktemp -d "${TMPDIR:-/tmp}/norrnote-i3b3x.XXXXXX")"
BACKUP=''
PATCH_STARTED=0
DEVICE_INSTALLED=0
cleanup() { rm -rf "$TEMP"; }
restore() {
  [[ -n "$BACKUP" && -d "$BACKUP/original" ]] || return 0
  echo 'ROLLBACK: restoring original build 103 sources; user data unchanged.' >&2
  cp -p "$BACKUP/original/$WIDGET" "$PROJECT_ROOT/$WIDGET"
  cp -p "$BACKUP/original/$PBX" "$PROJECT_ROOT/$PBX"
}
exit_handler() {
  local result="$1"
  trap - EXIT
  if (( result != 0 && PATCH_STARTED == 1 && DEVICE_INSTALLED == 0 )); then restore; fi
  if (( result != 0 && DEVICE_INSTALLED == 1 )); then
    echo 'NOTE: installation command succeeded, but read-back did not confirm build 104.' >&2
    echo 'Local build 104 sources were kept to avoid a source/device mismatch.' >&2
  fi
  cleanup
  exit "$result"
}
trap 'exit_handler "$?"' EXIT

DEVICE="$EXPLICIT_DEVICE"
if [[ -z "$DEVICE" ]]; then
  xcrun devicectl list devices --json-output "$TEMP/devices.json" >"$TEMP/devices.log" 2>&1 || {
    echo 'STOP: cannot query connected iPhones; unlock the device and open Xcode.' >&2
    tail -n 10 "$TEMP/devices.log" >&2; exit 5;
  }
  DEVICE="$(python3 - "$TEMP/devices.json" "$DEVICE_NAME" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as stream: devices=json.load(stream).get('result',{}).get('devices',[])
name=sys.argv[2]
hits=[]
for device in devices:
    props=device.get('deviceProperties') or device.get('properties') or {}
    hardware=device.get('hardwareProperties') or {}
    actual=str(props.get('name') or '')
    ident=device.get('identifier')
    kind=' '.join(str(x) for x in (hardware.get('marketingName'),props.get('productType'),hardware.get('productType')) if x).lower()
    if actual==name and ident and 'iphone' in (kind+' '+actual).lower():hits.append(ident)
if len(hits)!=1:sys.exit(f'STOP: found {len(hits)} iPhones named {name!r}, expected exactly one.')
print(hits[0])
PY
)" || exit 5
fi

read_installed_build() {
  xcrun devicectl device info apps --device "$DEVICE" --json-output "$TEMP/apps.json" >"$TEMP/apps.log" 2>&1 || {
    echo 'STOP: cannot query installed apps on the selected iPhone' >&2
    tail -n 10 "$TEMP/apps.log" >&2; return 1
  }
  python3 - "$TEMP/apps.json" "$BUNDLE" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f: apps=json.load(f).get('result',{}).get('apps',[])
matched=[a for a in apps if a.get('bundleIdentifier')==sys.argv[2]]
if len(matched)!=1:sys.exit('STOP: target application not uniquely installed on iPhone')
print(str(matched[0].get('bundleVersion','unknown')))
PY
}
ON_DEVICE="$(read_installed_build)" || exit 5
[[ "$ON_DEVICE" == '103' ]] || {
  echo "STOP: expected build 103 on $DEVICE_NAME, found $ON_DEVICE; no changes made" >&2; exit 5;
}
printf 'PRECHECK PASS: source build 103; device "%s" build %s.\n' "$DEVICE_NAME" "$ON_DEVICE"
if (( CHECK_ONLY )); then
  echo 'CHECK ONLY: source and device verified. Nothing changed.'
  exit 0
fi

BACKUP="$PROJECT_ROOT/.patch-backups/I3b3x-$(date '+%Y%m%d-%H%M%S')"
mkdir -p "$BACKUP/original/$(dirname "$WIDGET")" "$BACKUP/original/$(dirname "$PBX")"
cp -p "$PROJECT_ROOT/$WIDGET" "$BACKUP/original/$WIDGET"
cp -p "$PROJECT_ROOT/$PBX" "$BACKUP/original/$PBX"
PATCH_STARTED=1
cp -p "$PACKAGE/payload/$WIDGET" "$PROJECT_ROOT/$WIDGET"
cp -p "$PACKAGE/payload/$PBX" "$PROJECT_ROOT/$PBX"
verify_sha "$PROJECT_ROOT/$WIDGET" "$NEW_WIDGET"
verify_sha "$PROJECT_ROOT/$PBX" "$NEW_PBX"

echo 'Building signed app and Widget Extension for physical iPhone...'
if ! xcodebuild -project "$PROJECT" -scheme NorrNote21FEiOS -configuration Debug \
  -destination "platform=iOS,id=$DEVICE" -derivedDataPath "$TEMP/DerivedData" \
  -allowProvisioningUpdates build >"$BACKUP/xcodebuild-device.log" 2>&1; then
  echo 'STOP: Xcode build failed. No installation attempted.' >&2
  tail -n 65 "$BACKUP/xcodebuild-device.log" >&2
  exit 6
fi
APP="$TEMP/DerivedData/Build/Products/Debug-iphoneos/NorrNote21FEiOS.app"
EXT="$APP/PlugIns/NorrNoteHomeWidget.appex"
[[ -d "$APP" && -d "$EXT" && -f "$EXT/Assets.car" ]] || {
  echo 'STOP: compiled application, embedded widget, or Assets.car missing' >&2; exit 7;
}
plist() { /usr/libexec/PlistBuddy -c "Print :$2" "$1"; }
APP_VERSION="$(plist "$APP/Info.plist" CFBundleVersion)"
EXT_VERSION="$(plist "$EXT/Info.plist" CFBundleVersion)"
APP_ID="$(plist "$APP/Info.plist" CFBundleIdentifier)"
EXTENSION_POINT="$(plist "$EXT/Info.plist" NSExtension:NSExtensionPointIdentifier)"
[[ "$APP_VERSION" == 104 && "$EXT_VERSION" == 104 && "$APP_ID" == "$BUNDLE" && "$EXTENSION_POINT" == 'com.apple.widgetkit-extension' ]] || {
  echo "STOP: app/widget metadata inconsistent: app=$APP_VERSION widget=$EXT_VERSION bundle=$APP_ID extension=$EXTENSION_POINT" >&2; exit 7;
}
if xcrun --find assetutil >/dev/null 2>&1; then
  if xcrun assetutil --info "$EXT/Assets.car" >"$BACKUP/compiled-assets.json" 2>/dev/null; then
    grep -Fq NorrNoteShip "$BACKUP/compiled-assets.json" || {
      echo 'STOP: branded ship missing from compiled widget assets' >&2; exit 7;
    }
  fi
fi
printf 'Built app and widget: 104/104. Installing ONLY on %s...\n' "$DEVICE_NAME"
if ! xcrun devicectl device install app --device "$DEVICE" "$APP" >"$BACKUP/devicectl-install.log" 2>&1; then
  echo 'STOP: on-device installation failed. Backing up and restoring local source code.' >&2
  tail -n 30 "$BACKUP/devicectl-install.log" >&2
  exit 8
fi
DEVICE_INSTALLED=1
NEW_DEVICE_VERSION="$(read_installed_build)" || exit 9
[[ "$NEW_DEVICE_VERSION" == '104' ]] || {
  echo "STOP: device read-back returned $NEW_DEVICE_VERSION, expected 104" >&2; exit 9;
}
# Optional app launch prompts the app to refresh its WidgetKit timeline.
if ! xcrun devicectl device process launch --device "$DEVICE" "$BUNDLE" >"$BACKUP/devicectl-launch.log" 2>&1; then
  echo 'NOTE: app installed but could not auto-launch; open NorrNote on the iPhone.'
fi
printf '\nSUCCESS: %s now has NorrNote21FE build 104 (verified on device).\n' "$DEVICE_NAME"
printf 'BACKUP: %s\n' "$BACKUP"
echo 'W103 has been removed. The container uses an adaptive Apple-like background.'
echo 'The ship icon and completed-note button have NOT been changed.'
echo 'If the previous widget snapshot remains, remove ONLY the widget tile and add it again.'
